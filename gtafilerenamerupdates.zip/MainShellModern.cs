#nullable disable
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace GtaFileRenamer
{
    public class ModernMainForm : Form
    {
        private Panel _sidebar;
        private Panel _sidebarContent;
        private Panel _content;
        private Label _pageTitle;
        private Label _statusBar;
        private TextBox _navFilter;
        private RoundedButton _btnTheme;

        private readonly List<SidebarNavButton> _navButtons = new List<SidebarNavButton>();
        private readonly Dictionary<string, Func<Control>> _pageFactories = new Dictionary<string, Func<Control>>();
        private readonly Dictionary<string, Control> _pageCache = new Dictionary<string, Control>();
        private string _currentKey;

        public ModernMainForm()
        {
            this.Text = "GTA File Renamer  ·  OpenIV Edition";
            this.Size = new Size(1280, 820);
            this.MinimumSize = new Size(1000, 620);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 9f);
            this.BackColor = Theme.Background;
            this.Icon = SystemIcons.Application;

            RegisterPages();
            BuildShell();
            Theme.ThemeChanged += ApplyThemeToShell;
            NavigateTo("dashboard");
        }

        private void RegisterPages()
        {
            _pageFactories["rename"] = () => new RenamePanel { Dock = DockStyle.Fill };
            _pageFactories["eup"] = () => new EupPanel { Dock = DockStyle.Fill };
            _pageFactories["vehicle_addon"] = () => new VehicleAddonPanel { Dock = DockStyle.Fill };
            _pageFactories["addon_creator"] = () => new AddonCreatorPanel { Dock = DockStyle.Fill };
            _pageFactories["outfit_presets"] = () => new OutfitPresetManagerPanel { Dock = DockStyle.Fill };
            _pageFactories["vehicle_batch"] = () => new VehicleBatchEditPanel { Dock = DockStyle.Fill };
            _pageFactories["rpf_explorer"] = () => new RpfExplorerPanel { Dock = DockStyle.Fill };
            _pageFactories["dlc_manager"] = () => new DlcManagerPanel { Dock = DockStyle.Fill };
            _pageFactories["backup_manager"] = () => new BackupManagerPanel { Dock = DockStyle.Fill };
            _pageFactories["health_check"] = () => new SetupHealthCheckPanel { Dock = DockStyle.Fill };
            _pageFactories["dashboard"] = () => { var p = new DashboardPanel(); p.NavigateToRequested = key => NavigateTo(key); return p; };
            _pageFactories["changelog"] = () => new ChangelogPanel { Dock = DockStyle.Fill };
            _pageFactories["live_spawner"] = () => new LiveSpawnerPanel { Dock = DockStyle.Fill };
            _pageFactories["load_order"] = () => new LoadOrderManagerPanel { Dock = DockStyle.Fill };
            _pageFactories["meta_editor"] = () => new MetaEditorPanel { Dock = DockStyle.Fill };
            _pageFactories["mod_organizer"] = () => new ModOrganizerPanel { Dock = DockStyle.Fill };
            _pageFactories["batch"] = () => new BatchProcessorPanel { Dock = DockStyle.Fill };
            _pageFactories["toolbox"] = () => new ToolboxPanel { Dock = DockStyle.Fill };
            _pageFactories["budget"] = () => new StreamBudgetPanel { Dock = DockStyle.Fill };
            _pageFactories["conflict"] = () => new ConflictDetectorPanel { Dock = DockStyle.Fill };
            _pageFactories["scripts"] = () => new ScriptManagerPanel { Dock = DockStyle.Fill };
            _pageFactories["veh_wizard"] = () => new VehicleWizardPanel { Dock = DockStyle.Fill };
            _pageFactories["addon_injector"] = () => new AddonInjectorPanel { Dock = DockStyle.Fill };
            _pageFactories["settings"] = () => new AppSettingsPanel { Dock = DockStyle.Fill };
        }

        private (string section, string glyph, string label, string key)[] NavItems => new[]
        {
            ("Home", "🏠", "Dashboard", "dashboard"),
            ("Core", "✎", "File Renamer", "rename"),
            ("Core", "📦", "FiveM EUP → SP", "eup"),
            ("Vehicle Tools", "🚗", "Vehicle Addon", "vehicle_addon"),
            ("Vehicle Tools", "🔧", "Addon Creator", "addon_creator"),
            ("Vehicle Tools", "🧙", "Vehicle Wizard", "veh_wizard"),
            ("Vehicle Tools", "🗃", "Batch Vehicle Edit", "vehicle_batch"),
            ("Ped Tools", "🧍", "Outfit Presets", "outfit_presets"),
            ("Archive & Data", "🔍", "RPF Explorer", "rpf_explorer"),
            ("Archive & Data", "📋", "DLC Manager", "dlc_manager"),
            ("Archive & Data", "🗄", "Backup Manager", "backup_manager"),
            ("Archive & Data", "🗺", "Load Order Manager", "load_order"),
            ("Archive & Data", "✏", "Meta Editor", "meta_editor"),
            ("Archive & Data", "🗂", "Mod Organizer", "mod_organizer"),
            ("Utilities", "🎮", "Test / Inject Addon", "addon_injector"),
            ("Utilities", "🚗", "Live Spawner", "live_spawner"),
            ("Utilities", "🩺", "Setup Health Check", "health_check"),
            ("Utilities", "📰", "Changelog", "changelog"),
            ("Utilities", "⚡", "Batch Processor", "batch"),
            ("Utilities", "🛠", "Toolbox", "toolbox"),
            ("Utilities", "📊", "Stream Budget", "budget"),
            ("Utilities", "⚡", "Conflict Detector", "conflict"),
            ("Utilities", "📜", "Script Manager", "scripts"),
            ("System", "⚙", "Settings", "settings"),
        };

        private void BuildShell()
        {
            // Sidebar Container
            _sidebar = new Panel { Dock = DockStyle.Left, Width = ModernUI.SidebarWidth, BackColor = Theme.Surface };

            // Right Main Container
            var right = new Panel { Dock = DockStyle.Fill };

            // --- Sidebar Interior ---
            var brandBar = new Panel { Dock = DockStyle.Top, Height = 56 };
            var brandLbl = new Label { Text = "🎮  GTA Renamer", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(18, 0, 0, 0), Font = new Font("Segoe UI Semibold", 11.5f, FontStyle.Bold), ForeColor = Theme.Accent };
            brandBar.Controls.Add(brandLbl);

            var filterBar = new Panel { Dock = DockStyle.Top, Height = 44, Padding = new Padding(14, 6, 14, 6) };
            _navFilter = new TextBox { Dock = DockStyle.Fill, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, PlaceholderText = "🔎 Filter tools…", Font = new Font("Segoe UI", 8.5f) };
            _navFilter.TextChanged += (s, e) => FilterNav(_navFilter.Text);
            filterBar.Controls.Add(_navFilter);

            _sidebarContent = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
            BuildNavButtons(_sidebarContent);

            _sidebar.Controls.Add(_sidebarContent);
            _sidebar.Controls.Add(filterBar);
            _sidebar.Controls.Add(brandBar);

            // --- Right Side Interior ---
            _statusBar = new Label { Dock = DockStyle.Bottom, Height = 30, Text = " Ready", TextAlign = ContentAlignment.MiddleLeft, BackColor = Theme.Surface, ForeColor = Theme.Text };

            var topBar = new Panel { Dock = DockStyle.Top, Height = ModernUI.TopBarHeight, BackColor = Theme.Background };
            _pageTitle = new Label { Text = "File Renamer", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(24, 0, 0, 0), Font = new Font("Segoe UI Semibold", 14f, FontStyle.Bold), ForeColor = Theme.Text };

            var actionContainer = new FlowLayoutPanel { Dock = DockStyle.Right, FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(0, 10, 20, 0), AutoSize = true, BackColor = Color.Transparent };
            _btnTheme = RoundedButton.Make(Theme.IsDark ? "☀ Light" : "🌙 Dark", 90, 30);
            _btnTheme.Click += (s, e) => { Theme.ToggleTheme(); _btnTheme.Text = Theme.IsDark ? "☀ Light" : "🌙 Dark"; };

            actionContainer.Controls.Add(_btnTheme);
            topBar.Controls.Add(actionContainer);
            topBar.Controls.Add(_pageTitle);

            var contentHost = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20, 12, 20, 20) };
            _content = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Background };
            contentHost.Controls.Add(_content);

            right.Controls.Add(contentHost);
            right.Controls.Add(topBar);
            right.Controls.Add(_statusBar);

            this.Controls.Add(right);
            this.Controls.Add(_sidebar);
        }

        private void BuildNavButtons(Panel host)
        {
            host.Controls.Clear();
            _navButtons.Clear();
            string lastSection = null;
            var toAdd = new List<Control>();

            foreach (var (section, glyph, label, key) in NavItems)
            {
                if (section != lastSection)
                {
                    toAdd.Add(new SidebarSectionLabel(section));
                    lastSection = section;
                }
                var btn = new SidebarNavButton(glyph, label, key);
                btn.Clicked += b => NavigateTo((string)b.PageKey);
                _navButtons.Add(btn);
                toAdd.Add(btn);
            }

            toAdd.Reverse();
            foreach (var c in toAdd) host.Controls.Add(c);
        }

        private void FilterNav(string term)
        {
            term = (term ?? "").Trim();
            foreach (Control c in _sidebarContent.Controls)
            {
                if (c is SidebarNavButton b)
                    b.Visible = string.IsNullOrEmpty(term) || b.Label.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0;
                else if (c is SidebarSectionLabel)
                    c.Visible = string.IsNullOrEmpty(term);
            }
        }

        private void NavigateTo(string key)
        {
            if (!_pageFactories.ContainsKey(key)) return;
            _currentKey = key;

            if (!_pageCache.TryGetValue(key, out var page))
            {
                page = _pageFactories[key]();
                _pageCache[key] = page;
            }

            _content.Controls.Clear();
            _content.Controls.Add(page);

            var match = NavItems.FirstOrDefault(n => n.key == key);
            _pageTitle.Text = match.label ?? key;
            _statusBar.Text = " Loaded: " + (match.label ?? key);

            foreach (var b in _navButtons) { b.Selected = (string)b.PageKey == key; b.Invalidate(); }
        }

        private void ApplyThemeToShell()
        {
            this.BackColor = Theme.Background;
            _sidebar.BackColor = Theme.Surface;
            _statusBar.BackColor = Theme.Surface;
            _statusBar.ForeColor = Theme.Text;
            _pageTitle.ForeColor = Theme.Text;
            BuildNavButtons(_sidebarContent);
            foreach (var b in _navButtons) b.Selected = (string)b.PageKey == _currentKey;
            _sidebarContent.Invalidate(true);
        }
    }
}