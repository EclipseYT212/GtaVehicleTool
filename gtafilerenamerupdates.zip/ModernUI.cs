#nullable disable
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace GtaFileRenamer
{
    // =========================================================================
    //  ModernUI — palette, spacing and reusable controls for the sidebar shell.
    //  This sits alongside the existing Theme class (Theme.cs) and reuses its
    //  colors so ToggleTheme() still flips everything at once. Nothing here
    //  replaces Theme — it only adds shape/behavior (rounded corners, hover
    //  states, spacing) on top of the same color values.
    // =========================================================================
    internal static class ModernUI
    {
        // ── Spacing scale — use these instead of magic numbers when laying
        //    out new panels, so spacing stays consistent across the app. ──────
        public static class Space
        {
            public const int XS = 4, S = 8, M = 12, L = 20, XL = 32;
        }

        public const int CardRadius = 10;
        public const int ButtonRadius = 8;
        public const int SidebarWidth = 232;
        public const int SidebarCollapsedWidth = 60;
        public const int TopBarHeight = 56;

        public static Color ShadowColor => Theme.IsDark
            ? Color.FromArgb(60, 0, 0, 0)
            : Color.FromArgb(30, 0, 0, 0);

        public static Font FontTitle = new Font("Segoe UI Semibold", 15f, FontStyle.Bold);
        public static Font FontSection = new Font("Segoe UI Semibold", 10f, FontStyle.Bold);
        public static Font FontBody = new Font("Segoe UI", 9f);
        public static Font FontSmall = new Font("Segoe UI", 8f);

        // ── Rounded-rect path helper, shared by all custom-painted controls ───
        public static GraphicsPath RoundedRect(Rectangle bounds, int radius)
        {
            int d = radius * 2;
            var path = new GraphicsPath();
            if (d <= 0) { path.AddRectangle(bounds); return path; }
            path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        public static Color Lerp(Color a, Color b, float t)
        {
            t = Math.Max(0, Math.Min(1, t));
            return Color.FromArgb(
                (int)(a.A + (b.A - a.A) * t),
                (int)(a.R + (b.R - a.R) * t),
                (int)(a.G + (b.G - a.G) * t),
                (int)(a.B + (b.B - a.B) * t));
        }

        // ── Toast notification — small fading popup in the corner of a form,
        //    used for "Saved", "Built", "Copied", quick confirmations, etc.
        //    instead of a blocking MessageBox for low-stakes feedback. ────────
        public static void ShowToast(Form owner, string message, ToastKind kind = ToastKind.Info)
        {
            if (owner == null) return;
            var color = kind switch
            {
                ToastKind.Success => Theme.Success,
                ToastKind.Warning => Theme.Warning,
                ToastKind.Error => Theme.Danger,
                _ => Theme.Accent
            };

            var toast = new Form
            {
                FormBorderStyle = FormBorderStyle.None,
                ShowInTaskbar = false,
                StartPosition = FormStartPosition.Manual,
                BackColor = Theme.Surface2,
                Opacity = 0,
                Size = new Size(320, 52),
                TopMost = true,
            };
            var strip = new Panel { Dock = DockStyle.Left, Width = 4, BackColor = color };
            var lbl = new Label
            {
                Text = message,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(14, 0, 10, 0),
                ForeColor = Theme.Text,
                Font = FontBody,
            };
            toast.Controls.Add(lbl);
            toast.Controls.Add(strip);

            var wa = Screen.FromControl(owner).WorkingArea;
            toast.Location = new Point(wa.Right - toast.Width - 24, wa.Bottom - toast.Height - 24);
            toast.Show(owner);

            var fadeIn = new Timer { Interval = 15 };
            fadeIn.Tick += (s, e) =>
            {
                toast.Opacity += 0.12;
                if (toast.Opacity >= 0.97) { toast.Opacity = 0.97; fadeIn.Stop(); fadeIn.Dispose(); }
            };
            fadeIn.Start();

            var hold = new Timer { Interval = 2200 };
            hold.Tick += (s, e) =>
            {
                hold.Stop(); hold.Dispose();
                var fadeOut = new Timer { Interval = 15 };
                fadeOut.Tick += (s2, e2) =>
                {
                    toast.Opacity -= 0.12;
                    if (toast.Opacity <= 0) { fadeOut.Stop(); fadeOut.Dispose(); toast.Close(); toast.Dispose(); }
                };
                fadeOut.Start();
            };
            hold.Start();
        }

        public enum ToastKind { Info, Success, Warning, Error }
    }

    // =========================================================================
    //  RoundedButton — flat button with rounded corners and a smooth hover/
    //  press color transition. Drop-in replacement anywhere Theme.MakeButton
    //  was used; call RoundedButton.Make(...) the same way.
    // =========================================================================
    internal class RoundedButton : Button
    {
        public int Radius { get; set; } = ModernUI.ButtonRadius;
        public bool IsPrimary { get; set; }
        private float _hoverT = 0f;
        private readonly Timer _anim;

        public RoundedButton()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            Cursor = Cursors.Hand;
            _anim = new Timer { Interval = 12 };
            _anim.Tick += (s, e) =>
            {
                float target = ClientRectangle.Contains(PointToClient(MousePosition)) ? 1f : 0f;
                _hoverT += (target - _hoverT) * 0.35f;
                if (Math.Abs(target - _hoverT) < 0.01f) { _hoverT = target; _anim.Stop(); }
                Invalidate();
            };
            MouseEnter += (s, e) => { if (!_anim.Enabled) _anim.Start(); };
            MouseLeave += (s, e) => { if (!_anim.Enabled) _anim.Start(); };
        }

        public static RoundedButton Make(string text, int width, int height = 30, bool isPrimary = false)
        {
            var b = new RoundedButton
            {
                Text = text,
                Width = width,
                Height = height,
                IsPrimary = isPrimary,
                ForeColor = isPrimary ? Color.White : Theme.Text,
                Font = isPrimary ? new Font("Segoe UI", 9f, FontStyle.Bold) : new Font("Segoe UI", 9f),
            };
            return b;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            var baseColor = IsPrimary ? Theme.Accent : Theme.Surface2;
            var hoverColor = IsPrimary ? ModernUI.Lerp(Theme.Accent, Color.White, 0.15f) : Theme.Border;
            var fill = ModernUI.Lerp(baseColor, hoverColor, _hoverT);
            if (!Enabled) fill = ModernUI.Lerp(baseColor, Theme.Background, 0.5f);

            var rect = new Rectangle(0, 0, Width - 1, Height - 1);
            using var path = ModernUI.RoundedRect(rect, Radius);
            using var brush = new SolidBrush(fill);
            e.Graphics.FillPath(brush, path);
            if (!IsPrimary)
            {
                using var pen = new Pen(Theme.Border);
                e.Graphics.DrawPath(pen, path);
            }
            TextRenderer.DrawText(e.Graphics, Text, Font, rect, Enabled ? ForeColor : Theme.Muted,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }
    }

    // =========================================================================
    //  Card — rounded panel with a subtle border, used to group related
    //  controls (replaces plain Panels for anything meant to read as a
    //  distinct "block" in the new layout, e.g. a vehicle detail section).
    // =========================================================================
    internal class Card : Panel
    {
        public int Radius { get; set; } = ModernUI.CardRadius;
        public string Title { get; set; }

        public Card()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Color.Transparent;
            Padding = new Padding(ModernUI.Space.L, string.IsNullOrEmpty(Title) ? ModernUI.Space.L : 40, ModernUI.Space.L, ModernUI.Space.L);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            var rect = new Rectangle(0, 0, Width - 1, Height - 1);
            using var path = ModernUI.RoundedRect(rect, Radius);
            using var fill = new SolidBrush(Theme.Surface);
            e.Graphics.FillPath(fill, path);
            using var pen = new Pen(Theme.Border);
            e.Graphics.DrawPath(pen, path);

            if (!string.IsNullOrEmpty(Title))
            {
                using var titleBrush = new SolidBrush(Theme.Accent);
                e.Graphics.DrawString(Title, ModernUI.FontSection, titleBrush, ModernUI.Space.L, ModernUI.Space.M);
            }
        }
    }

    // =========================================================================
    //  SidebarNavButton — one entry in the left navigation rail. Shows an
    //  icon glyph + label, and a highlighted pill/indicator when selected.
    // =========================================================================
    internal class SidebarNavButton : Panel
    {
        public string Glyph { get; }
        public string Label { get; }
        public object PageKey { get; }
        public bool Selected { get; set; }
        public event Action<SidebarNavButton> Clicked;
        private bool _hover;

        public SidebarNavButton(string glyph, string label, object pageKey)
        {
            Glyph = glyph; Label = label; PageKey = pageKey;
            Height = 38;
            Dock = DockStyle.Top;
            Cursor = Cursors.Hand;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            MouseEnter += (s, e) => { _hover = true; Invalidate(); };
            MouseLeave += (s, e) => { _hover = false; Invalidate(); };
            Click += (s, e) => Clicked?.Invoke(this);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Color bg = Selected ? Theme.AccentDim : (_hover ? Theme.Surface2 : Color.Transparent);
            if (bg != Color.Transparent)
            {
                var rect = new Rectangle(8, 2, Width - 16, Height - 4);
                using var path = ModernUI.RoundedRect(rect, 8);
                using var brush = new SolidBrush(bg);
                e.Graphics.FillPath(brush, path);
            }
            if (Selected)
            {
                using var accentBrush = new SolidBrush(Theme.Accent);
                var accentRect = new Rectangle(0, 8, 3, Height - 16);
                using var accentPath = ModernUI.RoundedRect(accentRect, 2);
                e.Graphics.FillPath(accentBrush, accentPath);

                // Subtle glow behind the glyph on the selected item — a
                // small, low-risk polish touch rather than a full
                // animation system (which would need a Timer and more
                // surface area to get wrong for not much visible gain
                // on a static icon).
                using var glowBrush = new SolidBrush(Color.FromArgb(40, Theme.Accent.R, Theme.Accent.G, Theme.Accent.B));
                e.Graphics.FillEllipse(glowBrush, 10, (Height - 28) / 2f, 28, 28);
            }

            var fg = Selected ? Theme.Accent : Theme.TextDim;
            using var glyphBrush = new SolidBrush(fg);
            e.Graphics.DrawString(Glyph, new Font("Segoe UI Emoji", 11f), glyphBrush, 18, (Height - 18) / 2f);
            using var textBrush = new SolidBrush(Selected ? Theme.Text : fg);
            e.Graphics.DrawString(Label, Selected ? new Font("Segoe UI", 9.5f, FontStyle.Bold) : new Font("Segoe UI", 9.5f),
                textBrush, 46, (Height - 16) / 2f);
        }
    }

    // =========================================================================
    //  SidebarSectionLabel — small uppercase group header ("VEHICLE TOOLS")
    // =========================================================================
    internal class SidebarSectionLabel : Label
    {
        public SidebarSectionLabel(string text)
        {
            Text = text.ToUpperInvariant();
            Dock = DockStyle.Top;
            Height = 30;
            Padding = new Padding(18, 12, 0, 0);
            Font = new Font("Segoe UI", 7.5f, FontStyle.Bold);
            ForeColor = Theme.Muted;
        }
    }

    // =========================================================================
    //  ArchiveStatusIndicator — small always-visible strip showing whether
    //  update.rpf is currently a loose override folder (dlclist.xml edits
    //  just work, no repack risk) or a packed archive (needs the manual
    //  OpenIV path, or a one-time safe conversion). Meant to be dropped at
    //  the top of any panel that cares about this (DLC Manager, Test/Inject
    //  Addon) so the current state is visible before the person tries an
    //  action that depends on it, rather than discovering it via a failed
    //  operation. Call Refresh(gtaRoot) whenever the panel loads or the GTA
    //  folder changes — it does not poll or watch the filesystem itself.
    // =========================================================================
    internal class ArchiveStatusIndicator : Panel
    {
        private readonly Label _lbl;

        public ArchiveStatusIndicator()
        {
            Dock = DockStyle.Top;
            Height = 26;
            _lbl = new Label
            {
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(10, 0, 0, 0),
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
            };
            Controls.Add(_lbl);
            Refresh(null);
        }

        public void Refresh(string gtaRoot)
        {
            string updateRpfPath = string.IsNullOrEmpty(gtaRoot)
                ? null
                : System.IO.Path.Combine(gtaRoot, "mods", "update", "update.rpf");

            if (string.IsNullOrEmpty(gtaRoot))
            {
                _lbl.Text = "❓  No GTA folder set yet";
                _lbl.ForeColor = Theme.Muted;
                BackColor = Theme.Surface2;
            }
            else if (System.IO.Directory.Exists(updateRpfPath))
            {
                _lbl.Text = "🟢  update.rpf is a LOOSE folder — dlclist.xml edits save directly, no repack risk";
                _lbl.ForeColor = Theme.Success;
                BackColor = Theme.Surface2;
            }
            else if (System.IO.File.Exists(updateRpfPath))
            {
                _lbl.Text = "📦  update.rpf is a PACKED archive — dlclist.xml edits need manual OpenIV, or a one-time conversion";
                _lbl.ForeColor = Theme.Warning;
                BackColor = Theme.Surface2;
            }
            else
            {
                _lbl.Text = "❓  update.rpf not found at the current GTA folder";
                _lbl.ForeColor = Theme.Muted;
                BackColor = Theme.Surface2;
            }
        }
    }
}
