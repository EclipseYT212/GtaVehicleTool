#nullable disable
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GtaFileRenamer
{
    // =========================================================================
    //  Theme system
    // =========================================================================

    internal static class Theme
    {
        public static Color Background = Color.FromArgb(18, 18, 22);
        public static Color Surface = Color.FromArgb(28, 28, 36);
        public static Color Surface2 = Color.FromArgb(38, 38, 48);
        public static Color Border = Color.FromArgb(55, 55, 72);
        public static Color Accent = Color.FromArgb(82, 130, 255);
        public static Color AccentDim = Color.FromArgb(40, 70, 150);
        public static Color Success = Color.FromArgb(52, 211, 130);
        public static Color Warning = Color.FromArgb(255, 178, 50);
        public static Color Danger = Color.FromArgb(235, 75, 75);
        public static Color Text = Color.FromArgb(225, 225, 235);
        public static Color TextDim = Color.FromArgb(145, 145, 165);
        public static Color Muted = Color.FromArgb(90, 90, 110);
        public static Color GroupBg = Color.FromArgb(32, 38, 58);
        public static Color FiveMBg = Color.FromArgb(45, 30, 65);
        public static Color SPBg = Color.FromArgb(28, 52, 38);
        public static Color LinkedBg = Color.FromArgb(52, 48, 28);
        public static Color ListBg = Color.FromArgb(22, 22, 28);
        public static Color TagVehicle = Color.FromArgb(30, 60, 100);
        public static Color TagCloth = Color.FromArgb(55, 30, 75);
        public static Color TagPed = Color.FromArgb(20, 65, 50);
        public static bool IsDark = true;

        public static event Action ThemeChanged;

        public static void ToggleTheme()
        {
            if (IsDark)
            {
                Background = Color.FromArgb(243, 244, 248);
                Surface = Color.FromArgb(255, 255, 255);
                Surface2 = Color.FromArgb(246, 246, 250);
                Border = Color.FromArgb(205, 205, 218);
                Accent = Color.FromArgb(60, 100, 230);
                AccentDim = Color.FromArgb(180, 200, 255);
                Success = Color.FromArgb(18, 155, 80);
                Warning = Color.FromArgb(190, 115, 0);
                Danger = Color.FromArgb(195, 40, 40);
                Text = Color.FromArgb(25, 25, 38);
                TextDim = Color.FromArgb(80, 80, 100);
                Muted = Color.FromArgb(140, 140, 165);
                GroupBg = Color.FromArgb(225, 233, 248);
                FiveMBg = Color.FromArgb(238, 225, 248);
                SPBg = Color.FromArgb(220, 242, 230);
                LinkedBg = Color.FromArgb(248, 242, 215);
                ListBg = Color.FromArgb(250, 250, 253);
                TagVehicle = Color.FromArgb(210, 225, 248);
                TagCloth = Color.FromArgb(235, 218, 248);
                TagPed = Color.FromArgb(210, 242, 228);
                IsDark = false;
            }
            else
            {
                Background = Color.FromArgb(18, 18, 22);
                Surface = Color.FromArgb(28, 28, 36);
                Surface2 = Color.FromArgb(38, 38, 48);
                Border = Color.FromArgb(55, 55, 72);
                Accent = Color.FromArgb(82, 130, 255);
                AccentDim = Color.FromArgb(40, 70, 150);
                Success = Color.FromArgb(52, 211, 130);
                Warning = Color.FromArgb(255, 178, 50);
                Danger = Color.FromArgb(235, 75, 75);
                Text = Color.FromArgb(225, 225, 235);
                TextDim = Color.FromArgb(145, 145, 165);
                Muted = Color.FromArgb(90, 90, 110);
                GroupBg = Color.FromArgb(32, 38, 58);
                FiveMBg = Color.FromArgb(45, 30, 65);
                SPBg = Color.FromArgb(28, 52, 38);
                LinkedBg = Color.FromArgb(52, 48, 28);
                ListBg = Color.FromArgb(22, 22, 28);
                TagVehicle = Color.FromArgb(30, 60, 100);
                TagCloth = Color.FromArgb(55, 30, 75);
                TagPed = Color.FromArgb(20, 65, 50);
                IsDark = true;
            }
            ThemeChanged?.Invoke();
        }

        public static Button MakeButton(string text, int width, int height = 26, bool isPrimary = false)
        {
            var b = new Button
            {
                Text = text,
                Width = width,
                Height = height,
                BackColor = isPrimary ? Accent : Surface2,
                ForeColor = isPrimary ? Color.White : Text,
                FlatStyle = FlatStyle.Flat,
                Font = isPrimary ? new Font("Segoe UI", 8.5f, FontStyle.Bold)
                                       : new Font("Segoe UI", 8.5f),
                Cursor = Cursors.Hand,
            };
            b.FlatAppearance.BorderColor = isPrimary ? Accent : Border;
            b.FlatAppearance.BorderSize = isPrimary ? 0 : 1;
            return b;
        }

        public static Label MakeLabel(string text, bool muted = false) =>
            new Label
            {
                Text = text,
                AutoSize = true,
                ForeColor = muted ? Muted : TextDim,
                Font = new Font("Segoe UI", 8f)
            };

        public static TextBox MakeTextBox(string placeholder = "", int width = 200) =>
            new TextBox
            {
                Width = width,
                BackColor = Background,
                ForeColor = Text,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 9f),
                PlaceholderText = placeholder
            };
    }

    // =========================================================================
    //  Enums & data model
    // =========================================================================

    internal enum FormatMode { None, FiveMToSP, SPToFiveM }

    internal class FileGroup
    {
        public string Key { get; }
        public string Extension { get; }
        public List<string> Paths { get; } = new List<string>();
        public string TargetNumber { get; set; } = "";
        public FormatMode ConvertMode { get; set; } = FormatMode.None;
        public string FiveMPrefix { get; set; } = "";
        public string ComponentRoot { get; set; } = "";
        public string DominantNumber { get; set; } = "";
        public string VariantNumber { get; set; } = "";
        public bool Collapsed { get; set; } = false;
        public FileGroup(string key, string ext) { Key = key; Extension = ext; }
    }

    // =========================================================================
    //  Rename history for undo
    // =========================================================================

    internal class RenameOperation
    {
        public DateTime Timestamp { get; } = DateTime.Now;
        public List<(string OldPath, string NewPath)> Renames { get; } = new List<(string, string)>();
        public int SuccessCount => Renames.Count;
    }

    internal static class RenameHistory
    {
        private static readonly Stack<RenameOperation> _history = new Stack<RenameOperation>();
        public static bool CanUndo => _history.Count > 0;
        public static int Count => _history.Count;
        public static void Push(RenameOperation op) => _history.Push(op);
        public static RenameOperation Peek() => _history.Count > 0 ? _history.Peek() : null;
        public static RenameOperation Pop() => _history.Pop();

        public static string UndoButtonText => CanUndo
            ? $"↩ Undo ({_history.Peek().SuccessCount} files, {_history.Peek().Timestamp:HH:mm:ss})"
            : "↩ Undo";
    }

    // =========================================================================
    //  EUP Package converter – data model
    // =========================================================================

    internal class EupConvertEntry
    {
        public string SourcePath { get; set; }
        public string OutputName { get; set; }
        public bool WillChange { get; set; }
        public bool Skip { get; set; }
        public string SkipReason { get; set; }
        public bool IsBinary { get; set; }
    }

    // =========================================================================
    //  FiveM ↔ SP conversion helper
    // =========================================================================

    internal static class FormatConverter
    {
        private static readonly Regex FiveMCaretPattern =
            new Regex(@"^.+\^(.+)$", RegexOptions.IgnoreCase);
        private static readonly Regex FiveMUnderscorePattern =
            new Regex(@"^(?:mp_[mf]_freemode_\d+(?:_\w+?)*)_((?:head|berd|hair|uppr|lowr|hand|feet|teef|accs|task|decl|jbib|p_).+)$",
                RegexOptions.IgnoreCase);
        private static readonly Regex FiveMPrefixAny =
            new Regex(@"^(mp_[mf]_freemode_\d+(?:_\w+?)*)[_\^]", RegexOptions.IgnoreCase);
        private static readonly Regex ContentCaretRef =
            new Regex(@"mp_[mf]_freemode_\d+\^", RegexOptions.IgnoreCase);

        public static string DetectFiveMPrefix(string fileNameNoExt)
            => FiveMPrefixAny.Match(fileNameNoExt) is { Success: true } m ? m.Groups[1].Value : null;

        public static string ToSP(string fileNameNoExt)
        {
            var m = FiveMCaretPattern.Match(fileNameNoExt);
            if (m.Success) return m.Groups[1].Value;
            m = FiveMUnderscorePattern.Match(fileNameNoExt);
            if (m.Success) return m.Groups[1].Value;
            return fileNameNoExt;
        }

        public static string ToFiveM(string fileNameNoExt, string prefix) => $"{prefix}_{fileNameNoExt}";

        public static string PatchXmlContent(string content) => ContentCaretRef.Replace(content, "");

        public static bool IsBinaryFile(string filePath)
        {
            try
            {
                var header = new byte[4]; int read;
                using (var fs = File.OpenRead(filePath)) read = fs.Read(header, 0, 4);
                if (read < 4) return false;
                if (header[0] == 0x52 && header[1] == 0x53 && header[2] == 0x43 && header[3] == 0x37) return true;
                if (header[0] == 0x50 && header[1] == 0x53 && header[2] == 0x40) return true;
                return false;
            }
            catch { return false; }
        }

        public static void PatchAndWriteXmlFile(string sourcePath, string destPath)
        {
            var raw = File.ReadAllBytes(sourcePath);
            Encoding enc; int bomLen;
            if (raw.Length >= 3 && raw[0] == 0xEF && raw[1] == 0xBB && raw[2] == 0xBF)
            { enc = new UTF8Encoding(true); bomLen = 3; }
            else if (raw.Length >= 2 && raw[0] == 0xFF && raw[1] == 0xFE)
            { enc = new UnicodeEncoding(false, true); bomLen = 2; }
            else if (raw.Length >= 2 && raw[0] == 0xFE && raw[1] == 0xFF)
            { enc = new UnicodeEncoding(true, true); bomLen = 2; }
            else
            { enc = new UTF8Encoding(false); bomLen = 0; }
            var content = enc.GetString(raw, bomLen, raw.Length - bomLen);
            var patched = PatchXmlContent(content);
            File.WriteAllBytes(destPath, enc.GetPreamble().Concat(enc.GetBytes(patched)).ToArray());
        }

        public static readonly string[] KnownPrefixes = {
            "mp_f_freemode_01", "mp_m_freemode_01",
            "mp_f_freemode_02", "mp_m_freemode_02",
            "mp_f_freemode_03", "mp_m_freemode_03",
        };
    }

    // =========================================================================
    //  Component-slot registry
    // =========================================================================

    internal static class ComponentSlots
    {
        public static readonly string[] Roots = {
            "head","berd","hair","uppr","lowr","hand","feet","teef","accs","task","decl","jbib",
        };

        public static string Detect(string skeletonKey)
        {
            var lower = skeletonKey.ToLowerInvariant();
            // FiveM names use '^' as a component separator (e.g.
            // mp_f_freemode_01^jbib_diff_001_a_uni.ytd) just as often as '_'
            // — the original regex only recognized '_' or start-of-string as
            // a valid boundary before/after the slot name, so it silently
            // failed to detect the slot at all on any caret-separated FiveM
            // file, which is most of them.
            return Roots.OrderByDescending(r => r.Length)
                        .FirstOrDefault(r => Regex.IsMatch(lower, @"(^|_|\^)" + Regex.Escape(r) + @"(_|$|\.|\^)")) ?? "";
        }

        public static string DominantNumber(FileGroup grp)
        {
            var rx = new Regex(@"\d+");
            return grp.Paths
                .SelectMany(p => rx.Matches(Path.GetFileNameWithoutExtension(p)).Cast<Match>().Select(m => m.Value))
                .GroupBy(n => n).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault() ?? "";
        }

        public static string ToCompEnum(string slot)
        {
            switch (slot.ToUpperInvariant())
            {
                case "HEAD": return "PED_COMP_HEAD";
                case "BERD": return "PED_COMP_BEARD";
                case "HAIR": return "PED_COMP_HAIR";
                case "UPPR": return "PED_COMP_UPPR";
                case "LOWR": return "PED_COMP_LOWR";
                case "HAND": return "PED_COMP_HAND";
                case "FEET": return "PED_COMP_FEET";
                case "TEEF": return "PED_COMP_TEETH";
                case "ACCS": return "PED_COMP_ACCS";
                case "TASK": return "PED_COMP_TASK";
                case "DECL": return "PED_COMP_DECL";
                case "JBIB": return "PED_COMP_JBIB";
                default: return $"PED_COMP_{slot.ToUpperInvariant()}";
            }
        }
    }

    // =========================================================================
    //  EUP Package Converter logic
    // =========================================================================

    internal static class EupConverter
    {
        private static readonly HashSet<string> SkipNames =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "fxmanifest.lua", "__resource.lua", "content.xml", "setup2.xml" };
        private static readonly HashSet<string> SkipExtensions =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".lua" };
        private static readonly HashSet<string> PatchableExtensions =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".ymt", ".meta", ".xml" };

        public static List<EupConvertEntry> Scan(string resourceRoot, string excludeDir = null)
        {
            // Normalise exclusion path so prefix-check works regardless of trailing slash
            string excludeNorm = string.IsNullOrEmpty(excludeDir)
                ? null
                : excludeDir.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                            + Path.DirectorySeparatorChar;

            var entries = new List<EupConvertEntry>();
            foreach (var file in Directory.GetFiles(resourceRoot, "*.*", SearchOption.AllDirectories))
            {
                // Skip any file that lives inside the output directory (e.g. SP_Converted_Output)
                if (excludeNorm != null &&
                    file.StartsWith(excludeNorm, StringComparison.OrdinalIgnoreCase))
                    continue;

                var name = Path.GetFileName(file);
                var ext = Path.GetExtension(file);
                if (SkipExtensions.Contains(ext) || SkipNames.Contains(name))
                { entries.Add(new EupConvertEntry { SourcePath = file, OutputName = name, Skip = true, SkipReason = "FiveM-only" }); continue; }
                var baseName = Path.GetFileNameWithoutExtension(name);
                var outputBase = FormatConverter.ToSP(baseName);
                var outputName = outputBase + ext;

                // Sort clothing component/prop files into clothing/ and _p/
                // subfolders automatically. Only applies to .ydd/.ytd whose
                // name matches the clothing slot_idx_gender convention
                // (DlcBuilder.YddPattern/YtdPattern, already used elsewhere
                // for clothing detection) — vehicle .ytd files never match
                // this pattern, so they're never miscategorized; everything
                // else (meta files, .yft, etc.) stays exactly where it was.
                if ((ext.Equals(".ydd", StringComparison.OrdinalIgnoreCase) ||
                     ext.Equals(".ytd", StringComparison.OrdinalIgnoreCase)) &&
                    (DlcBuilder.YddPattern.IsMatch(outputBase) || DlcBuilder.YtdPattern.IsMatch(outputBase)))
                {
                    string subfolder = outputBase.StartsWith("p_", StringComparison.OrdinalIgnoreCase) ? "_p" : "clothing";
                    outputName = subfolder + "/" + outputName;
                }

                bool isBinary = PatchableExtensions.Contains(ext) && FormatConverter.IsBinaryFile(file);
                entries.Add(new EupConvertEntry
                {
                    SourcePath = file,
                    OutputName = outputName,
                    WillChange = !string.Equals(name, outputName, StringComparison.OrdinalIgnoreCase),
                    Skip = false,
                    IsBinary = isBinary
                });
            }
            return entries;
        }

        public static (int copied, int skipped, int failed, List<string> binaryWarnings) Execute(
            List<EupConvertEntry> entries, string outputDir, bool overwrite,
            Action<int, string> progress, ref bool cancel)
        {
            Directory.CreateDirectory(outputDir);
            int copied = 0, skipped = 0, failed = 0, done = 0;
            var binaryWarnings = new List<string>();
            foreach (var e in entries)
            {
                if (cancel) break;
                done++;
                if (e.Skip) { skipped++; progress(done, e.OutputName); continue; }
                var dest = Path.Combine(outputDir, e.OutputName);
                try
                {
                    if (File.Exists(dest) && !overwrite) { skipped++; progress(done, e.OutputName); continue; }
                    // OutputName may now include a clothing/ or _p/ subfolder
                    // prefix (see Scan's sorting above) — without this, the
                    // write below throws DirectoryNotFoundException, silently
                    // swallowed by the catch further down, exactly the kind
                    // of invisible failure that bit us with the progress
                    // callback null-check earlier in this conversation.
                    var destDir = Path.GetDirectoryName(dest);
                    if (!string.IsNullOrEmpty(destDir)) Directory.CreateDirectory(destDir);
                    var ext = Path.GetExtension(e.SourcePath);
                    if (PatchableExtensions.Contains(ext) && !e.IsBinary)
                        FormatConverter.PatchAndWriteXmlFile(e.SourcePath, dest);
                    else
                    {
                        File.Copy(e.SourcePath, dest, overwrite: true);
                        if (e.IsBinary && PatchableExtensions.Contains(ext)) binaryWarnings.Add(e.OutputName);
                    }
                    copied++;
                }
                catch { failed++; }
                progress(done, e.OutputName);
            }
            return (copied, skipped, failed, binaryWarnings);
        }
    }

    // =========================================================================
    //  DLC builder – clothing data model & logic
    // =========================================================================

    internal class DlcDrawable
    {
        public string SlotRoot { get; set; }
        public int DrawableIndex { get; set; }
        public string YddName { get; set; }
        public List<string> YtdNames { get; set; } = new List<string>();
    }

    internal class DlcBuildSettings
    {
        public string PedName { get; set; }
        public string DlcName { get; set; }
        public string OutputRoot { get; set; }
        public List<DlcDrawable> Drawables { get; set; } = new List<DlcDrawable>();
    }

    internal class VehicleEntry
    {
        public string SpawnName { get; set; }
        public bool HasHiModel { get; set; }
        public List<string> YtdNames { get; set; } = new List<string>();
    }

    internal class VehicleDlcBuildSettings
    {
        public string DlcName { get; set; }
        public string OutputRoot { get; set; }
        public List<VehicleEntry> Vehicles { get; set; } = new List<VehicleEntry>();
        public List<string> MetaFiles { get; set; } = new List<string>();

        // Set by the user in VehicleDlcDialog, but only when a vehicle is
        // actually detected. Controls whether RpfPackager generates/writes
        // any ELS files for this build at all.
        public bool IsElsVehicle { get; set; } = false;

        // Siren preset / light config applied to every detected vehicle in
        // this batch. Without this, carcols.meta, vehicles.meta and the ELS
        // xml all fall back to SirenPreset.None and no lights/sirens get
        // generated at all — only set per-vehicle detail (engine audio bank,
        // horn) survives, which is why those still worked while lights/sirens
        // silently didn't.
        public VehicleLightAudioConfig LightAudioConfig { get; set; } = new VehicleLightAudioConfig();

        // When true, carcols.meta is regenerated from LightAudioConfig even
        // if the source folder already supplied its own carcols.meta. Most
        // FiveM vehicle packs ship one, which previously meant the siren
        // preset chosen above was silently ignored (the auto-generate block
        // only fires when carcols.meta is *missing*). vehicles.meta is
        // deliberately NOT force-regenerated — it carries model-specific
        // data (bound offsets, wheel positions, txd names) that the
        // generator can't reproduce, and overwriting it risks breaking a
        // vehicle that currently loads/drives correctly.
        public bool RegenerateCarcols { get; set; } = true;

        // Set only when the vehicle came from "Load dlc.rpf" (extracting an
        // existing archive), not "Browse Folder" (loose files). Loose .yft/
        // .ytd files never get decompressed by this tool at all, so copying
        // them into the new vehicles.rpf is always safe. Files extracted
        // from an existing archive go through RpfFile's decompress/recompress
        // round-trip, which — after three separate evidence-based attempts
        // this session — still doesn't reliably reproduce a valid resource
        // file (confirmed via direct OpenIV comparison: header recognized,
        // but payload still reported as corrupt). When this is set, the
        // build skips attempting that copy entirely and instead gives exact
        // manual OpenIV instructions, which is the one method actually
        // confirmed to work.
        public string SourceDlcRpfPath { get; set; }
    }

    // =========================================================================
    //  Vehicle categories / Ped tables
    // =========================================================================

    internal static class VehicleCategories
    {
        public static readonly string[] All = {
            "Compacts","Sedans","SUVs","Coupes","Muscle","SportsClassics","Sports","Super",
            "Motorcycles","OffRoad","Industrial","Utility","Vans","Cycles","Boats",
            "Helicopters","Planes","Service","Emergency","Military","Commercial","Trains",
        };
    }

    internal static class PedTables
    {
        public static readonly string[] PedTypes = {
            "PED_TYPE_CIVMALE","PED_TYPE_CIVFEMALE","PED_TYPE_COP",
            "PED_TYPE_GANG_ALBANIAN","PED_TYPE_GANG_BIKER_1","PED_TYPE_GANG_BIKER_2",
            "PED_TYPE_GANG_ITALIAN","PED_TYPE_GANG_RUSSIAN","PED_TYPE_GANG_RUSSIAN_2",
            "PED_TYPE_GANG_IRISH","PED_TYPE_GANG_JAMAICAN","PED_TYPE_GANG_AFRICAN_AMERICAN",
            "PED_TYPE_GANG_KOREAN","PED_TYPE_GANG_CHINESE_JAPANESE","PED_TYPE_GANG_PUERTO_RICAN",
            "PED_TYPE_DEALER","PED_TYPE_MEDIC","PED_TYPE_FIREMAN","PED_TYPE_CRIMINAL",
            "PED_TYPE_BUM","PED_TYPE_PROSTITUTE","PED_TYPE_SPECIAL","PED_TYPE_MISSION",
            "PED_TYPE_SWAT","PED_TYPE_ANIMAL","PED_TYPE_ARMY",
        };
        public static readonly string[] Movements = {
            "move_m@generic","move_f@generic","move_m@casual@a","move_f@casual@a",
            "move_cop","move_m@drunk@a","move_m@fat@a","move_m@brave@a","move_m@scared@a",
            "move_m@injured","move_m@shadyped@a","move_m@suited@a","move_f@heels@a",
            "move_f@sexy@a","move_f@business@a","move_m@jog@","move_m@sprint",
            "move_m@homeless@a","move_m@gangster@ng","move_gang_crips@a",
        };
        public static readonly string[] Personalities = {
            "CIVMALE","CIVFEMALE","COP","SWAT","ARMY","FIREMAN","MEDIC",
            "GANG_1","GANG_2","DEALER","PROSTITUTE","BUM","CRIMINAL","HATER",
        };
    }

    // =========================================================================
    //  Addon data models
    // =========================================================================

    internal class ColorVariation
    {
        public int Primary { get; set; }
        public int Secondary { get; set; }
        public int Pearl { get; set; }
        public int Wheel { get; set; }
    }

    internal class AddonVehicleEntry
    {
        public string SpawnName { get; set; } = "";
        public string ElsName { get; set; } = "";        // ← ADD THIS
        public bool UseEls { get; set; } = false;          // ELS or vanilla sirens
        public string Category { get; set; } = "Compacts";
        public string MakeName { get; set; } = "MAKE_GENERIC";
        public string GameName { get; set; } = "";
        public string AudioNameHash { get; set; } = "";
        public bool HasHiModel { get; set; }
        public bool HasMods { get; set; }
        public bool HasAudio { get; set; }
        public List<ColorVariation> ColorVariations { get; set; } = new List<ColorVariation>();
        public float Mass { get; set; } = 1500f;
        public float DriveForce { get; set; } = 0.33f;
        public float TopSpeed { get; set; } = 30f;
        public int DriveGears { get; set; } = 6;
        public float BrakeForce { get; set; } = 0.7f;
        public float DriveBias { get; set; } = 0f;

        // ── Extra vehicles.meta fields (previously hardcoded in the generator) ──
        public string VehicleType { get; set; } = "VEHICLE_TYPE_CAR";
        public string Layout { get; set; } = "LAYOUT_STD";
        public string Swankness { get; set; } = "SWANKNESS_4";
        public string PlateType { get; set; } = "VPT_FRONT_AND_BACK_PLATES";
        public int NumWheels { get; set; } = 4;
        public int Hp { get; set; } = 1000;
        public int MaxNum { get; set; } = 10;
    }

    internal class AddonPedEntry
    {
        public string ModelName { get; set; } = "";
        public string PedType { get; set; } = "PED_TYPE_CIVMALE";
        public string Movement { get; set; } = "move_m@generic";
        public string Personality { get; set; } = "CIVMALE";
        public bool IsStreamed { get; set; } = true;

        // ── Extra peds.meta fields (previously hardcoded in the generator) ──
        public string VoiceGroup { get; set; } = "MISSING";
        public string ClipDictionaryName { get; set; } = "move_m@generic";
        public string StrafeClipSet { get; set; } = "CLIPSET_ID_MOVE_STRAFE_WALK";
        public string DefaultSpawnSet { get; set; } = "CIVMALE";
        public string TerrainStateName { get; set; } = "WALKING";
        public bool InheritPropsFromParent { get; set; } = false;
    }

    // =========================================================================
    //  Siren & audio config
    // =========================================================================

    /// <summary>Preset siren light patterns. Maps to a carcols siren block.</summary>
    internal enum SirenPreset
    {
        None,
        PoliceLSPD,
        PoliceFIB,
        Ambulance,
        FireTruck,
        Sheriff,
        Highway,
        Military,
    }

    /// <summary>
    /// Engine audio template. When Inherit is chosen the game borrows the audio
    /// bank of an existing vanilla vehicle (set via AudioInheritFrom).
    /// </summary>
    internal enum AudioPreset
    {
        Inherit,          // Copy from a vanilla spawn name
        FourCylinder,
        SixCylinder,
        V8Muscle,
        V8Luxury,
        V10,
        V12,
        Electric,
        TurboSports,
        PoliceCruiser,
        PoliceInterceptor,
        PoliceRanger,
        AmbulanceTruck,
        FiretruckHeavy,
        BigRig,
        Bus,
        Helicopter,
        Plane,
    }

    /// <summary>Attached per-vehicle to <see cref="AddonCreatorPanel._lightAudioConfigs"/>.</summary>
    internal class VehicleLightAudioConfig
    {
        public SirenPreset SirenPreset { get; set; } = SirenPreset.None;
        public AudioPreset AudioPreset { get; set; } = AudioPreset.FourCylinder;
        /// <summary>Vanilla spawn name to copy audio from (only used when AudioPreset == Inherit).</summary>
        public string AudioInheritFrom { get; set; } = "police";
        /// <summary>Number of rooftop/grille siren lights (1-8).</summary>
        public int SirenCount { get; set; } = 2;
        /// <summary>Primary siren light colour (GTA carcols colour index).</summary>
        public int SirenColor1 { get; set; } = 3;   // red
        /// <summary>Secondary siren light colour.</summary>
        public int SirenColor2 { get; set; } = 56;  // blue
    }

    // =========================================================================
    //  SirenIdResolver
    // =========================================================================

    internal static class SirenIdResolver
    {
        private static readonly Dictionary<SirenPreset, int> Map =
            new Dictionary<SirenPreset, int>
            {
                { SirenPreset.PoliceLSPD, 1 }, { SirenPreset.PoliceFIB,  2 },
                { SirenPreset.Ambulance,  3 }, { SirenPreset.FireTruck,  4 },
                { SirenPreset.Sheriff,    5 }, { SirenPreset.Highway,    6 },
                { SirenPreset.Military,   7 }, { SirenPreset.None,       0 },
            };

        public static int GetId(SirenPreset p) => Map.TryGetValue(p, out int id) ? id : 0;
    }

    // =========================================================================
    //  AddonGenerator  (core meta builders, no siren awareness)
    // =========================================================================

    internal static class AddonGenerator
    {
        // ------------------------------------------------------------------
        //  vehicles.meta  (plain – no siren fields)
        //  Use AddonGeneratorEx.BuildVehiclesMetaWithSirens when you have configs.
        // ------------------------------------------------------------------
        public static string BuildVehiclesMeta(List<AddonVehicleEntry> vehicles)
            => AddonGeneratorEx.BuildVehiclesMetaWithSirens(vehicles, null);

        // ------------------------------------------------------------------
        //  handling.meta
        // ------------------------------------------------------------------
        public static string BuildHandlingMeta(List<AddonVehicleEntry> vehicles)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CHandlingDataMgr>");
            sb.AppendLine("  <HandlingData>");
            foreach (var v in vehicles)
            {
                sb.AppendLine("    <Item type=\"CHandlingData\">");
                sb.AppendLine($"      <handlingName>{v.SpawnName}</handlingName>");
                sb.AppendLine($"      <fMass value=\"{v.Mass:F6}\" />");
                sb.AppendLine($"      <fInitialDragCoeff value=\"6.000000\" />");
                sb.AppendLine($"      <fPercentSubmerged value=\"85.000000\" />");
                sb.AppendLine($"      <vecCentreOfMassOffset x=\"0.000000\" y=\"0.030000\" z=\"0.000000\" />");
                sb.AppendLine($"      <vecInertiaMultiplier x=\"1.100000\" y=\"1.400000\" z=\"1.100000\" />");
                sb.AppendLine($"      <fDriveForce value=\"{v.DriveForce:F6}\" />");
                sb.AppendLine($"      <fInitialDriveGears value=\"{v.DriveGears}\" />");
                sb.AppendLine($"      <fInitialDriveForce value=\"{v.DriveForce:F6}\" />");
                sb.AppendLine($"      <fDriveInertia value=\"1.000000\" />");
                sb.AppendLine($"      <fClutchChangeRateScaleUpShift value=\"2.700000\" />");
                sb.AppendLine($"      <fClutchChangeRateScaleDownShift value=\"2.700000\" />");
                sb.AppendLine($"      <fInitialDriveMaxFlatVel value=\"{v.TopSpeed:F6}\" />");
                sb.AppendLine($"      <fBrakeForce value=\"{v.BrakeForce:F6}\" />");
                sb.AppendLine($"      <fBrakeBiasFront value=\"{v.DriveBias:F6}\" />");
                sb.AppendLine($"      <fHandBrakeForce value=\"0.900000\" />");
                sb.AppendLine($"      <fSteeringLock value=\"35.000000\" />");
                sb.AppendLine($"      <fTractionCurveMax value=\"2.800000\" />");
                sb.AppendLine($"      <fTractionCurveMin value=\"2.470000\" />");
                sb.AppendLine($"      <fTractionCurveLateral value=\"22.500000\" />");
                sb.AppendLine($"      <fTractionSpringDeltaMax value=\"0.150000\" />");
                sb.AppendLine($"      <fLowSpeedTractionLossMult value=\"0.000000\" />");
                sb.AppendLine($"      <fCamberStiffnesss value=\"0.000000\" />");
                sb.AppendLine($"      <fTractionBiasFront value=\"0.472000\" />");
                sb.AppendLine($"      <fTractionLossMult value=\"1.000000\" />");
                sb.AppendLine($"      <fSuspensionForce value=\"2.900000\" />");
                sb.AppendLine($"      <fSuspensionCompDamp value=\"1.200000\" />");
                sb.AppendLine($"      <fSuspensionReboundDamp value=\"2.100000\" />");
                sb.AppendLine($"      <fSuspensionUpperLimit value=\"0.100000\" />");
                sb.AppendLine($"      <fSuspensionLowerLimit value=\"-0.200000\" />");
                sb.AppendLine($"      <fSuspensionRaise value=\"0.020000\" />");
                sb.AppendLine($"      <fSuspensionBiasFront value=\"0.520000\" />");
                sb.AppendLine($"      <fAntiRollBarForce value=\"0.600000\" />");
                sb.AppendLine($"      <fAntiRollBarBiasFront value=\"0.550000\" />");
                sb.AppendLine($"      <fRollCentreHeightFront value=\"0.440000\" />");
                sb.AppendLine($"      <fRollCentreHeightRear value=\"0.380000\" />");
                sb.AppendLine($"      <fCollisionDamageMult value=\"0.700000\" />");
                sb.AppendLine($"      <fWeaponDamageMult value=\"1.000000\" />");
                sb.AppendLine($"      <fDeformationDamageMult value=\"0.600000\" />");
                sb.AppendLine($"      <fEngineDamageMult value=\"1.500000\" />");
                sb.AppendLine($"      <fPetrolTankVolume value=\"65.000000\" />");
                sb.AppendLine($"      <fOilVolume value=\"5.000000\" />");
                sb.AppendLine($"      <fSeatOffsetDistX value=\"0.000000\" />");
                sb.AppendLine($"      <fSeatOffsetDistY value=\"0.000000\" />");
                sb.AppendLine($"      <fSeatOffsetDistZ value=\"0.000000\" />");
                sb.AppendLine($"      <nMonetaryValue value=\"10000\" />");
                sb.AppendLine($"      <strModelFlags>440000</strModelFlags>");
                sb.AppendLine($"      <strHandlingFlags>0</strHandlingFlags>");
                sb.AppendLine($"      <strDamageFlags>0</strDamageFlags>");
                sb.AppendLine($"      <AIHandling>AVERAGE</AIHandling>");
                sb.AppendLine($"      <SubHandlingData><Item type=\"CCarHandlingData\" /></SubHandlingData>");
                sb.AppendLine("    </Item>");
            }
            sb.AppendLine("  </HandlingData>");
            sb.AppendLine("</CHandlingDataMgr>");
            return sb.ToString();
        }

        // ------------------------------------------------------------------
        //  carvariations.meta
        // ------------------------------------------------------------------
        public static string BuildCarVariationsMeta(List<AddonVehicleEntry> vehicles)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CVehicleVariationInfo>");
            sb.AppendLine("  <variationData>");
            foreach (var v in vehicles)
            {
                sb.AppendLine("    <Item>");
                sb.AppendLine($"      <modelName>{v.SpawnName}</modelName>");
                sb.AppendLine("      <colors>");
                var cvs = v.ColorVariations.Count > 0
                    ? v.ColorVariations
                    : new List<ColorVariation> { new ColorVariation() };
                foreach (var cv in cvs)
                    sb.AppendLine($"        <Item><indices content=\"char_array\"><Item>{cv.Primary}</Item><Item>{cv.Secondary}</Item><Item>{cv.Pearl}</Item><Item>{cv.Wheel}</Item></indices></Item>");
                sb.AppendLine("      </colors>");
                sb.AppendLine("      <kits><Item>0_default_modkit</Item></kits>");
                sb.AppendLine("    </Item>");
            }
            sb.AppendLine("  </variationData>");
            sb.AppendLine("</CVehicleVariationInfo>");
            return sb.ToString();
        }

        // ------------------------------------------------------------------
        //  peds.meta
        // ------------------------------------------------------------------
        public static string BuildPedsMeta(List<AddonPedEntry> peds, string dlcName)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CPedModelInfo__InitDataList>");
            sb.AppendLine("  <InitDatas>");
            foreach (var p in peds)
            {
                sb.AppendLine("    <Item>");
                sb.AppendLine($"      <Name>{p.ModelName}</Name>");
                sb.AppendLine($"      <ClipDictionaryName>{p.ClipDictionaryName}</ClipDictionaryName>");
                sb.AppendLine($"      <BlendShapeFileName /><ExpressionFileName /><ExpressionName />");
                sb.AppendLine($"      <MovementClipSet>{p.Movement}</MovementClipSet>");
                sb.AppendLine($"      <StrafeClipSet>{p.StrafeClipSet}</StrafeClipSet>");
                sb.AppendLine($"      <TerrainStateName>{p.TerrainStateName}</TerrainStateName>");
                sb.AppendLine($"      <InheritPropsFromParent value=\"{(p.InheritPropsFromParent ? "true" : "false")}\" />");
                sb.AppendLine($"      <Personality>{p.Personality}</Personality>");
                sb.AppendLine($"      <DefaultSpawnSet>{p.DefaultSpawnSet}</DefaultSpawnSet>");
                sb.AppendLine($"      <PedType>{p.PedType}</PedType>");
                sb.AppendLine($"      <pedVoiceGroup>{p.VoiceGroup}</pedVoiceGroup>");
                sb.AppendLine($"      <IsStreamedPed value=\"{(p.IsStreamed ? "true" : "false")}\" />");
                sb.AppendLine($"      <DlcName>{dlcName}</DlcName>");
                sb.AppendLine("    </Item>");
            }
            sb.AppendLine("  </InitDatas>");
            sb.AppendLine("</CPedModelInfo__InitDataList>");
            return sb.ToString();
        }

        // ------------------------------------------------------------------
        //  content.xml
        // ------------------------------------------------------------------
        public static string BuildContentXml(string dlcName, List<AddonVehicleEntry> vehicles, List<AddonPedEntry> peds)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CDataFileMgr__ContentsOfDataFileXml>");
            sb.AppendLine("  <disabledFiles /><includedXmlFiles /><includedDataFiles />");
            sb.AppendLine("  <dataFiles>");
            void Item(string path, string type, bool persistent = false)
                => sb.AppendLine($"    <Item><filename>{path}</filename><fileType>{type}</fileType>" +
                                 $"<overlay value=\"false\" /><disabled value=\"true\" />" +
                                 $"<persistent value=\"{(persistent ? "true" : "false")}\" /></Item>");
            Item($"dlc_{dlcName}:/data/carcols.meta", "CARCOLS_FILE");
            Item($"dlc_{dlcName}:/data/carvariations.meta", "VEHICLE_VARIATION_FILE");
            Item($"dlc_{dlcName}:/data/handling.meta", "HANDLING_FILE");
            Item($"dlc_{dlcName}:/data/vehicles.meta", "VEHICLE_METADATA_FILE");
            Item($"dlc_{dlcName}:/data/vehiclesstreamingdata.meta", "VEHICLE_STREAMING_REQUEST_RECORD");
            if (peds?.Count > 0) Item($"dlc_{dlcName}:/data/peds.meta", "PED_METADATA_FILE");
            Item($"dlc_{dlcName}:/%PLATFORM%/vehicles.rpf", "RPF_FILE", persistent: true);
            if (vehicles == null || vehicles.Count == 0) sb.AppendLine("  <invisibleFiles />");
            sb.AppendLine("  </dataFiles>");
            sb.AppendLine("  <contentChangeSets><Item>");
            sb.AppendLine($"    <changeSetName>{dlcName.ToUpperInvariant()}_AUTOGEN</changeSetName>");
            sb.AppendLine("    <filesToDisable /><filesToEnable>");
            sb.AppendLine($"      <Item>dlc_{dlcName}:/data/carcols.meta</Item>");
            sb.AppendLine($"      <Item>dlc_{dlcName}:/data/carvariations.meta</Item>");
            sb.AppendLine($"      <Item>dlc_{dlcName}:/data/handling.meta</Item>");
            sb.AppendLine($"      <Item>dlc_{dlcName}:/data/vehicles.meta</Item>");
            sb.AppendLine($"      <Item>dlc_{dlcName}:/data/vehiclesstreamingdata.meta</Item>");
            if (peds?.Count > 0) sb.AppendLine($"      <Item>dlc_{dlcName}:/data/peds.meta</Item>");
            sb.AppendLine($"      <Item>dlc_{dlcName}:/%PLATFORM%/vehicles.rpf</Item>");
            sb.AppendLine("    </filesToEnable>");
            sb.AppendLine("  </Item></contentChangeSets><patchFiles />");
            sb.AppendLine("</CDataFileMgr__ContentsOfDataFileXml>");
            return sb.ToString();
        }

        // ------------------------------------------------------------------
        //  setup2.xml
        // ------------------------------------------------------------------
        public static string BuildSetup2Xml(string dlcName)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<SSetupData>");
            sb.AppendLine($"  <deviceName>dlc_{dlcName}</deviceName><datFile>content.xml</datFile>");
            sb.AppendLine("  <timeStamp>00/00/0000 00:00:00</timeStamp>");
            sb.AppendLine($"  <nameHash>{dlcName}</nameHash>");
            sb.AppendLine("  <contentChangeSetGroups><Item><NameHash>GROUP_STARTUP</NameHash><ContentChangeSets>");
            sb.AppendLine($"    <Item>{dlcName.ToUpperInvariant()}_AUTOGEN</Item>");
            sb.AppendLine("  </ContentChangeSets></Item></contentChangeSetGroups>");
            sb.AppendLine("  <type>EXTRACONTENT_COMPAT_PACK</type><order value=\"50\" />");
            sb.AppendLine("</SSetupData>");
            return sb.ToString();
        }
    }

    // =========================================================================
    //  AddonGeneratorEx  — vehicles.meta with siren + audio fields
    // =========================================================================

    internal static class AddonGeneratorEx
    {
        /// <summary>
        /// Builds vehicles.meta, writing &lt;sirenId&gt; and the correct
        /// &lt;audioNameHash&gt; when a <see cref="VehicleLightAudioConfig"/> exists.
        /// Pass null configs to get the same output as the plain builder.
        /// </summary>
        public static string BuildVehiclesMetaWithSirens(
            List<AddonVehicleEntry> vehicles,
            Dictionary<string, VehicleLightAudioConfig> configs)
        {
            configs ??= new Dictionary<string, VehicleLightAudioConfig>();
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CVehicleModelInfo__InitDataList>");
            sb.AppendLine("  <InitDatas>");
            foreach (var v in vehicles)
            {
                configs.TryGetValue(v.SpawnName, out var cfg);
                cfg ??= new VehicleLightAudioConfig();
                int sirenId = SirenIdResolver.GetId(cfg.SirenPreset);
                bool hasSiren = sirenId > 0;
                // For Inherit: borrow the named vanilla bank.
                // For all other presets: use AddonGenerator2's resolver so the
                // audioNameHash points to a valid vanilla bank (e.g. "sultan",
                // "police", "ambulance") rather than the addon spawn name.
                string audioHash;
                if (cfg.AudioPreset == AudioPreset.Inherit)
                    audioHash = cfg.AudioInheritFrom ?? v.SpawnName;
                else if (!string.IsNullOrEmpty(v.AudioNameHash))
                    audioHash = v.AudioNameHash;
                else
                    audioHash = AddonGenerator2.ResolveAudioBankPublic(cfg);

                sb.AppendLine("    <Item>");
                sb.AppendLine($"      <modelName>{v.SpawnName}</modelName>");
                sb.AppendLine($"      <handlingId>{v.SpawnName}</handlingId>");
                sb.AppendLine($"      <gameName>{(string.IsNullOrEmpty(v.GameName) ? v.SpawnName.ToUpperInvariant() : v.GameName)}</gameName>");
                sb.AppendLine($"      <vehicleMakeName>{v.MakeName}</vehicleMakeName>");
                sb.AppendLine($"      <expressionDictionary>null</expressionDictionary>");
                sb.AppendLine($"      <expressionName>null</expressionName>");
                sb.AppendLine($"      <animConvRoofDictionary>null</animConvRoofDictionary>");
                sb.AppendLine($"      <animConvRoofName>null</animConvRoofName>");
                sb.AppendLine($"      <animConvRoofWindowsAmount value=\"0\" />");
                sb.AppendLine($"      <txdName>{v.SpawnName}</txdName>");
                sb.AppendLine($"      <type>{v.VehicleType}</type>");
                sb.AppendLine($"      <plateType>{v.PlateType}</plateType>");
                sb.AppendLine($"      <vehicleClass>VC_{v.Category}</vehicleClass>");
                sb.AppendLine($"      <flags></flags>");
                sb.AppendLine($"      <audioNameHash>{audioHash}</audioNameHash>");
                // ── Siren ───────────────────────────────────────────────────
                if (hasSiren)
                {
                    sb.AppendLine($"      <sirenId value=\"{sirenId}\" />");
                    sb.AppendLine($"      <vehicleFlags1>FLAG_HAS_SIRENS</vehicleFlags1>");
                }
                // ────────────────────────────────────────────────────────────
                sb.AppendLine($"      <layout>{v.Layout}</layout>");
                sb.AppendLine($"      <coverBoundOffsets>VEHICLE_COVER_BOUNDS_DEFAULT</coverBoundOffsets>");
                sb.AppendLine($"      <explosionInfo>EXPLOSION_INFO_DEFAULT</explosionInfo>");
                sb.AppendLine($"      <scenarioLayout />");
                sb.AppendLine($"      <cameraName>DEFAULT_FOLLOW_VEHICLE_CAMERA</cameraName>");
                sb.AppendLine($"      <aimCameraName>DEFAULT_FOLLOW_VEHICLE_AIM_CAMERA</aimCameraName>");
                sb.AppendLine($"      <FirstPersonDriveByIKOffset x=\"0\" y=\"0\" z=\"0\" />");
                sb.AppendLine($"      <FirstPersonDriveByUnarmedIKOffset x=\"0\" y=\"0\" z=\"0\" />");
                sb.AppendLine($"      <FirstPersonProjectileDriveByIKOffset x=\"0\" y=\"0\" z=\"0\" />");
                sb.AppendLine($"      <FirstPersonDriveByLeftIKOffset x=\"0\" y=\"0\" z=\"0\" />");
                sb.AppendLine($"      <FirstPersonDriveByRightIKOffset x=\"0\" y=\"0\" z=\"0\" />");
                sb.AppendLine($"      <wheelScale value=\"0.3\" />");
                sb.AppendLine($"      <wheelScaleRear value=\"0.3\" />");
                sb.AppendLine($"      <dirtLevelMin value=\"0.0\" /><dirtLevelMax value=\"0.4\" />");
                sb.AppendLine($"      <envEffScaleMin value=\"0.0\" /><envEffScaleMax value=\"0.0\" />");
                sb.AppendLine($"      <envEffScaleMin2 value=\"0.0\" /><envEffScaleMax2 value=\"0.0\" />");
                sb.AppendLine($"      <damageMapScale value=\"0.3\" /><damageOffsetScale value=\"0.3\" />");
                sb.AppendLine($"      <diffuseTint value=\"0xFFFFFFFF\" />");
                sb.AppendLine($"      <steerWheelMult value=\"1.0\" /><hp value=\"{v.Hp}\" />");
                sb.AppendLine($"      <ped>PLAYER_ZERO</ped><relatedVehicle />");
                sb.AppendLine($"      <shouldUseCinematicViewMode value=\"true\" />");
                sb.AppendLine($"      <shouldCameraTransitionOnClimbLadder value=\"false\" />");
                sb.AppendLine($"      <shouldCameraIgnoreExiting value=\"false\" />");
                sb.AppendLine($"      <AllowRespray value=\"true\" />");
                sb.AppendLine($"      <corneringAbility value=\"0.73\" /><bikeWheelFriction value=\"0.8\" />");
                sb.AppendLine($"      <maxDirtGrabVelocity value=\"-1.0\" /><hoodCameraFovMultiplier value=\"0.0\" />");
                sb.AppendLine($"      <swankness>{v.Swankness}</swankness><maxNum value=\"{v.MaxNum}\" />");
                sb.AppendLine($"      <flags2></flags2>");
                sb.AppendLine($"      <headlightDistanceMultiplier value=\"1.0\" />");
                sb.AppendLine($"      <headlightIntensityMultiplier value=\"1.0\" />");
                sb.AppendLine($"      <RoofCoverMaterial>VOC_CAR</RoofCoverMaterial>");
                sb.AppendLine($"      <numWheels value=\"{v.NumWheels}\" />");
                sb.AppendLine($"      <HasRocketBoost value=\"false\" /><HasFlyingAbility value=\"false\" />");
                sb.AppendLine($"      <HasOnSpawnGiveCargobobHook value=\"false\" />");
                sb.AppendLine($"      <HasLowriderHydraulics value=\"false\" />");
                sb.AppendLine($"      <HasLowriderDonkHydraulics value=\"false\" />");
                sb.AppendLine($"      <HasFroggerHoverAbility value=\"false\" />");
                sb.AppendLine($"      <isElectric value=\"{(cfg.AudioPreset == AudioPreset.Electric ? "true" : "false")}\" />");
                sb.AppendLine("    </Item>");
            }
            sb.AppendLine("  </InitDatas>");
            sb.AppendLine("</CVehicleModelInfo__InitDataList>");
            return sb.ToString();
        }
    }

    // =========================================================================
    //  AddonGenerator1  — carcols, streaming data, audio OpenFormats XML
    // =========================================================================

    internal static class AddonGenerator2
    {
        // ------------------------------------------------------------------
        //  Public entry used by AddonCreatorPanel.BtnGenerateAll_Click
        // ------------------------------------------------------------------
        public static void ExportFullDlcPackage(
            string outputRootPath,
            string dlcName,
            List<AddonVehicleEntry> vehicles,
            List<AddonPedEntry> peds,
            string sourceFilesDir,
            Dictionary<string, VehicleLightAudioConfig> lightAudioConfigs = null)
        {
            lightAudioConfigs ??= new Dictionary<string, VehicleLightAudioConfig>();

            string dlcRoot = Path.Combine(outputRootPath, "dlcpacks", dlcName);
            string rpfRoot = Path.Combine(dlcRoot, "dlc.rpf");
            string dataDir = Path.Combine(rpfRoot, "data");
            string audioSfxDir = Path.Combine(dataDir, "audio", "sfx");
            string vehicleRpf = Path.Combine(rpfRoot, "x64", "vehicles.rpf");

            foreach (var d in new[] { dataDir, audioSfxDir, vehicleRpf, dlcRoot })
                Directory.CreateDirectory(d);

            if (vehicles?.Count > 0)
            {
                File.WriteAllText(Path.Combine(dataDir, "vehicles.meta"),
                    AddonGeneratorEx.BuildVehiclesMetaWithSirens(vehicles, lightAudioConfigs), Encoding.UTF8);
                File.WriteAllText(Path.Combine(dataDir, "handling.meta"),
                    AddonGenerator.BuildHandlingMeta(vehicles), Encoding.UTF8);
                File.WriteAllText(Path.Combine(dataDir, "carvariations.meta"),
                    AddonGenerator.BuildCarVariationsMeta(vehicles), Encoding.UTF8);
                File.WriteAllText(Path.Combine(dataDir, "carcols.meta"),
                    BuildCarcolsMeta(vehicles, lightAudioConfigs), Encoding.UTF8);
                File.WriteAllText(Path.Combine(dataDir, "vehiclesstreamingdata.meta"),
                    BuildVehiclesStreamingData(vehicles, lightAudioConfigs), Encoding.UTF8);
                File.WriteAllText(Path.Combine(audioSfxDir, "audiovehicles_OPENFORMATS.xml"),
                    BuildAudioVehiclesXml(vehicles, lightAudioConfigs), Encoding.UTF8);
                File.WriteAllText(Path.Combine(audioSfxDir, "AUDIO_README.txt"),
                    BuildAudioReadme(), Encoding.UTF8);
            }

            if (peds?.Count > 0)
                File.WriteAllText(Path.Combine(dataDir, "peds.meta"),
                    AddonGenerator.BuildPedsMeta(peds, dlcName), Encoding.UTF8);

            File.WriteAllText(Path.Combine(rpfRoot, "content.xml"),
                AddonGenerator.BuildContentXml(dlcName, vehicles, peds), Encoding.UTF8);
            File.WriteAllText(Path.Combine(rpfRoot, "setup2.xml"),
                AddonGenerator.BuildSetup2Xml(dlcName), Encoding.UTF8);

            // Copy source model files into vehicles.rpf staging folder
            if (!string.IsNullOrEmpty(sourceFilesDir) && Directory.Exists(sourceFilesDir))
            {
                foreach (var f in Directory.GetFiles(sourceFilesDir, "*.*", SearchOption.AllDirectories))
                {
                    var ext = Path.GetExtension(f).ToLowerInvariant();
                    if (ext == ".yft" || ext == ".ytd")
                        File.Copy(f, Path.Combine(vehicleRpf, Path.GetFileName(f)), overwrite: true);
                    else if (ext == ".meta" || ext == ".xml")
                        File.Copy(f, Path.Combine(dataDir, Path.GetFileName(f)), overwrite: true);
                }
            }

            File.WriteAllText(Path.Combine(dlcRoot, "HOW_TO_INSTALL.txt"),
                BuildInstallReadme(dlcName, vehicles, lightAudioConfigs), Encoding.UTF8);
        }

        // ------------------------------------------------------------------
        //  carcols.meta  — siren light pattern definitions
        // ------------------------------------------------------------------
        public static string BuildCarcolsMeta(
            List<AddonVehicleEntry> vehicles,
            Dictionary<string, VehicleLightAudioConfig> configs = null)
        {
            configs ??= new Dictionary<string, VehicleLightAudioConfig>();
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CVehicleModelInfoVarGlobal>");
            sb.AppendLine("  <Kits />");
            sb.AppendLine("  <Sirens>");

            // Emit one block per unique preset that is actually used
            var usedPresets = vehicles
                .Select(v => GetCfg(v.SpawnName, configs).SirenPreset)
                .Where(p => p != SirenPreset.None)
                .Distinct();

            foreach (var preset in usedPresets)
                sb.Append(SirenBlock(preset, configs, vehicles));

            sb.AppendLine("  </Sirens>");
            sb.AppendLine("</CVehicleModelInfoVarGlobal>");
            return sb.ToString();
        }

        // ------------------------------------------------------------------
        //  vehiclesstreamingdata.meta  — public wrapper
        // ------------------------------------------------------------------
        public static string BuildVehiclesStreamingDataPublic(
            List<AddonVehicleEntry> vehicles,
            Dictionary<string, VehicleLightAudioConfig> configs)
            => BuildVehiclesStreamingData(vehicles, configs);

        // ------------------------------------------------------------------
        //  audiovehicles OpenFormats XML  — public wrapper
        // ------------------------------------------------------------------
        public static string BuildAudioVehiclesXmlPublic(
            List<AddonVehicleEntry> vehicles,
            Dictionary<string, VehicleLightAudioConfig> configs)
            => BuildAudioVehiclesXml(vehicles, configs);

        // ------------------------------------------------------------------
        //  AUDIO_README.txt  — public wrapper
        // ------------------------------------------------------------------
        public static string BuildAudioReadmePublic() => BuildAudioReadme();

        // ------------------------------------------------------------------
        //  vehiclesstreamingdata.meta  — tells the game which audio wad to stream
        // ------------------------------------------------------------------
        private static string BuildVehiclesStreamingData(
            List<AddonVehicleEntry> vehicles,
            Dictionary<string, VehicleLightAudioConfig> configs)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CVehicleStreamingDataMgr__InitDataList>");
            sb.AppendLine("  <InitDatas>");
            foreach (var v in vehicles)
            {
                var cfg = GetCfg(v.SpawnName, configs);
                // Inherit = borrow the named vanilla bank; anything else = use spawn name
                string bank = cfg.AudioPreset == AudioPreset.Inherit
                    ? (cfg.AudioInheritFrom ?? v.SpawnName)
                    : v.SpawnName;
                sb.AppendLine("    <Item>");
                sb.AppendLine($"      <modelName>{v.SpawnName}</modelName>");
                sb.AppendLine($"      <audioNameHash>{bank}</audioNameHash>");
                sb.AppendLine("    </Item>");
            }
            sb.AppendLine("  </InitDatas>");
            sb.AppendLine("</CVehicleStreamingDataMgr__InitDataList>");
            return sb.ToString();
        }

        // ------------------------------------------------------------------
        //  audiovehicles OpenFormats XML
        //  Import this via CodeWalker → RPF Explorer → OpenFormats
        //  into  dlc.rpf/x64/audio/sfx/  renamed to  audiovehicles.dat151.rel
        // ------------------------------------------------------------------
        private static string BuildAudioVehiclesXml(
            List<AddonVehicleEntry> vehicles,
            Dictionary<string, VehicleLightAudioConfig> configs)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<!-- Import via CodeWalker → RPF Explorer → OpenFormats -->");
            sb.AppendLine("<!-- Destination: dlc.rpf/x64/audio/sfx/               -->");
            sb.AppendLine("<!-- Rename to:   audiovehicles.dat151.rel              -->");
            sb.AppendLine("<AudioVehicleData>");
            foreach (var v in vehicles)
            {
                var cfg = GetCfg(v.SpawnName, configs);
                string bank = ResolveAudioBank(cfg);
                string horn = ResolveHornBank(cfg);
                sb.AppendLine($"  <Item>");
                sb.AppendLine($"    <Name>{v.SpawnName}</Name>");
                sb.AppendLine($"    <EngineAccel>{bank}_ENGINE_ACCEL</EngineAccel>");
                sb.AppendLine($"    <EngineDecel>{bank}_ENGINE_DECEL</EngineDecel>");
                sb.AppendLine($"    <StartSound>{bank}_START</StartSound>");
                sb.AppendLine($"    <StopSound>{bank}_STOP</StopSound>");
                sb.AppendLine($"    <Horn>{horn}_HORN</Horn>");
                if (cfg.SirenPreset != SirenPreset.None)
                {
                    string sirenBank = ResolveSirenAudioBank(cfg.SirenPreset);
                    sb.AppendLine($"    <Siren>{sirenBank}_SIREN_1</Siren>");
                    sb.AppendLine($"    <SirenOff>{sirenBank}_SIREN_OFF</SirenOff>");
                }
                sb.AppendLine($"  </Item>");
            }
            sb.AppendLine("</AudioVehicleData>");
            return sb.ToString();
        }

        private static string BuildAudioReadme() =>
            "To activate custom engine audio for these vehicles you need to import\n" +
            "audiovehicles_OPENFORMATS.xml using CodeWalker's RPF Explorer.\n\n" +
            "Steps:\n" +
            "  1. Open CodeWalker → RPF Explorer\n" +
            "  2. Navigate to:  dlc.rpf/x64/audio/sfx/\n" +
            "  3. Right-click → Import OpenFormats → select audiovehicles_OPENFORMATS.xml\n" +
            "  4. Rename the imported entry to:  audiovehicles.dat151.rel\n\n" +
            "Without this step the vehicle will fall back to the vanilla audio bank\n" +
            "specified by audioNameHash in vehicles.meta.\n";

        // ------------------------------------------------------------------
        //  HOW_TO_INSTALL.txt
        // ------------------------------------------------------------------
        private static string BuildInstallReadme(
            string dlcName,
            List<AddonVehicleEntry> vehicles,
            Dictionary<string, VehicleLightAudioConfig> configs)
        {
            bool hasSirens = vehicles?.Any(v =>
                GetCfg(v.SpawnName, configs).SirenPreset != SirenPreset.None) ?? false;

            var sb = new StringBuilder();
            sb.AppendLine("=================================================================");
            sb.AppendLine($"  HOW TO INSTALL '{dlcName}'  (lights, sirens & audio)");
            sb.AppendLine("=================================================================");
            if (vehicles?.Count > 0)
                sb.AppendLine($"  Vehicles: {string.Join(", ", vehicles.Select(v => v.SpawnName))}");
            sb.AppendLine();
            sb.AppendLine("STEP 1 — Add to dlclist.xml");
            sb.AppendLine("  File: mods/update/update.rpf/common/data/dlclist.xml");
            sb.AppendLine($"  Add:  <Item>dlcpacks:/{dlcName}/</Item>");
            sb.AppendLine();
            sb.AppendLine("STEP 2 — Create RPF structure in OpenIV");
            sb.AppendLine($"  mods/update/x64/dlcpacks/{dlcName}/dlc.rpf");
            sb.AppendLine("    data/");
            sb.AppendLine("    data/audio/sfx/");
            sb.AppendLine("    x64/  →  New Archive: vehicles.rpf");
            sb.AppendLine();
            sb.AppendLine("STEP 3 — Import content.xml + setup2.xml (OpenFormats)");
            sb.AppendLine("  dlc.rpf ROOT → right-click → Import using OpenFormats");
            sb.AppendLine();
            sb.AppendLine("STEP 4 — Import meta files into data/ (plain Import)");
            sb.AppendLine("  vehicles.meta  handling.meta  carvariations.meta");
            sb.AppendLine("  carcols.meta   vehiclesstreamingdata.meta");
            sb.AppendLine();
            sb.AppendLine("STEP 5 — Import model files into x64/vehicles.rpf/ (plain Import)");
            sb.AppendLine("  .yft   _hi.yft   .ytd");
            sb.AppendLine();
            if (hasSirens)
            {
                sb.AppendLine("STEP 6 — Siren audio (requires CodeWalker)");
                sb.AppendLine("  Navigate to: dlc.rpf/x64/audio/sfx/");
                sb.AppendLine("  Right-click → Import OpenFormats → audiovehicles_OPENFORMATS.xml");
                sb.AppendLine("  Rename the entry to: audiovehicles.dat151.rel");
                sb.AppendLine();
                sb.AppendLine("  NOTE: carcols.meta defines the light flash patterns.");
                sb.AppendLine("  The <sirenId> in vehicles.meta links to the carcols block.");
                sb.AppendLine("  To change colours/patterns edit the <flashiness> and <color>");
                sb.AppendLine("  values inside carcols.meta.");
            }
            sb.AppendLine("=================================================================");
            return sb.ToString();
        }

        // ------------------------------------------------------------------
        //  Siren block XML helpers
        // ------------------------------------------------------------------

        private static string SirenBlock(
            SirenPreset preset,
            Dictionary<string, VehicleLightAudioConfig> configs,
            List<AddonVehicleEntry> vehicles)
        {
            // Find the first vehicle using this preset to get its custom colours
            var cfg = vehicles
                .Select(v => GetCfg(v.SpawnName, configs))
                .FirstOrDefault(c => c.SirenPreset == preset)
                ?? new VehicleLightAudioConfig();

            int id = SirenIdResolver.GetId(preset);
            int count = Math.Clamp(cfg.SirenCount, 1, 8);
            int col1 = cfg.SirenColor1;
            int col2 = cfg.SirenColor2;
            string name = preset.ToString().ToUpperInvariant();

            var sb = new StringBuilder();
            sb.AppendLine($"    <Item>");
            sb.AppendLine($"      <id value=\"{id}\" />");
            sb.AppendLine($"      <name>{name}</name>");
            sb.AppendLine($"      <BPM value=\"120\" />");
            sb.AppendLine($"      <lightFalloffMax value=\"15.0\" />");
            sb.AppendLine($"      <lightFalloffExponent value=\"30.0\" />");
            sb.AppendLine($"      <lightInnerConeAngle value=\"0.0\" />");
            sb.AppendLine($"      <lightOuterConeAngle value=\"90.0\" />");
            sb.AppendLine($"      <lightOffset x=\"0.0\" y=\"0.0\" z=\"0.0\" />");
            sb.AppendLine($"      <textureName>VehicleLight_sirenlight</textureName>");
            sb.AppendLine($"      <sequencerBpm value=\"0\" />");
            sb.AppendLine($"      <leftHeadLight><flashiness>PATTERN_CONSTANT</flashiness><color>0x{CarcolsHex(col1)}</color></leftHeadLight>");
            sb.AppendLine($"      <rightHeadLight><flashiness>PATTERN_CONSTANT</flashiness><color>0x{CarcolsHex(col2)}</color></rightHeadLight>");
            sb.AppendLine($"      <leftTailLight><flashiness>PATTERN_CONSTANT</flashiness><color>0x{CarcolsHex(col1)}</color></leftTailLight>");
            sb.AppendLine($"      <rightTailLight><flashiness>PATTERN_CONSTANT</flashiness><color>0x{CarcolsHex(col2)}</color></rightTailLight>");

            for (int i = 0; i < count; i++)
            {
                int col = (i % 2 == 0) ? col1 : col2;
                string fl = (i % 2 == 0) ? "PATTERN_EMERGENCY_FLASH_1" : "PATTERN_EMERGENCY_FLASH_2";
                sb.AppendLine($"      <Sirens_{i}>");
                sb.AppendLine($"        <sirenLights>");
                sb.AppendLine($"          <flashiness>{fl}</flashiness>");
                sb.AppendLine($"          <color>0x{CarcolsHex(col)}</color>");
                sb.AppendLine($"          <intensity value=\"15.0\" />");
                sb.AppendLine($"          <lightGroup value=\"{i % 2}\" />");
                sb.AppendLine($"          <rotate value=\"false\" />");
                sb.AppendLine($"          <scale value=\"true\" /><scaleFactor value=\"2\" />");
                sb.AppendLine($"          <healthToIntensityMultiplier value=\"1.0\" />");
                sb.AppendLine($"          <offset x=\"0.0\" y=\"0.0\" z=\"0.0\" />");
                sb.AppendLine($"        </sirenLights>");
                sb.AppendLine($"      </Sirens_{i}>");
            }
            sb.AppendLine($"      <vehicleBlipSiren value=\"SIRENSETTING_INTERRUPT_VEHICLE_BLIP_LOUD\" />");
            sb.AppendLine($"    </Item>");
            return sb.ToString();
        }

        // ------------------------------------------------------------------
        //  Audio bank resolvers
        // ------------------------------------------------------------------

        public static string ResolveAudioBankPublic(VehicleLightAudioConfig cfg)
            => ResolveAudioBank(cfg);

        private static string ResolveAudioBank(VehicleLightAudioConfig cfg)
        {
            if (cfg.AudioPreset == AudioPreset.Inherit)
                return cfg.AudioInheritFrom?.ToLowerInvariant() ?? "police";
            switch (cfg.AudioPreset)
            {
                case AudioPreset.FourCylinder: return "sultan";
                case AudioPreset.SixCylinder: return "tailgater";
                case AudioPreset.V8Muscle: return "vigero";
                case AudioPreset.V8Luxury: return "schafter2";
                case AudioPreset.V10: return "rapidgt";
                case AudioPreset.V12: return "superd";
                case AudioPreset.Electric: return "voltic";
                case AudioPreset.TurboSports: return "jester";
                case AudioPreset.PoliceCruiser: return "police";
                case AudioPreset.PoliceInterceptor: return "police2";
                case AudioPreset.PoliceRanger: return "sheriff";
                case AudioPreset.AmbulanceTruck: return "ambulance";
                case AudioPreset.FiretruckHeavy: return "firetruk";
                case AudioPreset.BigRig: return "hauler";
                case AudioPreset.Bus: return "bus";
                case AudioPreset.Helicopter: return "polmav";
                case AudioPreset.Plane: return "luxor";
                default: return "sultan";
            }
        }

        private static string ResolveHornBank(VehicleLightAudioConfig cfg)
        {
            switch (cfg.AudioPreset)
            {
                case AudioPreset.PoliceCruiser:
                case AudioPreset.PoliceInterceptor:
                case AudioPreset.PoliceRanger: return "POLICE";
                case AudioPreset.AmbulanceTruck: return "AMBULANCE";
                case AudioPreset.FiretruckHeavy: return "FIRETRUCK";
                case AudioPreset.BigRig:
                case AudioPreset.Bus: return "TRUCK";
                default: return "NORMAL";
            }
        }

        private static string ResolveSirenAudioBank(SirenPreset preset)
        {
            switch (preset)
            {
                case SirenPreset.PoliceLSPD:
                case SirenPreset.PoliceFIB:
                case SirenPreset.Sheriff:
                case SirenPreset.Highway: return "POLICE";
                case SirenPreset.Ambulance: return "AMBULANCE";
                case SirenPreset.FireTruck: return "FIRETRUCK";
                case SirenPreset.Military: return "MILITARY";
                default: return "POLICE";
            }
        }

        // ------------------------------------------------------------------
        //  Colour index → ARGB hex string
        //  Only the most common emergency / carcols indices are mapped.
        //  Everything else falls back to white.
        // ------------------------------------------------------------------
        private static string CarcolsHex(int idx)
        {
            switch (idx)
            {
                case 0: return "FF1111FF"; // blue
                case 1: return "FFFFFFFF"; // white
                case 2: return "FFFFFF00"; // yellow
                case 3: return "FFFF1111"; // red
                case 4: return "FF00FF00"; // green
                case 5: return "FFFF8C00"; // orange
                case 6: return "FFFF00FF"; // purple
                case 56: return "FF1155FF"; // LSPD blue
                default: return "FFFFFFFF";
            }
        }

        private static VehicleLightAudioConfig GetCfg(
            string spawnName, Dictionary<string, VehicleLightAudioConfig> configs)
            => (configs != null && configs.TryGetValue(spawnName, out var c)) ? c : new VehicleLightAudioConfig();
    }

    // =========================================================================
    //  VehicleDlcBuilder (EUP panel → build from converted files)
    // =========================================================================

    internal static class VehicleDlcBuilder
    {
        private static readonly (string Match, string FileType)[] MetaFileTypes = {
            ("carcols","CARCOLS_FILE"),("carvariations","VEHICLE_VARIATION_FILE"),
            ("handling","HANDLING_FILE"),("vehicles","VEHICLE_METADATA_FILE"),
            ("vehiclelayouts","VEHICLE_LAYOUTS_FILE"),("contentunlocks","CONTENT_UNLOCKING_META_FILE"),
        };
        private static readonly HashSet<string> ExcludedFileNames =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "content.xml", "setup2.xml" };

        public static (List<VehicleEntry> vehicles, List<string> metaFiles) Scan(string convertedDir)
        {
            var files = Directory.GetFiles(convertedDir, "*.*", SearchOption.AllDirectories);
            var yftFiles = files.Where(f => f.EndsWith(".yft", StringComparison.OrdinalIgnoreCase)
                            && !Path.GetFileNameWithoutExtension(f).EndsWith("_hi", StringComparison.OrdinalIgnoreCase)).ToList();
            var allYtd = files.Where(f => f.EndsWith(".ytd", StringComparison.OrdinalIgnoreCase))
                                .Select(f => Path.GetFileNameWithoutExtension(f)).ToList();
            var allNames = files.Select(f => Path.GetFileName(f)).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var vehicles = new List<VehicleEntry>();
            foreach (var yft in yftFiles)
            {
                var spawn = Path.GetFileNameWithoutExtension(yft);
                bool hasHi = allNames.Contains(spawn + "_hi.yft");
                // Also match the '+' separator — Rockstar's own naming
                // convention for a supplementary texture dictionary loaded
                // alongside the base one (e.g. "durango+hi.ytd"), distinct
                // from the underscore convention used for plain texture
                // variants. Missing this meant a real, correctly-named,
                // correctly-extracted file was silently never matched to its
                // vehicle and dropped during the build step.
                var ytds = allYtd.Where(n => n.Equals(spawn, StringComparison.OrdinalIgnoreCase)
                    || n.StartsWith(spawn + "_", StringComparison.OrdinalIgnoreCase)
                    || n.StartsWith(spawn + "+", StringComparison.OrdinalIgnoreCase)).OrderBy(n => n).ToList();
                vehicles.Add(new VehicleEntry { SpawnName = spawn, HasHiModel = hasHi, YtdNames = ytds });
            }
            var metaFiles = files
                .Where(f => { var n = Path.GetFileName(f); if (ExcludedFileNames.Contains(n)) return false; return f.EndsWith(".meta", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".xml", StringComparison.OrdinalIgnoreCase); })
                .Select(f => Path.GetFileName(f)).OrderBy(f => f).ToList();
            return (vehicles.OrderBy(v => v.SpawnName).ToList(), metaFiles);
        }

        public static List<string> Build(VehicleDlcBuildSettings s, string convertedFilesDir)
        {
            var log = new List<string>();
            var dlcRoot = Path.Combine(s.OutputRoot, "dlcpacks", s.DlcName);
            var dlcRpf = Path.Combine(dlcRoot, "dlc.rpf");
            var vehicleRpf = Path.Combine(dlcRpf, "x64", "vehicles.rpf");
            var dataDir = Path.Combine(dlcRpf, "data");
            foreach (var dir in new[] { vehicleRpf, dataDir, dlcRoot }) Directory.CreateDirectory(dir);
            foreach (var v in s.Vehicles)
            {
                CopyIfExists(convertedFilesDir, vehicleRpf, v.SpawnName + ".yft", log);
                if (v.HasHiModel) CopyIfExists(convertedFilesDir, vehicleRpf, v.SpawnName + "_hi.yft", log);
                foreach (var ytd in v.YtdNames) CopyIfExists(convertedFilesDir, vehicleRpf, ytd + ".ytd", log);
            }
            foreach (var meta in s.MetaFiles) CopyIfExists(convertedFilesDir, dataDir, meta, log);
            File.WriteAllText(Path.Combine(dlcRpf, "content.xml"), BuildContentXml(s), Encoding.UTF8);
            File.WriteAllText(Path.Combine(dlcRpf, "setup2.xml"), BuildSetup2Xml(s), Encoding.UTF8);
            File.WriteAllText(Path.Combine(dlcRoot, "HOW_TO_INSTALL.txt"), BuildInstructions(s));
            log.Add("Written content.xml, setup2.xml, HOW_TO_INSTALL.txt");
            return log;
        }

        private static void CopyIfExists(string srcDir, string destDir, string fileName, List<string> log)
        {
            var src = Path.Combine(srcDir, fileName);
            if (!File.Exists(src)) return;
            File.Copy(src, Path.Combine(destDir, fileName), overwrite: true);
            log.Add($"Copied  {fileName}  →  {Path.GetFileName(destDir)}/");
        }

        private static string ResolveMetaFileType(string fileName)
        {
            var lower = Path.GetFileNameWithoutExtension(fileName).ToLowerInvariant();
            foreach (var (match, fileType) in MetaFileTypes) if (lower.Contains(match)) return fileType;
            return "VEHICLE_METADATA_FILE";
        }

        private static string BuildContentXml(VehicleDlcBuildSettings s)
        {
            var device = $"dlc_{s.DlcName}";
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CDataFileMgr__ContentsOfDataFileXml>");
            sb.AppendLine("  <disabledFiles /><includedXmlFiles /><includedDataFiles />");
            sb.AppendLine("  <dataFiles>");
            foreach (var meta in s.MetaFiles)
            {
                sb.AppendLine("    <Item>");
                sb.AppendLine($"      <filename>{device}:/data/{meta}</filename>");
                sb.AppendLine($"      <fileType>{ResolveMetaFileType(meta)}</fileType>");
                sb.AppendLine("      <overlay value=\"false\" /><disabled value=\"true\" /><persistent value=\"false\" />");
                sb.AppendLine("    </Item>");
            }
            sb.AppendLine($"    <Item><filename>{device}:/%PLATFORM%/vehicles.rpf</filename><fileType>RPF_FILE</fileType><overlay value=\"false\" /><disabled value=\"true\" /><persistent value=\"true\" /></Item>");
            sb.AppendLine("  </dataFiles>");
            sb.AppendLine("  <contentChangeSets><Item>");
            sb.AppendLine($"    <changeSetName>{s.DlcName.ToUpperInvariant()}_AUTOGEN</changeSetName>");
            sb.AppendLine("    <filesToDisable /><filesToEnable>");
            foreach (var meta in s.MetaFiles) sb.AppendLine($"      <Item>{device}:/data/{meta}</Item>");
            sb.AppendLine($"      <Item>{device}:/%PLATFORM%/vehicles.rpf</Item>");
            sb.AppendLine("    </filesToEnable><txdToLoad /><txdToUnload /><residentResources /><unregisterResources />");
            sb.AppendLine("  </Item></contentChangeSets><patchFiles />");
            sb.AppendLine("</CDataFileMgr__ContentsOfDataFileXml>");
            return sb.ToString();
        }

        private static string BuildSetup2Xml(VehicleDlcBuildSettings s)
        {
            var device = $"dlc_{s.DlcName}";
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<SSetupData>");
            sb.AppendLine($"  <deviceName>{device}</deviceName><datFile>content.xml</datFile>");
            sb.AppendLine("  <timeStamp>00/00/0000 00:00:00</timeStamp>");
            sb.AppendLine($"  <nameHash>{s.DlcName}</nameHash>");
            sb.AppendLine("  <contentChangeSetGroups><Item><NameHash>GROUP_STARTUP</NameHash><ContentChangeSets>");
            sb.AppendLine($"    <Item>{s.DlcName.ToUpperInvariant()}_AUTOGEN</Item>");
            sb.AppendLine("  </ContentChangeSets></Item></contentChangeSetGroups>");
            sb.AppendLine("  <type>EXTRACONTENT_COMPAT_PACK</type><order value=\"9\" />");
            sb.AppendLine("</SSetupData>");
            return sb.ToString();
        }

        private static string BuildInstructions(VehicleDlcBuildSettings s)
        {
            var sb = new StringBuilder();
            sb.AppendLine("=================================================================");
            sb.AppendLine("  HOW TO INSTALL THIS VEHICLE DLC IN OPENIV");
            sb.AppendLine("=================================================================");
            sb.AppendLine($"  Vehicles: {string.Join(", ", s.Vehicles.Select(v => v.SpawnName))}");
            sb.AppendLine();
            sb.AppendLine("STEP 1 — Add:  <Item>dlcpacks:/" + s.DlcName + "/</Item>  to dlclist.xml");
            sb.AppendLine("STEP 2 — Create mods/update/x64/dlcpacks/" + s.DlcName + "/dlc.rpf");
            sb.AppendLine("         Inside: data/  and  x64/vehicles.rpf  (new archive)");
            sb.AppendLine("STEP 3 — Import .yft + .ytd into x64/vehicles.rpf/");
            sb.AppendLine("STEP 4 — Import .meta files into data/");
            sb.AppendLine("STEP 5 — Import content.xml + setup2.xml via OpenFormats into dlc.rpf root");
            sb.AppendLine("=================================================================");
            return sb.ToString();
        }
    }

    // =========================================================================
    //  DlcBuilder (clothing)
    // =========================================================================

    internal static class DlcBuilder
    {
        internal static readonly Regex YddPattern =
            new Regex(@"^(?<slot>[a-z]+)_(?<idx>\d+)_[a-z]$", RegexOptions.IgnoreCase);
        internal static readonly Regex YtdPattern =
            new Regex(@"^(?<slot>[a-z]+)_diff_(?<idx>\d+)_[a-z]_", RegexOptions.IgnoreCase);

        public static (string detectedPed, List<DlcDrawable> drawables) Scan(string convertedDir)
        {
            var files = Directory.GetFiles(convertedDir, "*.*", SearchOption.TopDirectoryOnly);
            var yddFiles = files.Where(f => f.EndsWith(".ydd", StringComparison.OrdinalIgnoreCase)).ToList();
            var ytdFiles = files.Where(f => f.EndsWith(".ytd", StringComparison.OrdinalIgnoreCase)).ToList();
            string detectedPed = "mp_f_freemode_01";
            var ymtFile = files.FirstOrDefault(f => f.EndsWith(".ymt", StringComparison.OrdinalIgnoreCase));
            if (ymtFile != null && !FormatConverter.IsBinaryFile(ymtFile))
            {
                try { var m = Regex.Match(File.ReadAllText(ymtFile), @"<pedName>([^<]+)</pedName>", RegexOptions.IgnoreCase); if (m.Success) detectedPed = m.Groups[1].Value.Trim(); }
                catch { }
            }
            var drawables = new List<DlcDrawable>();
            foreach (var ydd in yddFiles)
            {
                var baseName = Path.GetFileNameWithoutExtension(ydd);
                var m = YddPattern.Match(baseName);
                if (!m.Success) continue;
                var slot = m.Groups["slot"].Value.ToLowerInvariant();
                var idxStr = m.Groups["idx"].Value;
                int idx = int.Parse(idxStr);
                var matchingYtds = ytdFiles
                    .Select(f => Path.GetFileNameWithoutExtension(f))
                    .Where(n => { var ym = YtdPattern.Match(n); return ym.Success && ym.Groups["slot"].Value.Equals(slot, StringComparison.OrdinalIgnoreCase) && ym.Groups["idx"].Value == idxStr; })
                    .OrderBy(n => n).ToList();
                drawables.Add(new DlcDrawable { SlotRoot = slot, DrawableIndex = idx, YddName = baseName, YtdNames = matchingYtds });
            }
            return (detectedPed, drawables.OrderBy(d => d.SlotRoot).ThenBy(d => d.DrawableIndex).ToList());
        }

        public static List<string> Build(DlcBuildSettings s, string convertedFilesDir)
        {
            var log = new List<string>();
            var genderSuffix = s.PedName.Contains("_f_") ? "female" : "male";
            var rpfName = $"{s.DlcName}_{genderSuffix}.rpf";
            var rpfNameP = $"{s.DlcName}_{genderSuffix}_p.rpf";
            var dlcRoot = Path.Combine(s.OutputRoot, "dlcpacks", s.DlcName);
            var dlcRpfRoot = Path.Combine(dlcRoot, "dlc.rpf");
            var dlcX64 = Path.Combine(dlcRpfRoot, "x64", "models", "cdimages");
            var rpfModels = Path.Combine(dlcX64, rpfName);
            var rpfModelsP = Path.Combine(dlcX64, rpfNameP);
            var commonData = Path.Combine(dlcRpfRoot, "common", "data", "shop_metadata");
            var openFmtsDir = Path.Combine(dlcRoot, "IMPORT_WITH_OPENFORMATS");
            foreach (var dir in new[] { commonData, dlcRpfRoot, dlcRoot, dlcX64, openFmtsDir }) Directory.CreateDirectory(dir);
            bool hasComponents = false, hasProps = false;
            foreach (var file in Directory.GetFiles(convertedFilesDir, "*.*", SearchOption.TopDirectoryOnly))
            {
                var ext = Path.GetExtension(file).ToLowerInvariant();
                if (ext != ".ydd" && ext != ".ytd") continue;
                bool isProp = Path.GetFileName(file).StartsWith("p_", StringComparison.OrdinalIgnoreCase);
                if (isProp) { Directory.CreateDirectory(rpfModelsP); File.Copy(file, Path.Combine(rpfModelsP, Path.GetFileName(file)), overwrite: true); log.Add($"Copied {Path.GetFileName(file)} → props RPF"); hasProps = true; }
                else { Directory.CreateDirectory(rpfModels); File.Copy(file, Path.Combine(rpfModels, Path.GetFileName(file)), overwrite: true); log.Add($"Copied {Path.GetFileName(file)} → components RPF"); hasComponents = true; }
            }
            var ymtFileName = $"{s.PedName}_{s.DlcName}.ymt.xml";
            var metaFileName = $"{s.DlcName}.meta.xml";
            File.WriteAllText(Path.Combine(dlcRpfRoot, "content.xml"), BuildContentXml(s, rpfName, rpfNameP, hasComponents, hasProps), Encoding.UTF8);
            File.WriteAllText(Path.Combine(dlcRpfRoot, "setup2.xml"), BuildSetup2Xml(s), Encoding.UTF8);
            File.WriteAllText(Path.Combine(openFmtsDir, ymtFileName), BuildYmt(s), Encoding.UTF8);
            File.WriteAllText(Path.Combine(openFmtsDir, metaFileName), BuildMeta(s), Encoding.UTF8);
            File.WriteAllText(Path.Combine(dlcRoot, "HOW_TO_INSTALL.txt"), BuildInstructions(s, rpfName, rpfNameP, hasComponents, hasProps, ymtFileName, metaFileName));
            log.Add("Written content.xml, setup2.xml, .ymt.xml, .meta.xml, HOW_TO_INSTALL.txt");
            return log;
        }

        internal static string BuildYmt(DlcBuildSettings s)
        {
            // Schema confirmed directly against a real exported
            // mp_f_freemode_01.ymt (via CodeWalker), not guessed. The
            // previous version was missing required itemType="..."
            // attributes on every array container and the <clothData> block
            // on every drawable Item — exactly why OpenIV's PSO importer
            // rejected it ("Unable to import META/PSO file", Line 0 — a
            // structural-level rejection, not one bad value).
            //
            // Field-level note: a few values below (flags=0, audioID=none,
            // expressionMods all-zero) are neutral defaults, not confirmed
            // per-drawable behavior — the real file's actual values varied
            // per base-game drawable in ways tied to specific game design we
            // have no way to infer for a brand new custom drawable. These
            // defaults are chosen to be structurally valid and import
            // cleanly; if something looks behaviorally off in-game (e.g. an
            // expression glitch), that's the area to revisit, not the
            // overall structure.
            var bySlot = s.Drawables
                .GroupBy(d => d.SlotRoot.ToLowerInvariant())
                .ToDictionary(g => g.Key, g => g.OrderBy(d => d.DrawableIndex).ToList());

            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CPedVariationInfo>");
            sb.AppendLine(" <bHasTexVariations value=\"true\" />");
            sb.AppendLine(" <bHasDrawblVariations value=\"true\" />");
            sb.AppendLine(" <bHasLowLODs value=\"false\" />");
            sb.AppendLine(" <bIsSuperLOD value=\"false\" />");
            // All 12 slots are always listed for a freemode-based patch ped,
            // whether or not this DLC adds anything to each one — slots it
            // doesn't touch just get an empty entry below instead of being
            // omitted (omitting one entirely was not seen anywhere in the
            // real reference file).
            sb.AppendLine(" <availComp>0 1 2 3 4 5 6 7 8 9 10 11</availComp>");
            sb.AppendLine(" <aComponentData3 itemType=\"CPVComponentData\">");
            foreach (var slot in ComponentSlots.Roots)
            {
                bySlot.TryGetValue(slot, out var drawables);
                drawables ??= new List<DlcDrawable>();
                int numAvailTex = drawables.Sum(d => Math.Max(1, d.YtdNames.Count));
                sb.AppendLine("  <Item>");
                sb.AppendLine($"   <numAvailTex value=\"{numAvailTex}\" />");
                if (drawables.Count == 0)
                {
                    sb.AppendLine("   <aDrawblData3 itemType=\"CPVDrawblData\" />");
                }
                else
                {
                    sb.AppendLine("   <aDrawblData3 itemType=\"CPVDrawblData\">");
                    foreach (var d in drawables)
                    {
                        sb.AppendLine("    <Item>");
                        sb.AppendLine("     <propMask value=\"17\" />");
                        sb.AppendLine("     <numAlternatives value=\"0\" />");
                        sb.AppendLine("     <aTexData itemType=\"CPVTextureData\">");
                        int texCount = Math.Max(1, d.YtdNames.Count);
                        for (int t = 0; t < texCount; t++)
                        {
                            sb.AppendLine("     <Item>");
                            sb.AppendLine($"      <texId value=\"{t}\" />");
                            sb.AppendLine("      <distribution value=\"255\" />");
                            sb.AppendLine("     </Item>");
                        }
                        sb.AppendLine("     </aTexData>");
                        sb.AppendLine("     <clothData>");
                        sb.AppendLine("      <ownsCloth value=\"false\" />");
                        sb.AppendLine("     </clothData>");
                        sb.AppendLine("    </Item>");
                    }
                    sb.AppendLine("   </aDrawblData3>");
                }
                sb.AppendLine("  </Item>");
            }
            sb.AppendLine(" </aComponentData3>");

            // Required even when empty — confirmed present (self-closed) in
            // the real reference file.
            sb.AppendLine(" <aSelectionSets itemType=\"CPedSelectionSet\" />");

            // One entry per (slot, drawable) pair, same order as
            // aComponentData3 — confirmed against the real file's
            // pedXml_compIdx/pedXml_drawblIdx pairing and PV_COMP_<SLOT>
            // naming, which lines up exactly with ComponentSlots.Roots'
            // existing order.
            sb.AppendLine(" <compInfos itemType=\"CComponentInfo\">");
            for (int slotIdx = 0; slotIdx < ComponentSlots.Roots.Length; slotIdx++)
            {
                var slot = ComponentSlots.Roots[slotIdx];
                if (!bySlot.TryGetValue(slot, out var drawables)) continue;
                foreach (var d in drawables)
                {
                    sb.AppendLine("  <Item>");
                    sb.AppendLine("   <pedXml_audioID>none</pedXml_audioID>");
                    sb.AppendLine("   <pedXml_audioID2>none</pedXml_audioID2>");
                    sb.AppendLine("   <pedXml_expressionMods>0 0 0 0 0</pedXml_expressionMods>");
                    sb.AppendLine("   <flags value=\"0\" />");
                    sb.AppendLine("   <inclusions>0</inclusions>");
                    sb.AppendLine("   <exclusions>0</exclusions>");
                    sb.AppendLine($"   <pedXml_vfxComps>PV_COMP_{slot.ToUpperInvariant()}</pedXml_vfxComps>");
                    sb.AppendLine("   <pedXml_flags value=\"0\" />");
                    sb.AppendLine($"   <pedXml_compIdx value=\"{slotIdx}\" />");
                    sb.AppendLine($"   <pedXml_drawblIdx value=\"{d.DrawableIndex}\" />");
                    sb.AppendLine("  </Item>");
                }
            }
            sb.AppendLine(" </compInfos>");

            // Props aren't tracked in DlcBuildSettings.Drawables at all (only
            // component drawables matched by the slot_idx_gender naming
            // pattern are) — prop files still get packaged into the _p.rpf,
            // but without a populated propInfo section here they won't show
            // up as wearable accessories yet. That's an existing scope gap,
            // not something this fix introduces or regresses — propInfo is
            // written as structurally-complete-but-empty since the real file
            // confirms this section must be present even with nothing in it.
            sb.AppendLine(" <propInfo>");
            sb.AppendLine("  <numAvailProps value=\"0\" />");
            sb.AppendLine("  <aPropMetaData itemType=\"CPedPropMetaData\" />");
            sb.AppendLine("  <aAnchors itemType=\"CAnchorProps\" />");
            sb.AppendLine(" </propInfo>");

            sb.AppendLine(" <dlcName />");
            sb.AppendLine("</CPedVariationInfo>");
            return sb.ToString();
        }

        internal static string BuildMeta(DlcBuildSettings s)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CComponentInfo><Infos><Item type=\"CPedComponentInfo\">");
            sb.AppendLine($"  <pedXml>{s.DlcName}</pedXml>");
            sb.AppendLine($"  <numAvailComp value=\"{s.Drawables.Count}\" />");
            sb.AppendLine("  <components>");
            foreach (var d in s.Drawables)
            {
                int ci = Array.IndexOf(ComponentSlots.Roots, d.SlotRoot.ToLowerInvariant()); if (ci < 0) ci = 0;
                sb.AppendLine("    <Item type=\"CPedSpecificComponentInfo\">");
                sb.AppendLine($"      <drawableIndex value=\"{d.DrawableIndex}\" />");
                sb.AppendLine($"      <numTextures value=\"{Math.Max(1, d.YtdNames.Count)}\" />");
                sb.AppendLine($"      <componentTypeFlags value=\"0\" />");
                sb.AppendLine($"      <componentIndex value=\"{ci}\" />");
                sb.AppendLine($"      <nameHash>{d.YddName}</nameHash>");
                sb.AppendLine("    </Item>");
            }
            sb.AppendLine("  </components></Item></Infos></CComponentInfo>");
            return sb.ToString();
        }

        internal static string BuildContentXml(DlcBuildSettings s, string rpfName, string rpfNameP, bool hasComponents, bool hasProps)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<CDataFileMgr__ContentsOfDataFileXml>");
            sb.AppendLine("  <disabledFiles /><includedXmlFiles /><includedDataFiles />");
            sb.AppendLine("  <dataFiles>");
            if (hasComponents) sb.AppendLine($"    <Item><filename>dlcpacks:/eup/{s.DlcName}/dlc.rpf/x64/models/cdimages/{rpfName}</filename><fileType>RPF_FILE</fileType><overlay value=\"false\" /><disabled value=\"true\" /><persistent value=\"true\" /></Item>");
            if (hasProps) sb.AppendLine($"    <Item><filename>dlcpacks:/eup/{s.DlcName}/dlc.rpf/x64/models/cdimages/{rpfNameP}</filename><fileType>RPF_FILE</fileType><overlay value=\"false\" /><disabled value=\"true\" /><persistent value=\"true\" /></Item>");
            sb.AppendLine($"    <Item><filename>dlcpacks:/eup/{s.DlcName}/dlc.rpf/common/data/shop_metadata/{s.DlcName}.meta</filename><fileType>SHOP_PED_APPAREL_META_FILE</fileType><overlay value=\"false\" /><disabled value=\"true\" /><persistent value=\"false\" /></Item>");
            sb.AppendLine("  </dataFiles>");
            sb.AppendLine("  <contentChangeSets><Item>");
            sb.AppendLine($"    <changeSetName>{s.DlcName.ToUpperInvariant()}_AUTOGEN</changeSetName>");
            sb.AppendLine("    <filesToInvalidate /><filesToDisable /><filesToEnable>");
            if (hasComponents) sb.AppendLine($"      <Item>dlcpacks:/eup/{s.DlcName}/dlc.rpf/x64/models/cdimages/{rpfName}</Item>");
            if (hasProps) sb.AppendLine($"      <Item>dlcpacks:/eup/{s.DlcName}/dlc.rpf/x64/models/cdimages/{rpfNameP}</Item>");
            sb.AppendLine($"      <Item>dlcpacks:/eup/{s.DlcName}/dlc.rpf/common/data/shop_metadata/{s.DlcName}.meta</Item>");
            sb.AppendLine("    </filesToEnable><txdToLoad /><txdToUnload /><residentTxdToLoad /><residentTxdToUnload />");
            sb.AppendLine("  </Item></contentChangeSets><patchFiles />");
            sb.AppendLine("</CDataFileMgr__ContentsOfDataFileXml>");
            return sb.ToString();
        }

        internal static string BuildSetup2Xml(DlcBuildSettings s)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<SSetupData>");
            sb.AppendLine("  <deviceName>dlc_patch</deviceName><datFile>content.xml</datFile>");
            sb.AppendLine("  <timeStamp>08/01/2024 00:00:00</timeStamp>");
            sb.AppendLine($"  <nameHash>{s.DlcName}</nameHash>");
            sb.AppendLine("  <contentChangeSetGroups><Item><NameHash>GROUP_STARTUP</NameHash><ContentChangeSets>");
            sb.AppendLine($"    <Item>{s.DlcName.ToUpperInvariant()}_AUTOGEN</Item>");
            sb.AppendLine("  </ContentChangeSets></Item></contentChangeSetGroups>");
            sb.AppendLine("  <streamingFileType>2</streamingFileType><isLevelPack value=\"false\" />");
            sb.AppendLine($"  <patchDeviceName>dlc_patch</patchDeviceName><patchPrefix>z_{s.DlcName}</patchPrefix>");
            sb.AppendLine("</SSetupData>");
            return sb.ToString();
        }

        internal static string BuildInstructions(DlcBuildSettings s, string rpfName, string rpfNameP,
            bool hasComponents, bool hasProps, string ymtFileName, string metaFileName)
        {
            var sb = new StringBuilder();
            sb.AppendLine("=================================================================");
            sb.AppendLine("  HOW TO INSTALL THIS DLC IN OPENIV");
            sb.AppendLine("=================================================================");
            sb.AppendLine($"  <Item>dlcpacks:/eup/{s.DlcName}/</Item>  →  dlclist.xml");
            sb.AppendLine();
            sb.AppendLine($"  mods/update/x64/dlcpacks/{s.DlcName}/dlc.rpf");
            sb.AppendLine("  Folders: x64/models/cdimages/  common/data/shop_metadata/");
            if (hasComponents) sb.AppendLine($"  New Archive inside cdimages/: {rpfName}");
            if (hasProps) sb.AppendLine($"  New Archive inside cdimages/: {rpfNameP}");
            sb.AppendLine();
            if (hasComponents) sb.AppendLine($"  Import into {rpfName}/: all .ydd and .ytd component files");
            if (hasProps) sb.AppendLine($"  Import into {rpfNameP}/: all .ydd and .ytd prop files");
            sb.AppendLine($"  OpenFormats → dlc.rpf ROOT → {ymtFileName}");
            sb.AppendLine($"  OpenFormats → shop_metadata/ → {metaFileName}");
            sb.AppendLine("  OpenFormats → dlc.rpf ROOT → content.xml, setup2.xml");
            sb.AppendLine("=================================================================");
            return sb.ToString();
        }
    }

    // =========================================================================
    //  Diff highlight helper
    // =========================================================================

    internal static class DiffHighlight
    {
        public static List<(string text, bool changed)> Diff(string original, string result)
        {
            if (string.IsNullOrEmpty(result)) return new List<(string, bool)> { (original, true) };
            if (original == result) return new List<(string, bool)> { (original, false) };
            int m = original.Length, n = result.Length;
            int[,] dp = new int[m + 1, n + 1];
            for (int i = 1; i <= m; i++) for (int j = 1; j <= n; j++)
                dp[i, j] = original[i - 1] == result[j - 1] ? dp[i - 1, j - 1] + 1 : Math.Max(dp[i - 1, j], dp[i, j - 1]);
            var common = new bool[m]; int oi = m, ri = n;
            while (oi > 0 && ri > 0)
            {
                if (original[oi - 1] == result[ri - 1]) { common[oi - 1] = true; oi--; ri--; }
                else if (dp[oi - 1, ri] > dp[oi, ri - 1]) oi--; else ri--;
            }
            var segs = new List<(string text, bool changed)>();
            var buf = new StringBuilder(); bool inCh = !common[0];
            for (int i = 0; i < m; i++)
            {
                bool ch = !common[i];
                if (ch != inCh) { if (buf.Length > 0) segs.Add((buf.ToString(), inCh)); buf.Clear(); inCh = ch; }
                buf.Append(original[i]);
            }
            if (buf.Length > 0) segs.Add((buf.ToString(), inCh));
            return segs;
        }
    }

    // =========================================================================
    //  Diff ListView
    // =========================================================================

    internal class DiffListView : ListView
    {
        public Dictionary<int, (List<(string t, bool ch)> orig, List<(string t, bool ch)> res)> DiffData
            = new Dictionary<int, (List<(string t, bool ch)>, List<(string t, bool ch)>)>();

        public DiffListView()
        {
            this.OwnerDraw = true;
            this.DrawColumnHeader += (s, e) => e.DrawDefault = true;
            this.DrawSubItem += DrawSub;
            this.DrawItem += (s, e) => { };
        }

        private void DrawSub(object sender, DrawListViewSubItemEventArgs e)
        {
            if ((e.ColumnIndex != 0 && e.ColumnIndex != 1) || !DiffData.ContainsKey(e.ItemIndex))
            { e.DrawDefault = true; return; }
            var bounds = e.Bounds;
            using (var bg = new SolidBrush(e.Item.Selected ? SystemColors.Highlight : e.Item.BackColor))
                e.Graphics.FillRectangle(bg, bounds);
            var data = DiffData[e.ItemIndex];
            var segs = e.ColumnIndex == 0 ? data.orig : data.res;
            if (segs == null) { e.DrawDefault = true; return; }
            float x = bounds.Left + 2, y = bounds.Top + (bounds.Height - e.Item.Font.Height) / 2f;
            foreach (var (text, changed) in segs)
            {
                var color = changed ? (e.ColumnIndex == 0 ? Theme.Danger : Theme.Success) : e.Item.ForeColor;
                if (e.Item.Selected) color = Color.White;
                using var brush = new SolidBrush(color);
                if (changed)
                {
                    var sz = e.Graphics.MeasureString(text, e.Item.Font);
                    using var hi = new SolidBrush(e.Item.Selected ? Color.FromArgb(60, 255, 255, 255) :
                        (e.ColumnIndex == 0 ? Color.FromArgb(50, 220, 60, 60) : Color.FromArgb(50, 40, 200, 100)));
                    e.Graphics.FillRectangle(hi, x, bounds.Top, sz.Width, bounds.Height);
                }
                e.Graphics.DrawString(text, e.Item.Font, brush, x, y);
                x += e.Graphics.MeasureString(text, e.Item.Font).Width - 1;
            }
        }
    }

    // =========================================================================
    //  Extension registry + manager dialog
    // =========================================================================

    internal static class ExtensionRegistry
    {
        public static readonly HashSet<string> Default = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            ".ydd",".ydr",".yft",".ytd",".ymap",".ytyp",".ymf",".ybn",".ynv",".ynd",
            ".ycd",".yvr",".ywr",".ypt",".awc",".rel",".ysc",".ymt",".yld",".yed",
            ".yfd",".ypdb",".ybd",".ypl",".rpf",".dat",".gxt2",".meta",".xml",
            ".bik",".fxc",".gfx",".ync",
        };
        public static HashSet<string> UserAdded = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public static HashSet<string> All { get { var c = new HashSet<string>(Default, StringComparer.OrdinalIgnoreCase); foreach (var e in UserAdded) c.Add(e); return c; } }
        public static bool Add(string ext) { if (!ext.StartsWith(".")) ext = "." + ext; if (Default.Contains(ext)) return false; return UserAdded.Add(ext.ToLowerInvariant()); }
        public static bool Remove(string ext) { if (!ext.StartsWith(".")) ext = "." + ext; return UserAdded.Remove(ext.ToLowerInvariant()); }
    }

    internal class ExtensionManagerDialog : Form
    {
        private ListBox lstDefault, lstCustom;
        private TextBox txtNew;

        public ExtensionManagerDialog()
        {
            this.Text = "Manage File Extensions"; this.Size = new Size(620, 440);
            this.StartPosition = FormStartPosition.CenterParent; this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false; this.MinimizeBox = false;
            this.BackColor = Theme.Surface; this.ForeColor = Theme.Text;
            var lbl1 = Theme.MakeLabel("Built-in extensions (read-only)", muted: true); lbl1.Location = new Point(14, 12);
            lstDefault = new ListBox { Location = new Point(14, 32), Size = new Size(260, 320), BackColor = Theme.Background, ForeColor = Theme.TextDim, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f) };
            foreach (var e in ExtensionRegistry.Default.OrderBy(x => x)) lstDefault.Items.Add(e);
            var lbl2 = Theme.MakeLabel("Custom extensions", muted: true); lbl2.Location = new Point(288, 12);
            lstCustom = new ListBox { Location = new Point(288, 32), Size = new Size(190, 320), BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f) };
            RefreshCustom();
            txtNew = Theme.MakeTextBox(".myext", 130); txtNew.Location = new Point(288, 360);
            var btnAdd = Theme.MakeButton("+ Add", 70, isPrimary: true); btnAdd.Location = new Point(428, 359);
            var btnRemove = Theme.MakeButton("Remove", 70); btnRemove.Location = new Point(288, 391); btnRemove.ForeColor = Theme.Danger;
            var btnClose = Theme.MakeButton("Done", 70, isPrimary: true); btnClose.Location = new Point(508, 391); btnClose.DialogResult = DialogResult.OK;
            btnAdd.Click += (s, e) => { var ext = txtNew.Text.Trim(); if (string.IsNullOrEmpty(ext)) return; if (ExtensionRegistry.Add(ext)) { RefreshCustom(); txtNew.Clear(); } else MessageBox.Show("Already exists.", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Information); };
            btnRemove.Click += (s, e) => { if (lstCustom.SelectedItem == null) return; ExtensionRegistry.Remove(lstCustom.SelectedItem.ToString()); RefreshCustom(); };
            this.Controls.AddRange(new Control[] { lbl1, lstDefault, lbl2, lstCustom, txtNew, btnAdd, btnRemove, btnClose });
        }
        private void RefreshCustom() { lstCustom.Items.Clear(); foreach (var e in ExtensionRegistry.UserAdded.OrderBy(x => x)) lstCustom.Items.Add(e); }
    }

    // =========================================================================
    //  Main application shell
    // =========================================================================

    public class MainForm : Form
    {
        public MainForm()
        {
            this.Text = "GTA File Renamer  ·  OpenIV Edition";
            this.Size = new Size(1100, 750); this.MinimumSize = new Size(900, 580);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 9f);
            this.BackColor = Theme.Background; this.ForeColor = Theme.Text;
            this.Icon = SystemIcons.Application;

            var tabs = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) };
            var tabRename = new TabPage("  ✎  File Renamer  ");
            var tabEup = new TabPage("  📦  FiveM EUP → SP  ");
            var tabVehicleAddon = new TabPage("  🚗  Vehicle Addon  ");
            var tabAddon = new TabPage("  🔧  Addon Creator  ");
            var tabRpfExplorer = new TabPage("  🔍  RPF Explorer  ");
            var tabDlcManager = new TabPage("  📋  DLC Manager  ");
            var tabMetaEditor = new TabPage("  ✏  Meta Editor  ");
            var tabModOrganizer = new TabPage("  🗂  Mod Organizer  ");
            var tabBatch = new TabPage("  ⚡  Batch Processor  ");
            var tabToolbox = new TabPage("  🛠  Toolbox  ");
            var tabBudget = new TabPage("  📊  Stream Budget  ");
            var tabConflict = new TabPage("  ⚡  Conflict Detector  ");
            var tabScripts = new TabPage("  📜  Script Manager  ");
            var tabVehWizard = new TabPage("  🧙  Vehicle Wizard  ");
            var tabSettings = new TabPage("  ⚙  Settings  ");
            var allTabs = new[] { tabRename, tabEup, tabVehicleAddon, tabAddon, tabRpfExplorer, tabDlcManager, tabMetaEditor, tabModOrganizer, tabBatch, tabToolbox, tabBudget, tabConflict, tabScripts, tabVehWizard, tabSettings };
            foreach (var tp in allTabs) { tp.BackColor = Theme.Background; tp.ForeColor = Theme.Text; tabs.TabPages.Add(tp); }

            var renamePanel = new RenamePanel(); renamePanel.Dock = DockStyle.Fill; tabRename.Controls.Add(renamePanel);
            var eupPanel = new EupPanel(); eupPanel.Dock = DockStyle.Fill; tabEup.Controls.Add(eupPanel);
            var vehicleAddonPanel = new VehicleAddonPanel(); vehicleAddonPanel.Dock = DockStyle.Fill; tabVehicleAddon.Controls.Add(vehicleAddonPanel);
            var dlcManagerPanel = new DlcManagerPanel(); dlcManagerPanel.Dock = DockStyle.Fill; tabDlcManager.Controls.Add(dlcManagerPanel);
            var metaEditorPanel = new MetaEditorPanel(); metaEditorPanel.Dock = DockStyle.Fill; tabMetaEditor.Controls.Add(metaEditorPanel);
            var modOrganizerPanel = new ModOrganizerPanel(); modOrganizerPanel.Dock = DockStyle.Fill; tabModOrganizer.Controls.Add(modOrganizerPanel);
            var batchPanel = new BatchProcessorPanel(); batchPanel.Dock = DockStyle.Fill; tabBatch.Controls.Add(batchPanel);
            var toolboxPanel = new ToolboxPanel(); toolboxPanel.Dock = DockStyle.Fill; tabToolbox.Controls.Add(toolboxPanel);
            var budgetPanel = new StreamBudgetPanel(); budgetPanel.Dock = DockStyle.Fill; tabBudget.Controls.Add(budgetPanel);
            var conflictPanel = new ConflictDetectorPanel(); conflictPanel.Dock = DockStyle.Fill; tabConflict.Controls.Add(conflictPanel);
            var scriptsPanel = new ScriptManagerPanel(); scriptsPanel.Dock = DockStyle.Fill; tabScripts.Controls.Add(scriptsPanel);
            var wizardPanel = new VehicleWizardPanel(); wizardPanel.Dock = DockStyle.Fill; tabVehWizard.Controls.Add(wizardPanel);
            var settingsPanel = new AppSettingsPanel(); settingsPanel.Dock = DockStyle.Fill; tabSettings.Controls.Add(settingsPanel);
            var addonPanel = new AddonCreatorPanel(); addonPanel.Dock = DockStyle.Fill; tabAddon.Controls.Add(addonPanel);
            var rpfExplorerPanel = new RpfExplorerPanel(); rpfExplorerPanel.Dock = DockStyle.Fill; tabRpfExplorer.Controls.Add(rpfExplorerPanel);

            var btnTheme = Theme.MakeButton("☀ Light", 80);
            btnTheme.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnTheme.Click += (s, e) =>
            {
                Theme.ToggleTheme();
                btnTheme.Text = Theme.IsDark ? "☀ Light" : "🌙 Dark";
                btnTheme.BackColor = Theme.Surface2; btnTheme.ForeColor = Theme.Muted;
                btnTheme.FlatAppearance.BorderColor = Theme.Border;
                this.BackColor = Theme.Background;
                foreach (var tp in allTabs) tp.BackColor = Theme.Background;
            };
            this.Controls.Add(tabs); this.Controls.Add(btnTheme);
            _ = this.Handle;
            this.Shown += (s, e) => btnTheme.Location = new Point(this.ClientSize.Width - btnTheme.Width - 8, 4);
            this.Resize += (s, e) => btnTheme.Location = new Point(this.ClientSize.Width - btnTheme.Width - 8, 4);
            Theme.ThemeChanged += () => { foreach (var tp in allTabs) tp.BackColor = Theme.Background; };
        }
    }

    // =========================================================================
    //  GroupStatusFilter
    // =========================================================================

    internal enum GroupStatusFilter { All, NeedsConfig, Ready, NoChange }

    // =========================================================================
    //  RenamePanel  (unchanged from original)
    // =========================================================================

    internal class RenamePanel : UserControl
    {
        private ComboBox cboMatchMode;
        private TextBox txtSearch, txtFilter;
        private Button btnAddFiles, btnAddFolder, btnRename, btnClear, btnUndo, btnExport, btnExtMgr;
        private Button btnCollapseAll, btnExpandAll, btnGroupsOnly, btnNextUnconfigured;
        private CheckBox chkCompact;
        private CheckBox chkAutoSyncNumber;
        private TextBox txtAutoNumBase;
        private ComboBox cboAutoNumMode;
        private CheckBox chkAutoNumPerSlot;
        private Button btnAutoNumber;
        private ComboBox cboStatusFilter;
        private DiffListView listView;
        private Label lblStatus, lblTotalFiles, lblTotalGroups, lblReadyCount, lblNoMatchCount;
        private ProgressBar progressBar;
        private Label lblProgress;
        private Panel progressPanel, dropHintPanel;
        private List<FileGroup> groups = new List<FileGroup>();
        private static readonly Regex DigitRun = new Regex(@"\d+");
        private ToolTip toolTip;
        private bool _groupsOnlyMode = false;
        private bool _compactMode = false;
        private bool _autoSyncSameNumber = false;
        private GroupStatusFilter _statusFilter = GroupStatusFilter.All;

        public RenamePanel()
        {
            this.BackColor = Theme.Background;
            this.AllowDrop = true;
            this.DragEnter += Unified_DragEnter;
            this.DragDrop += Unified_DragDrop;
            Theme.ThemeChanged += ApplyTheme;
            Build();
        }

        private void ApplyTheme()
        {
            this.BackColor = Theme.Background;
            if (listView != null) { listView.BackColor = Theme.ListBg; listView.ForeColor = Theme.Text; }
            RebuildList();
        }

        private Button MB(string t, int w, bool primary = false) => Theme.MakeButton(t, w, 26, primary);
        private Button MBIcon(string icon, int w, string tip)
        {
            var b = Theme.MakeButton(icon, w, 26);
            b.Font = new Font("Segoe UI", 9.5f);
            toolTip.SetToolTip(b, tip);
            return b;
        }

        private void Build()
        {
            toolTip = new ToolTip();
            const int PAD = 12, ROW_A = 10, ROW_B = 52, CBO_H = 22;

            var topPanel = new Panel { Dock = DockStyle.Top, Height = 122, BackColor = Theme.Surface };
            topPanel.Paint += (s, e) => { using var pen = new Pen(Theme.Border); e.Graphics.DrawLine(pen, PAD, 44, topPanel.Width - PAD, 44); };

            var lblMode = Theme.MakeLabel("Mode"); lblMode.Location = new Point(PAD, ROW_A + 4);
            cboMatchMode = new ComboBox { Location = new Point(46, ROW_A), Width = 200, Height = CBO_H, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Theme.Background, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) };
            cboMatchMode.Items.AddRange(new object[] { "Variant number only (recommended)", "All numbers in filename", "First number only", "Last number only", "Specific number (search below)" });
            cboMatchMode.SelectedIndex = 0;
            cboMatchMode.SelectedIndexChanged += (s, e) => { txtSearch.Enabled = cboMatchMode.SelectedIndex == 4; RebuildList(); };

            var lblSearch = Theme.MakeLabel("Find"); lblSearch.Location = new Point(254, ROW_A + 4);
            txtSearch = Theme.MakeTextBox("e.g. 007", 70); txtSearch.Location = new Point(280, ROW_A + 1); txtSearch.MaxLength = 20; txtSearch.Enabled = false;
            txtSearch.TextChanged += (s, e) => RebuildList();

            var lblFilter = Theme.MakeLabel("Filter"); lblFilter.Location = new Point(360, ROW_A + 4);
            txtFilter = Theme.MakeTextBox("Search files…", 150); txtFilter.Location = new Point(395, ROW_A + 1);
            txtFilter.TextChanged += (s, e) => RebuildList();

            btnExport = MB("Export CSV", 92); btnExport.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnExtMgr = MB("Extensions", 92); btnExtMgr.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnExport.Click += BtnExport_Click;
            btnExtMgr.Click += (s, e) => { using var dlg = new ExtensionManagerDialog(); dlg.ShowDialog(this.FindForm()); };

            btnAddFiles = MB("＋ Add Files", 95, true);
            btnAddFolder = MB("＋ Folder", 78);
            btnClear = MB("✕ Clear", 60);
            btnClear.BackColor = Color.FromArgb(60, 28, 28); btnClear.ForeColor = Theme.Danger; btnClear.FlatAppearance.BorderColor = Color.FromArgb(80, 40, 40);
            btnUndo = MB(RenameHistory.UndoButtonText, 190); btnUndo.Enabled = false;
            var btnSaveConfig = MB("💾 Save Config", 110);
            var btnLoadConfig = MB("📁 Load Config", 110);

            btnAddFiles.Location = new Point(PAD, ROW_B);
            btnAddFolder.Location = new Point(PAD + 100, ROW_B);
            btnClear.Location = new Point(PAD + 183, ROW_B);
            btnUndo.Location = new Point(PAD + 248, ROW_B);
            const int ROW_C = ROW_B + 34;
            btnSaveConfig.Location = new Point(PAD, ROW_C);
            btnLoadConfig.Location = new Point(PAD + 116, ROW_C);
            var lblConfigHint = Theme.MakeLabel("Save/reload which target numbers and conversion modes were set per file-group, by matching filenames.", muted: true);
            lblConfigHint.Location = new Point(PAD + 236, ROW_C + 4);
            btnSaveConfig.Location = new Point(PAD + 443, ROW_B);
            btnLoadConfig.Location = new Point(PAD + 558, ROW_B);

            btnAddFiles.Click += BtnAddFiles_Click;
            btnAddFolder.Click += BtnAddFolder_Click;
            btnClear.Click += (s, e) => { groups.Clear(); RebuildList(); RefreshDropHint(); };
            btnUndo.Click += BtnUndo_Click;

            var sep = new Panel { Location = new Point(PAD + 443, ROW_B), Width = 1, Height = 26, BackColor = Theme.Border };

            btnCollapseAll = MBIcon("⊟", 34, "Collapse all"); btnCollapseAll.Location = new Point(PAD + 450, ROW_B);
            btnExpandAll = MBIcon("⊞", 34, "Expand all"); btnExpandAll.Location = new Point(PAD + 488, ROW_B);
            btnGroupsOnly = MBIcon("☰", 34, "Headers only"); btnGroupsOnly.Location = new Point(PAD + 526, ROW_B);
            btnNextUnconfigured = MB("⏭ Next ⚠", 92); btnNextUnconfigured.Location = new Point(PAD + 566, ROW_B);
            btnNextUnconfigured.ForeColor = Theme.Warning;

            btnCollapseAll.Click += (s, e) => { foreach (var g in groups) g.Collapsed = true; RebuildList(); };
            btnExpandAll.Click += (s, e) => { foreach (var g in groups) g.Collapsed = false; RebuildList(); };
            btnGroupsOnly.Click += (s, e) => { _groupsOnlyMode = !_groupsOnlyMode; btnGroupsOnly.BackColor = _groupsOnlyMode ? Theme.AccentDim : Theme.Surface2; btnGroupsOnly.ForeColor = _groupsOnlyMode ? Color.White : Theme.Text; RebuildList(); };
            btnNextUnconfigured.Click += (s, e) => ScrollToNextUnconfigured();

            var lblShow = Theme.MakeLabel("Show"); lblShow.Location = new Point(PAD + 668, ROW_B + 5);
            cboStatusFilter = new ComboBox { Location = new Point(PAD + 696, ROW_B + 1), Width = 118, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Theme.Background, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) };
            cboStatusFilter.Items.AddRange(new object[] { "All groups", "Needs config", "All ready", "No change" }); cboStatusFilter.SelectedIndex = 0;
            cboStatusFilter.SelectedIndexChanged += (s, e) => { _statusFilter = (GroupStatusFilter)cboStatusFilter.SelectedIndex; RebuildList(); };

            chkCompact = new CheckBox { Text = "Compact", AutoSize = true, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            chkCompact.Location = new Point(PAD + 820, ROW_B + 5);
            chkCompact.CheckedChanged += (s, e) => { _compactMode = chkCompact.Checked; RebuildList(); };

            // When checked, setting a group's target number automatically
            // applies the same number to every other group that shares both
            // the same component slot AND the same original number (e.g.
            // jbib_035_u.ydd and jbib_diff_035_a.ytd renumbering together
            // instantly) — narrower than the existing per-dialog "sync
            // linked" checkbox, which only matches by component slot and
            // ignores the original number entirely.
            chkAutoSyncNumber = new CheckBox { Text = "Auto-sync same number", AutoSize = true, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            chkAutoSyncNumber.Location = new Point(PAD + 900, ROW_B + 5);
            chkAutoSyncNumber.CheckedChanged += (s, e) =>
            {
                _autoSyncSameNumber = chkAutoSyncNumber.Checked;
                // Apply retroactively too — without this, checking the box
                // only affects groups configured AFTER this point, leaving
                // already-configured groups (like a group you set up before
                // ticking the box) un-synced with their same-number siblings.
                if (_autoSyncSameNumber) ApplyAutoSyncToAllGroups();
                RebuildList();
            };

            btnSaveConfig.Click += (s, e) => SaveGroupConfig();
            btnLoadConfig.Click += (s, e) => LoadGroupConfig();

            topPanel.Resize += (s, e) => { int r = topPanel.Width - PAD; btnExtMgr.Location = new Point(r - 92, ROW_A); btnExport.Location = new Point(r - 188, ROW_A); };
            topPanel.Controls.AddRange(new Control[] {
                lblMode, cboMatchMode, lblSearch, txtSearch, lblFilter, txtFilter,
                btnExport, btnExtMgr, btnAddFiles, btnAddFolder, btnClear, btnUndo,
                sep, btnCollapseAll, btnExpandAll, btnGroupsOnly, btnNextUnconfigured,
                lblShow, cboStatusFilter, chkCompact, chkAutoSyncNumber,
                btnSaveConfig, btnLoadConfig, lblConfigHint });

            var infoBar = new Panel { Dock = DockStyle.Top, Height = 30, BackColor = Color.FromArgb(15, 15, 20) };
            lblTotalFiles = new Label { Text = "0 files", AutoSize = true, Location = new Point(PAD, 8), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f) };
            lblTotalGroups = new Label { Text = "0 groups", AutoSize = true, Location = new Point(130, 8), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f) };
            lblReadyCount = new Label { Text = "0 ready", AutoSize = true, Location = new Point(270, 8), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f) };
            lblNoMatchCount = new Label { Text = "", AutoSize = true, Location = new Point(410, 8), ForeColor = Theme.Danger, Font = new Font("Segoe UI", 8.5f) };
            infoBar.Controls.AddRange(new Control[] { lblTotalFiles, lblTotalGroups, lblReadyCount, lblNoMatchCount });

            listView = new DiffListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, GridLines = false, Font = new Font("Consolas", 8.5f), BackColor = Theme.ListBg, ForeColor = Theme.Text, BorderStyle = BorderStyle.None };
            listView.MouseUp += (s, e) =>
            {
                if (e.Button != MouseButtons.Right) return;
                var hit = listView.HitTest(e.Location);
                if (hit.Item == null) return;
                listView.SelectedItems.Clear();
                hit.Item.Selected = true;

                string tag = hit.Item.Tag as string;
                if (string.IsNullOrEmpty(tag) || !tag.StartsWith("FILE:")) return; // group headers have no single file to act on
                if (!int.TryParse(tag.Substring(5), out int gi) || gi < 0 || gi >= groups.Count) return;

                string fileName = hit.Item.Text.TrimStart(' ');
                string fullPath = groups[gi].Paths.FirstOrDefault(p => Path.GetFileName(p) == fileName);
                if (fullPath == null) return;

                var menu = new ContextMenuStrip();
                menu.Items.Add("📂 Open Containing Folder", null, (s2, e2) =>
                {
                    if (File.Exists(fullPath)) System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{fullPath}\"");
                });
                menu.Items.Add("📋 Copy Full Path", null, (s2, e2) => Clipboard.SetText(fullPath));
                menu.Items.Add("📋 Copy Filename", null, (s2, e2) => Clipboard.SetText(fileName));
                menu.Show(listView, e.Location);
            };
            listView.Columns.Add("Original Filename", 340);
            listView.Columns.Add("→  Result Filename", 340);
            listView.Columns.Add("Ext", 55);
            listView.Columns.Add("Status", 100);
            listView.AllowDrop = true;
            listView.DragEnter += Unified_DragEnter;
            listView.DragDrop += Unified_DragDrop;

            dropHintPanel = new Panel { Dock = DockStyle.Fill, BackColor = Theme.ListBg, Visible = true };
            dropHintPanel.AllowDrop = true; dropHintPanel.DragEnter += Unified_DragEnter; dropHintPanel.DragDrop += Unified_DragDrop;
            var lblDrop = new Label { Text = "Drag & drop GTA files or folders here\nor use the buttons above", TextAlign = ContentAlignment.MiddleCenter, Dock = DockStyle.Fill, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 11f), BackColor = Color.Transparent };
            lblDrop.AllowDrop = true; lblDrop.DragEnter += Unified_DragEnter; lblDrop.DragDrop += Unified_DragDrop;
            dropHintPanel.Controls.Add(lblDrop);

            var listContainer = new Panel { Dock = DockStyle.Fill };
            listContainer.Controls.Add(listView); listContainer.Controls.Add(dropHintPanel);

            progressPanel = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = Theme.Surface, Visible = false, Padding = new Padding(PAD, 4, PAD, 4) };
            progressBar = new ProgressBar { Location = new Point(PAD, 5), Height = 18, Width = 560, Style = ProgressBarStyle.Continuous, BackColor = Theme.Background, ForeColor = Theme.Accent, Minimum = 0, Maximum = 100 };
            lblProgress = new Label { AutoSize = true, Location = new Point(582, 7), ForeColor = Theme.Text, Font = new Font("Segoe UI", 8.5f) };
            progressPanel.Controls.AddRange(new Control[] { progressBar, lblProgress });

            var bottomPanel = new Panel { Dock = DockStyle.Bottom, Height = 46, Padding = new Padding(PAD, 8, PAD, 0), BackColor = Theme.Surface };
            btnRename = Theme.MakeButton("▶ Rename All Groups", 162, 28, true);
            btnRename.Location = new Point(PAD, 8); btnRename.Enabled = false;
            btnRename.Click += BtnRename_Click;
            lblStatus = new Label { Text = "Add files to get started.", AutoSize = true, Location = new Point(185, 14), ForeColor = Theme.Muted };
            bottomPanel.Controls.AddRange(new Control[] { btnRename, lblStatus });

            foreach (var p in new Control[] { topPanel, infoBar, bottomPanel })
            { p.AllowDrop = true; p.DragEnter += Unified_DragEnter; p.DragDrop += Unified_DragDrop; }

            this.Controls.Add(listContainer);
            this.Controls.Add(progressPanel);
            this.Controls.Add(bottomPanel);
            this.Controls.Add(infoBar);
            this.Controls.Add(topPanel);
        }


        private static string Skeleton(string fileName)
        {
            var ext = Path.GetExtension(fileName);
            return DigitRun.Replace(Path.GetFileNameWithoutExtension(fileName), "▪") + ext;
        }

        private static string GetVariantNumber(string fileNameNoExt)
        {
            var matches = DigitRun.Matches(fileNameNoExt);
            for (int i = matches.Count - 1; i >= 0; i--)
                if (matches[i].Length >= 3) return matches[i].Value;
            return matches.Count > 0 ? matches[matches.Count - 1].Value : "";
        }

        private bool IsGroupAllReady(FileGroup grp) => grp.Paths.Count > 0 && grp.Paths.All(p => GetNewName(Path.GetFileName(p), grp.TargetNumber, grp) != null);
        private bool IsGroupNeedsConfig(FileGroup grp) => grp.ConvertMode == FormatMode.None && string.IsNullOrEmpty(grp.TargetNumber);

        private bool GroupMatchesStatusFilter(FileGroup grp)
        {
            switch (_statusFilter)
            {
                case GroupStatusFilter.NeedsConfig: return IsGroupNeedsConfig(grp);
                case GroupStatusFilter.Ready: return IsGroupAllReady(grp);
                case GroupStatusFilter.NoChange: return grp.Paths.Any(p => { var nn = GetNewName(Path.GetFileName(p), grp.TargetNumber, grp); return nn == null && !IsGroupNeedsConfig(grp); });
                default: return true;
            }
        }

        private void ScrollToNextUnconfigured()
        {
            int start = listView.SelectedItems.Count > 0 ? listView.SelectedItems[0].Index + 1 : 0;
            for (int pass = 0; pass < 2; pass++)
            {
                int lo = pass == 0 ? start : 0, hi = pass == 0 ? listView.Items.Count : Math.Min(start, listView.Items.Count);
                for (int i = lo; i < hi; i++)
                {
                    var tag = listView.Items[i].Tag as string ?? "";
                    if (!tag.StartsWith("GROUP:")) continue;
                    int gi = int.Parse(tag.Substring(6)); if (gi >= groups.Count) continue;
                    if (IsGroupNeedsConfig(groups[gi])) { listView.SelectedItems.Clear(); listView.Items[i].Selected = true; listView.Items[i].EnsureVisible(); listView.Focus(); return; }
                }
            }
        }

        private void AddToGroups(IEnumerable<string> paths)
        {
            var fiveMDetected = new List<FileGroup>();
            foreach (var path in paths)
            {
                if (!ExtensionRegistry.All.Contains(Path.GetExtension(path))) continue;
                var fileName = Path.GetFileName(path);
                var baseNoExt = Path.GetFileNameWithoutExtension(fileName);
                var skeleton = Skeleton(fileName);
                var ext = Path.GetExtension(path);
                var slot = ComponentSlots.Detect(skeleton);
                var varNum = GetVariantNumber(baseNoExt);
                string groupKey = (!string.IsNullOrEmpty(slot) && !string.IsNullOrEmpty(varNum)) ? $"{slot}:{varNum}" : skeleton;
                var group = groups.FirstOrDefault(g => g.Key == groupKey);
                if (group == null)
                {
                    group = new FileGroup(groupKey, ext) { ComponentRoot = slot, VariantNumber = varNum };
                    var prefix = FormatConverter.DetectFiveMPrefix(baseNoExt);
                    if (prefix != null) { group.FiveMPrefix = prefix; fiveMDetected.Add(group); }
                    groups.Add(group);
                }
                if (!group.Paths.Contains(path)) group.Paths.Add(path);
            }
            foreach (var g in groups) g.DominantNumber = ComponentSlots.DominantNumber(g);

            bool applyAll = false; DialogResult cachedResult = DialogResult.None; string cachedPrefix = null;
            for (int fi = 0; fi < fiveMDetected.Count; fi++)
            {
                var grp = fiveMDetected[fi];
                if (applyAll) { ApplyFiveMChoice(grp, cachedResult, cachedPrefix); continue; }
                int remaining = fiveMDetected.Count - fi - 1;
                var example = Path.GetFileName(grp.Paths[0]);
                var spExample = FormatConverter.ToSP(Path.GetFileNameWithoutExtension(example)) + Path.GetExtension(example);
                using var dlg = new FiveMConvertDialog(example, spExample, grp.FiveMPrefix, remaining);
                var result = dlg.ShowDialog(this.FindForm());
                ApplyFiveMChoice(grp, result, dlg.ChosenSPToFiveMPrefix);
                if (dlg.ApplyForAll) { applyAll = true; cachedResult = result; cachedPrefix = dlg.ChosenSPToFiveMPrefix; }
            }
            if (_compactMode) foreach (var g in groups) if (IsGroupAllReady(g)) g.Collapsed = true;
        }

        private static void ApplyFiveMChoice(FileGroup grp, DialogResult result, string chosenPrefix)
        {
            if (result == DialogResult.Yes) grp.ConvertMode = FormatMode.FiveMToSP;
            else if (result == DialogResult.Cancel && chosenPrefix != null) { grp.ConvertMode = FormatMode.SPToFiveM; grp.FiveMPrefix = chosenPrefix; }
            else grp.ConvertMode = FormatMode.None;
        }

        private List<FileGroup> GetLinkedGroups(FileGroup grp)
        {
            if (string.IsNullOrEmpty(grp.ComponentRoot)) return new List<FileGroup>();
            return groups.Where(g => g != grp && g.ComponentRoot == grp.ComponentRoot).ToList();
        }

        /// <summary>
        /// Narrower than GetLinkedGroups — matches by component slot AND
        /// original variant number together (e.g. only other jbib_035_*
        /// groups, not jbib_002_* or hair_035_*), for the "Auto-sync same
        /// number" toolbar checkbox.
        /// </summary>
        private List<FileGroup> GetGroupsWithSameNumber(FileGroup grp)
        {
            if (string.IsNullOrEmpty(grp.ComponentRoot) || string.IsNullOrEmpty(grp.VariantNumber))
                return new List<FileGroup>();
            return groups.Where(g => g != grp
                && g.ComponentRoot == grp.ComponentRoot
                && g.VariantNumber == grp.VariantNumber).ToList();
        }

        /// <summary>
        /// Runs once, immediately, when "Auto-sync same number" gets checked —
        /// for every (component, original number) family that already has at
        /// least one group with a target number set, propagates that number
        /// to every other group in the same family. Processes groups in list
        /// order, so whichever group in a family was configured first "wins"
        /// if more than one already had a (possibly different) number set.
        /// </summary>
        private void ApplyAutoSyncToAllGroups()
        {
            var seen = new HashSet<(string root, string num)>();
            foreach (var g in groups)
            {
                if (string.IsNullOrEmpty(g.TargetNumber) || string.IsNullOrEmpty(g.ComponentRoot) || string.IsNullOrEmpty(g.VariantNumber))
                    continue;
                var key = (g.ComponentRoot, g.VariantNumber);
                if (!seen.Add(key)) continue; // this family already handled by an earlier group
                foreach (var sg in GetGroupsWithSameNumber(g)) sg.TargetNumber = g.TargetNumber;
            }
            foreach (var g in groups) g.DominantNumber = ComponentSlots.DominantNumber(g);
        }

        private string GetNewName(string originalFileName, string newNum, FileGroup grp)
        {
            var ext = Path.GetExtension(originalFileName);
            var baseName = Path.GetFileNameWithoutExtension(originalFileName);
            string converted = baseName;
            bool didConvert = false;

            if (grp.ConvertMode == FormatMode.FiveMToSP) { var s = FormatConverter.ToSP(baseName); if (s != baseName) { converted = s; didConvert = true; } }
            else if (grp.ConvertMode == FormatMode.SPToFiveM) { converted = FormatConverter.ToFiveM(baseName, grp.FiveMPrefix); didConvert = true; }

            string final = converted; bool didRename = false;
            if (!string.IsNullOrEmpty(newNum))
            {
                string newBase;
                switch (cboMatchMode.SelectedIndex)
                {
                    case 0:
                        if (!string.IsNullOrEmpty(grp.VariantNumber)) newBase = new Regex(@"(?<!\d)" + Regex.Escape(grp.VariantNumber) + @"(?!\d)").Replace(converted, newNum);
                        else { var allM = DigitRun.Matches(converted); newBase = allM.Count == 0 ? converted : ReplaceAt(converted, allM[allM.Count - 1], newNum); }
                        break;
                    case 1: newBase = DigitRun.Replace(converted, newNum); break;
                    case 2: newBase = ReplaceNth(converted, newNum, 0); break;
                    case 3: var all = DigitRun.Matches(converted); newBase = all.Count == 0 ? converted : ReplaceAt(converted, all[all.Count - 1], newNum); break;
                    case 4: var search = txtSearch.Text.Trim(); newBase = string.IsNullOrEmpty(search) ? converted : new Regex(@"(?<!\d)" + Regex.Escape(search) + @"(?!\d)").Replace(converted, newNum); break;
                    default: newBase = converted; break;
                }
                if (newBase != converted) { final = newBase; didRename = true; }
            }
            if (!didConvert && !didRename) return null;
            var result = final + ext;
            return result == originalFileName ? null : result;
        }

        private static string ReplaceNth(string input, string r, int nth)
        { var m = DigitRun.Matches(input); return m.Count <= nth ? input : ReplaceAt(input, m[nth], r); }

        private static string ReplaceAt(string input, Match m, string r)
            => input.Substring(0, m.Index) + r + input.Substring(m.Index + m.Length);

        private void Unified_DragEnter(object sender, DragEventArgs e) => e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
        private void Unified_DragDrop(object sender, DragEventArgs e)
        {
            var paths = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (paths?.Length > 0) { AddToGroups(ExpandPaths(paths)); RebuildList(); RefreshDropHint(); }
        }

        private static IEnumerable<string> ExpandPaths(string[] paths)
        {
            foreach (var p in paths)
            {
                if (File.Exists(p)) yield return p;
                else if (Directory.Exists(p)) foreach (var f in Directory.GetFiles(p, "*.*", SearchOption.AllDirectories)) yield return f;
            }
        }

        private void BtnAddFiles_Click(object sender, EventArgs e)
        {
            var exts = string.Join(";", ExtensionRegistry.All.Select(x => "*" + x));
            using var dlg = new OpenFileDialog { Title = "Select GTA / OpenIV files", Filter = $"OpenIV Files ({exts})|{exts}|All Files (*.*)|*.*", Multiselect = true };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            AddToGroups(dlg.FileNames); RebuildList(); RefreshDropHint();
        }

        private void BtnAddFolder_Click(object sender, EventArgs e)
        {
            using var dlg = new FolderBrowserDialog { Description = "Select folder containing GTA files" };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            AddToGroups(Directory.GetFiles(dlg.SelectedPath, "*.*", SearchOption.AllDirectories)); RebuildList(); RefreshDropHint();
        }

        private void RefreshDropHint()
        {
            int total = groups.Sum(g => g.Paths.Count);
            dropHintPanel.Visible = total == 0; listView.Visible = total > 0;
        }

        private void BtnExport_Click(object sender, EventArgs e)
        {
            var plan = groups.SelectMany(grp => grp.Paths.Select(p => new {
                Group = grp.Key,
                Directory = Path.GetDirectoryName(p),
                Original = Path.GetFileName(p),
                Result = GetNewName(Path.GetFileName(p), grp.TargetNumber, grp) ?? Path.GetFileName(p),
                WillChange = GetNewName(Path.GetFileName(p), grp.TargetNumber, grp) != null
            })).ToList();
            if (plan.Count == 0) { MessageBox.Show("No files loaded.", "Nothing to export", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }

            var result = MessageBox.Show("Export as GTA V Add-on DLC package?\n(No = export CSV rename plan)",
                "Export Mode", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return;

            if (result == DialogResult.Yes)
            {
                using var srcDlg = new FolderBrowserDialog { Description = "Select converted vehicle files folder" };
                if (srcDlg.ShowDialog() != DialogResult.OK) return;
                using var outDlg = new FolderBrowserDialog { Description = "Select output root folder" };
                if (outDlg.ShowDialog() != DialogResult.OK) return;
                string dlcName = Microsoft.VisualBasic.Interaction.InputBox("Enter DLC name (lowercase, no spaces):", "DLC Name", "my_vehicle_dlc");
                if (string.IsNullOrWhiteSpace(dlcName)) return;
                try
                {
                    AddonGenerator1.ExportFullDlcPackage(outDlg.SelectedPath, dlcName,
                        new List<AddonVehicleEntry>(), new List<AddonPedEntry>(), srcDlg.SelectedPath);
                    MessageBox.Show($"DLC built!\n\n{outDlg.SelectedPath}\\dlcpacks\\{dlcName}", "DLC Built", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    System.Diagnostics.Process.Start("explorer.exe", $"\"{Path.Combine(outDlg.SelectedPath, "dlcpacks", dlcName)}\"");
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            else
            {
                using var saveDlg = new SaveFileDialog { Title = "Save rename plan", Filter = "CSV|*.csv", FileName = "rename_plan.csv" };
                if (saveDlg.ShowDialog() != DialogResult.OK) return;
                var lines = new List<string> { "Group,Directory,Original,Result,WillChange" };
                lines.AddRange(plan.Select(r => $"\"{r.Group}\",\"{r.Directory}\",\"{r.Original}\",\"{r.Result}\",{r.WillChange}"));
                File.WriteAllLines(saveDlg.FileName, lines, Encoding.UTF8);
                MessageBox.Show($"Exported {plan.Count} rows.", "Export Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // ── Save/Load Config — persists each group's TargetNumber/
        //    ConvertMode/FiveMPrefix keyed by its Key, so re-running this
        //    on a similar batch of files (e.g. an updated FiveM export)
        //    doesn't mean re-configuring every group by hand again. Only
        //    reapplies to groups whose Key matches what's currently
        //    loaded — anything not found in the current scan is just
        //    skipped rather than causing an error. ─────────────────────
        private void SaveGroupConfig()
        {
            if (groups.Count == 0) { MessageBox.Show("Nothing to save — add files first.", "Nothing To Save", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }

            using var dlg = new SaveFileDialog { Filter = "Rename Config|*.renameconfig", FileName = "rename_config.renameconfig" };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            var sb = new System.Text.StringBuilder();
            foreach (var g in groups)
                sb.AppendLine($"{g.Key}|{g.TargetNumber}|{(int)g.ConvertMode}|{g.FiveMPrefix}");

            File.WriteAllText(dlg.FileName, sb.ToString(), System.Text.Encoding.UTF8);
            lblStatus.Text = $"✔ Saved config for {groups.Count} group(s)."; lblStatus.ForeColor = Theme.Success;
        }

        private void LoadGroupConfig()
        {
            if (groups.Count == 0) { MessageBox.Show("Add files first, then load a config to apply to matching groups.", "Add Files First", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }

            using var dlg = new OpenFileDialog { Filter = "Rename Config|*.renameconfig|All files|*.*" };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                var byKey = groups.ToDictionary(g => g.Key, g => g);
                int applied = 0, skipped = 0;
                foreach (var line in File.ReadAllLines(dlg.FileName))
                {
                    var parts = line.Split('|');
                    if (parts.Length != 4) continue;
                    if (!byKey.TryGetValue(parts[0], out var g)) { skipped++; continue; }

                    g.TargetNumber = parts[1];
                    if (int.TryParse(parts[2], out int modeVal) && Enum.IsDefined(typeof(FormatMode), modeVal))
                        g.ConvertMode = (FormatMode)modeVal;
                    g.FiveMPrefix = parts[3];
                    applied++;
                }

                if (_autoSyncSameNumber) ApplyAutoSyncToAllGroups();
                RebuildList();
                lblStatus.Text = $"✔ Applied config to {applied} group(s)" + (skipped > 0 ? $", {skipped} not found in current file list." : ".");
                lblStatus.ForeColor = Theme.Success;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Couldn't load config: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUndo_Click(object sender, EventArgs e)
        {
            if (!RenameHistory.CanUndo) return;
            var op = RenameHistory.Peek();
            if (MessageBox.Show($"Undo {op.SuccessCount} renames from {op.Timestamp:HH:mm:ss}?", "Confirm Undo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            RenameHistory.Pop(); int success = 0, failed = 0;
            foreach (var (oldPath, newPath) in op.Renames)
            {
                try
                {
                    if (File.Exists(newPath) && !File.Exists(oldPath))
                    { File.Move(newPath, oldPath); foreach (var grp in groups) { int idx = grp.Paths.IndexOf(newPath); if (idx >= 0) grp.Paths[idx] = oldPath; } success++; }
                    else failed++;
                }
                catch { failed++; }
            }
            RebuildList(); RefreshDropHint();
            lblStatus.Text = $"↩ Undo — {success} restored, {failed} failed."; lblStatus.ForeColor = failed > 0 ? Theme.Danger : Theme.Success;
            btnUndo.Text = RenameHistory.UndoButtonText; btnUndo.Enabled = RenameHistory.CanUndo;
        }

        private void RebuildList()
        {
            listView.BeginUpdate(); listView.Items.Clear(); listView.DiffData.Clear();
            var filterText = txtFilter?.Text?.Trim() ?? "";
            int totalReady = 0, totalNoMatch = 0, totalFiles = 0, unconfigured = 0;

            for (int gi = 0; gi < groups.Count; gi++)
            {
                var grp = groups[gi];
                if (!GroupMatchesStatusFilter(grp)) continue;
                var filteredPaths = string.IsNullOrEmpty(filterText) ? grp.Paths : grp.Paths.Where(p => Path.GetFileName(p).IndexOf(filterText, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
                if (!string.IsNullOrEmpty(filterText) && filteredPaths.Count == 0) continue;
                totalFiles += grp.Paths.Count;
                int grpReady = grp.Paths.Count(p => GetNewName(Path.GetFileName(p), grp.TargetNumber, grp) != null);
                bool allReady = grpReady == grp.Paths.Count && grp.Paths.Count > 0;
                var linked = GetLinkedGroups(grp); bool isLinked = linked.Count > 0 && !string.IsNullOrEmpty(grp.ComponentRoot);
                bool needsConf = IsGroupNeedsConfig(grp); if (needsConf) unconfigured++;
                bool collapsed = _groupsOnlyMode || grp.Collapsed || (_compactMode && allReady);

                Color hdrBg = grp.ConvertMode == FormatMode.FiveMToSP ? Theme.FiveMBg :
                              grp.ConvertMode == FormatMode.SPToFiveM ? Theme.SPBg :
                              isLinked ? Theme.LinkedBg : Theme.GroupBg;
                string fmtBadge = grp.ConvertMode == FormatMode.FiveMToSP ? "  [FiveM→SP]" : grp.ConvertMode == FormatMode.SPToFiveM ? $"  [SP→FiveM({grp.FiveMPrefix})]" : "";
                string slotBadge = !string.IsNullOrEmpty(grp.ComponentRoot) ? $"  [{grp.ComponentRoot.ToUpper()}]" : "";
                string syncBadge = isLinked ? $"  🔗 {linked.Count} linked" : "";
                string target = string.IsNullOrEmpty(grp.TargetNumber) ? "[ double-click to configure ]" : $"Target → {grp.TargetNumber}";
                string displayKey = grp.Key.Contains(':') ? $"{grp.ComponentRoot.ToUpper()}_{grp.VariantNumber}  ({grp.Paths.Count} file{(grp.Paths.Count != 1 ? "s" : "")})" : grp.Key;
                string colIcon = collapsed ? "▶ " : "▼ ";
                string warnBadge = needsConf ? " ⚠" : "";

                var header = new ListViewItem
                {
                    Text = $"  {colIcon}GROUP {gi + 1}{slotBadge}{fmtBadge}  —  {displayKey}{syncBadge}{warnBadge}",
                    BackColor = hdrBg,
                    ForeColor = needsConf ? Theme.Warning : Theme.Accent,
                    Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                    Tag = $"GROUP:{gi}",
                    UseItemStyleForSubItems = false
                };
                header.SubItems.Add(new ListViewItem.ListViewSubItem { Text = target, ForeColor = string.IsNullOrEmpty(grp.TargetNumber) ? Theme.Muted : Theme.Warning, BackColor = hdrBg });
                header.SubItems.Add(new ListViewItem.ListViewSubItem { Text = grp.Extension, ForeColor = Theme.Muted, BackColor = hdrBg });
                header.SubItems.Add(new ListViewItem.ListViewSubItem { Text = $"{grpReady}/{grp.Paths.Count} ready", ForeColor = allReady ? Theme.Success : grpReady > 0 ? Theme.Warning : Theme.Muted, BackColor = hdrBg });
                listView.Items.Add(header);

                if (!collapsed)
                {
                    foreach (var path in filteredPaths.OrderBy(p => p))
                    {
                        var original = Path.GetFileName(path);
                        var ext = Path.GetExtension(path);
                        var newName = GetNewName(original, grp.TargetNumber, grp);
                        int itemIdx = listView.Items.Count;
                        var item = new ListViewItem("    " + original) { Tag = $"FILE:{gi}" };
                        if (_compactMode) item.Font = new Font("Consolas", 7.5f);

                        if (newName != null)
                        {
                            item.SubItems.Add(newName); item.SubItems.Add(ext); item.SubItems.Add("✔ Ready");
                            item.ForeColor = Theme.Success; item.BackColor = Theme.ListBg;
                            listView.DiffData[itemIdx] = (DiffHighlight.Diff(original, newName), DiffHighlight.Diff(newName, original));
                            totalReady++;
                        }
                        else if (grp.ConvertMode == FormatMode.None && string.IsNullOrEmpty(grp.TargetNumber))
                        { item.SubItems.Add("—"); item.SubItems.Add(ext); item.SubItems.Add("Waiting"); item.ForeColor = Theme.Muted; item.BackColor = Theme.ListBg; }
                        else
                        { item.SubItems.Add("—"); item.SubItems.Add(ext); item.SubItems.Add("No change"); item.ForeColor = Theme.Muted; item.BackColor = Theme.ListBg; totalNoMatch++; }
                        listView.Items.Add(item);
                    }
                }
                else
                {
                    totalReady += grpReady;
                    totalNoMatch += grp.Paths.Count(p => { var nn = GetNewName(Path.GetFileName(p), grp.TargetNumber, grp); return nn == null && !needsConf; });
                }
            }
            listView.EndUpdate();

            lblTotalFiles.Text = $"{totalFiles} file{(totalFiles != 1 ? "s" : "")}"; lblTotalFiles.ForeColor = totalFiles > 0 ? Theme.Text : Theme.Muted;
            lblTotalGroups.Text = $"{groups.Count} group{(groups.Count != 1 ? "s" : "")}"; lblTotalGroups.ForeColor = groups.Count > 0 ? Theme.Accent : Theme.Muted;
            lblReadyCount.Text = $"{totalReady} ready"; lblReadyCount.ForeColor = totalReady > 0 ? Theme.Success : Theme.Muted;
            lblNoMatchCount.Text = totalNoMatch > 0 ? $"{totalNoMatch} no change" : "";

            btnNextUnconfigured.Enabled = unconfigured > 0;
            btnNextUnconfigured.Text = unconfigured > 0 ? $"⏭ Next ⚠ ({unconfigured})" : "⏭ Next ⚠";
            btnNextUnconfigured.ForeColor = unconfigured > 0 ? Theme.Warning : Theme.Muted;
            btnRename.Enabled = totalReady > 0;
            btnExport.Enabled = totalFiles > 0;
            btnCollapseAll.Enabled = btnExpandAll.Enabled = btnGroupsOnly.Enabled = groups.Count > 0;

            if (totalFiles == 0) { lblStatus.Text = "Add files to get started."; lblStatus.ForeColor = Theme.Muted; }
            else { int configured = groups.Count(g => g.ConvertMode != FormatMode.None || !string.IsNullOrEmpty(g.TargetNumber)); lblStatus.Text = $"{groups.Count} group(s) — {configured} configured — {totalReady} file(s) ready."; lblStatus.ForeColor = totalReady > 0 ? Theme.Success : Theme.Muted; }
            if (!string.IsNullOrEmpty(filterText)) { lblNoMatchCount.Text = $"🔍 \"{filterText}\""; lblNoMatchCount.ForeColor = Theme.Warning; }

            listView.DoubleClick -= ListViewDoubleClick;
            listView.DoubleClick += ListViewDoubleClick;
            listView.MouseDown -= ListViewMouseDown;
            listView.MouseDown += ListViewMouseDown;
        }

        // Width, in pixels, of the "  ▼ " / "  ▶ " prefix the arrow is drawn
        // as part of — clicks within this zone toggle collapse instead of
        // selecting/configuring. A little generous on purpose so it's easy
        // to hit without needing pixel-perfect aim.
        private const int CollapseArrowZonePx = 28;
        private Point _lastMouseDownLocation;

        private bool IsClickOnCollapseArrow(Point location, out int groupIndex)
        {
            groupIndex = -1;
            var hit = listView.HitTest(location);
            if (hit.Item == null || !(hit.Item.Tag is string tag) || !tag.StartsWith("GROUP:")) return false;
            int relativeX = location.X - hit.Item.Bounds.Left;
            if (relativeX > CollapseArrowZonePx) return false;
            groupIndex = int.Parse(tag.Substring(6));
            return groupIndex < groups.Count;
        }

        private void ListViewMouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            _lastMouseDownLocation = e.Location;
            if (!IsClickOnCollapseArrow(e.Location, out int gi)) return;
            groups[gi].Collapsed = !groups[gi].Collapsed;
            RebuildList();
        }

        private void ListViewDoubleClick(object sender, EventArgs e)
        {
            // A double-click is two MouseDown events in quick succession, so
            // ListViewMouseDown above has already toggled collapse once by
            // the time this fires if the click landed on the arrow — don't
            // also open the config dialog in that case, or the two would
            // fight each other (collapse, then immediately pop a dialog).
            if (IsClickOnCollapseArrow(_lastMouseDownLocation, out _)) return;

            if (listView.SelectedItems.Count == 0) return;
            var tag = listView.SelectedItems[0].Tag as string ?? "";
            if (tag.StartsWith("GROUP:"))
            {
                int gi = int.Parse(tag.Substring(6)); if (gi >= groups.Count) return;
                // Always open the config dialog — previously this only
                // opened for groups that still "needed" config (no
                // ConvertMode/TargetNumber set yet); once a group had been
                // auto-detected or configured even once, double-click would
                // silently switch to just toggling collapse instead, which
                // contradicts the "[ double-click to configure ]" text the
                // UI itself shows. Collapse/expand is still available via
                // the Collapse All / Expand All toolbar buttons.
                OpenGroupConfig(gi);
                return;
            }
            if (tag.StartsWith("FILE:")) OpenGroupConfig(int.Parse(tag.Substring(5)));
        }

        private void OpenGroupConfig(int gi)
        {
            if (gi >= groups.Count) return;
            var grp = groups[gi]; var linked = GetLinkedGroups(grp);
            using var dlg = new GroupConfigDialog(grp, linked);
            if (dlg.ShowDialog(this.FindForm()) == DialogResult.OK)
            {
                if (dlg.SyncLinked && !string.IsNullOrEmpty(grp.TargetNumber)) foreach (var lg in linked) lg.TargetNumber = grp.TargetNumber;

                // "Auto-sync same number" toolbar checkbox — instantly applies
                // this group's new target number to every other group sharing
                // the same component slot AND the same original number, no
                // need to open each one's dialog individually.
                if (_autoSyncSameNumber && !string.IsNullOrEmpty(grp.TargetNumber))
                    foreach (var sg in GetGroupsWithSameNumber(grp)) sg.TargetNumber = grp.TargetNumber;

                foreach (var g in groups) g.DominantNumber = ComponentSlots.DominantNumber(g);
                if (_compactMode && IsGroupAllReady(grp)) grp.Collapsed = true;
                RebuildList();
            }
        }

        private static string ResolveCollision(string desiredPath)
        {
            if (!File.Exists(desiredPath)) return desiredPath;
            var dir = Path.GetDirectoryName(desiredPath); var name = Path.GetFileNameWithoutExtension(desiredPath); var ext = Path.GetExtension(desiredPath);
            for (int n = 1; n < 10000; n++) { var c = Path.Combine(dir, $"{name}_{n}{ext}"); if (!File.Exists(c)) return c; }
            return desiredPath;
        }

        private async void BtnRename_Click(object sender, EventArgs e)
        {
            var plan = groups.SelectMany(grp => grp.Paths.Select(p => new { Group = grp, OldPath = p, NewName = GetNewName(Path.GetFileName(p), grp.TargetNumber, grp) }))
                             .Where(x => x.NewName != null).ToList();
            if (plan.Count == 0) return;

            var collisions = plan
                .Select(x => new { x.OldPath, DesiredPath = Path.Combine(Path.GetDirectoryName(x.OldPath)!, x.NewName), AutoPath = ResolveCollision(Path.Combine(Path.GetDirectoryName(x.OldPath)!, x.NewName)) })
                .Where(x => File.Exists(x.DesiredPath) && !x.DesiredPath.Equals(x.OldPath, StringComparison.OrdinalIgnoreCase)).ToList();

            bool autoRenameAll = false;
            if (collisions.Count > 0)
            {
                var lines = collisions.Take(8).Select(c => $"  • {Path.GetFileName(c.DesiredPath)}  →  {Path.GetFileName(c.AutoPath)}").ToList();
                if (collisions.Count > 8) lines.Add($"  … and {collisions.Count - 8} more");
                var choice = MessageBox.Show($"{collisions.Count} file(s) would collide.\n\n{string.Join("\n", lines)}\n\n[Yes] Auto-rename with _1, _2…\n[No] Skip\n[Cancel] Abort", "Name Collisions", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (choice == DialogResult.Cancel) return;
                autoRenameAll = choice == DialogResult.Yes;
                if (!autoRenameAll) { var cs = new HashSet<string>(collisions.Select(c => c.OldPath), StringComparer.OrdinalIgnoreCase); plan = plan.Where(x => !cs.Contains(x.OldPath)).ToList(); }
            }

            progressBar.Maximum = plan.Count; progressBar.Value = 0; progressPanel.Visible = true;
            btnRename.Enabled = btnAddFiles.Enabled = btnAddFolder.Enabled = btnClear.Enabled = false;
            int success = 0, skipped = 0, failed = 0; var op = new RenameOperation();

            await Task.Run(() =>
            {
                foreach (var entry in plan)
                {
                    var dir = Path.GetDirectoryName(entry.OldPath); var desired = Path.Combine(dir, entry.NewName); string newPath = desired;
                    if (File.Exists(desired) && !desired.Equals(entry.OldPath, StringComparison.OrdinalIgnoreCase))
                    { if (autoRenameAll) newPath = ResolveCollision(desired); else { skipped++; continue; } }
                    try
                    {
                        File.Move(entry.OldPath, newPath); op.Renames.Add((entry.OldPath, newPath));
                        this.Invoke((Action)(() => { int idx = entry.Group.Paths.IndexOf(entry.OldPath); if (idx >= 0) entry.Group.Paths[idx] = newPath; success++; progressBar.Value = success + skipped + failed; lblProgress.Text = $"Renaming… {success + skipped + failed} / {plan.Count}"; }));
                    }
                    catch (Exception ex)
                    { this.Invoke((Action)(() => { MessageBox.Show($"Failed: {Path.GetFileName(entry.OldPath)}\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); failed++; progressBar.Value = success + skipped + failed; })); }
                }
            });

            if (op.Renames.Count > 0) { RenameHistory.Push(op); btnUndo.Enabled = true; btnUndo.Text = RenameHistory.UndoButtonText; }
            foreach (var g in groups) g.DominantNumber = ComponentSlots.DominantNumber(g);
            if (_compactMode) foreach (var g in groups) if (IsGroupAllReady(g)) g.Collapsed = true;
            RebuildList(); RefreshDropHint();
            lblProgress.Text = $"Done — {success} renamed, {skipped} skipped, {failed} failed.";
            lblStatus.Text = $"✔ {success} renamed  •  {skipped} skipped  •  {failed} failed"; lblStatus.ForeColor = failed > 0 ? Theme.Danger : Theme.Success;
            btnAddFiles.Enabled = btnAddFolder.Enabled = btnClear.Enabled = true;
            btnRename.Enabled = groups.Any(g => g.Paths.Any(p => GetNewName(Path.GetFileName(p), g.TargetNumber, g) != null));
            await Task.Delay(3000); progressPanel.Visible = false; RebuildList();
        }
    }

    // =========================================================================
    //  EupPanel  (unchanged from original)
    // =========================================================================

    internal class EupPanel : UserControl
    {
        private Button btnPickFolder, btnConvert, btnRescan, btnBuildDlc, btnMergeDlc;
        private TextBox txtSourceFolder, txtOutputFolder;
        private CheckBox chkOverwrite;
        private ListView listView;
        private Label lblStatus, lblSummary, lblDlcHint, lblBinaryWarn, lblProgress;
        private ProgressBar progressBar;
        private Panel progressPanel, dropHint, dlcStrip, binaryWarnPanel;
        private List<EupConvertEntry> entries = new List<EupConvertEntry>();
        private string sourceRoot = "", lastConvertedDir = "";
        private bool cancelOperation = false;

        public EupPanel()
        {
            this.BackColor = Theme.Background;
            this.AllowDrop = true;
            this.DragEnter += (s, e) => e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
            this.DragDrop += (s, e) => { var p = (string[])e.Data.GetData(DataFormats.FileDrop); if (p?.Length > 0 && Directory.Exists(p[0])) LoadSourceFolder(p[0]); };
            Theme.ThemeChanged += () => { this.BackColor = Theme.Background; if (listView != null) { listView.BackColor = Theme.ListBg; listView.ForeColor = Theme.Text; } RefreshUiList(); };
            Build();
        }

        private void Build()
        {
            const int PAD = 12;
            var top = new Panel { Dock = DockStyle.Top, Height = 108, BackColor = Theme.Surface };
            void AddLbl(string t, Point p) { var l = Theme.MakeLabel(t, muted: true); l.Location = p; top.Controls.Add(l); }
            AddLbl("FiveM Resource Root Folder (contains stream/ or fxmanifest.lua):", new Point(PAD, 10));
            txtSourceFolder = Theme.MakeTextBox("Drag and drop folder here…", 510); txtSourceFolder.Location = new Point(PAD, 28); txtSourceFolder.ReadOnly = true;
            btnPickFolder = Theme.MakeButton("Browse…", 88); btnPickFolder.Location = new Point(PAD + 514, 27);
            btnPickFolder.Click += (s, e) => { using var d = new FolderBrowserDialog { Description = "Select FiveM Resource Root" }; if (d.ShowDialog() == DialogResult.OK) LoadSourceFolder(d.SelectedPath); };
            AddLbl("SP Clean Output Folder:", new Point(PAD, 56));
            txtOutputFolder = Theme.MakeTextBox("", 510); txtOutputFolder.Location = new Point(PAD, 74);
            var btnPickOut = Theme.MakeButton("Browse…", 88); btnPickOut.Location = new Point(PAD + 514, 73);
            btnPickOut.Click += (s, e) => { using var d = new FolderBrowserDialog(); if (d.ShowDialog() == DialogResult.OK) txtOutputFolder.Text = d.SelectedPath; };
            btnRescan = Theme.MakeButton("🔄 Rescan", 86); btnRescan.Location = new Point(PAD + 610, 27); btnRescan.Visible = false;
            btnRescan.Click += (s, e) => { if (!string.IsNullOrEmpty(sourceRoot)) { entries = EupConverter.Scan(sourceRoot, txtOutputFolder.Text.Trim()); RefreshUiList(); } };
            chkOverwrite = new CheckBox { Text = "Overwrite existing files", AutoSize = true, Checked = true, ForeColor = Theme.TextDim, Font = new Font("Segoe UI", 8.5f), Location = new Point(PAD + 610, 74) };
            top.Controls.AddRange(new Control[] { txtSourceFolder, btnPickFolder, txtOutputFolder, btnPickOut, btnRescan, chkOverwrite });

            dlcStrip = new Panel { Dock = DockStyle.Top, Height = 38, BackColor = Color.FromArgb(22, 48, 32), Visible = false };
            btnBuildDlc = Theme.MakeButton("📦  Wrap into SP Addon DLC Pack", 230, 28, true); btnBuildDlc.Location = new Point(PAD, 5); btnBuildDlc.BackColor = Theme.Success;
            btnBuildDlc.Click += BtnBuildDlc_Click;
            btnMergeDlc = Theme.MakeButton("🔗  Merge into Existing Pack", 210, 28, true); btnMergeDlc.Location = new Point(PAD + 244, 5); btnMergeDlc.BackColor = Theme.Accent;
            btnMergeDlc.Click += BtnMergeDlc_Click;
            lblDlcHint = new Label { Text = "Conversion complete — package as a new DLC, or merge into one you already have.", Location = new Point(PAD + 466, 11), AutoSize = true, ForeColor = Color.FromArgb(160, 220, 180), Font = new Font("Segoe UI", 8.5f) };
            dlcStrip.Controls.AddRange(new Control[] { btnBuildDlc, btnMergeDlc, lblDlcHint });

            binaryWarnPanel = new Panel { Dock = DockStyle.Top, Height = 30, BackColor = Color.FromArgb(48, 28, 28), Visible = false };
            lblBinaryWarn = new Label { Text = "", Location = new Point(PAD, 7), AutoSize = true, ForeColor = Color.FromArgb(240, 150, 140), Font = new Font("Segoe UI", 8.5f) };
            binaryWarnPanel.Controls.Add(lblBinaryWarn);

            var summaryBar = new Panel { Dock = DockStyle.Top, Height = 28, BackColor = Color.FromArgb(14, 14, 18) };
            lblSummary = new Label { Text = "0 files found", Location = new Point(PAD, 7), AutoSize = true, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f) };
            summaryBar.Controls.Add(lblSummary);

            listView = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, GridLines = false, Font = new Font("Consolas", 8.5f), BackColor = Theme.ListBg, ForeColor = Theme.Text, BorderStyle = BorderStyle.None };
            listView.MouseUp += (s, e) =>
            {
                if (e.Button != MouseButtons.Right) return;
                var hit = listView.HitTest(e.Location);
                if (hit.Item == null) return;
                listView.SelectedItems.Clear();
                hit.Item.Selected = true;
                if (hit.Item.Tag is not EupConvertEntry entry) return;

                var menu = new ContextMenuStrip();
                menu.Items.Add("📂 Open Source File Location", null, (s2, e2) =>
                {
                    if (File.Exists(entry.SourcePath)) System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{entry.SourcePath}\"");
                });
                menu.Items.Add("📋 Copy Source Path", null, (s2, e2) => Clipboard.SetText(entry.SourcePath));
                menu.Items.Add("📋 Copy Output Name", null, (s2, e2) => Clipboard.SetText(entry.OutputName ?? ""));
                menu.Show(listView, e.Location);
            };
            listView.Columns.Add("Original FiveM Name / Relative Path", 450);
            listView.Columns.Add("→  SP Clean Name", 300);
            listView.Columns.Add("Action", 180);

            dropHint = new Panel { Dock = DockStyle.Fill, BackColor = Theme.ListBg };
            var lblDrop = new Label { Text = "Drag & Drop a FiveM EUP or Vehicle Resource Folder Here\n(the folder containing 'stream/' or 'fxmanifest.lua')", TextAlign = ContentAlignment.MiddleCenter, Dock = DockStyle.Fill, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 11f) };
            dropHint.Controls.Add(lblDrop);

            var center = new Panel { Dock = DockStyle.Fill };
            center.Controls.Add(listView); center.Controls.Add(dropHint);

            progressPanel = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = Theme.Surface, Visible = false };
            progressBar = new ProgressBar { Location = new Point(PAD, 5), Height = 18, Width = 560, Style = ProgressBarStyle.Continuous, BackColor = Theme.Background, ForeColor = Theme.Accent, Minimum = 0, Maximum = 100 };
            lblProgress = new Label { AutoSize = true, Location = new Point(582, 7), ForeColor = Theme.Text, Font = new Font("Segoe UI", 8.5f) };
            progressPanel.Controls.AddRange(new Control[] { progressBar, lblProgress });

            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 46, BackColor = Theme.Surface, Padding = new Padding(PAD, 8, PAD, 8) };
            btnConvert = Theme.MakeButton("Extract & Convert to SP", 172, 28, true); btnConvert.Location = new Point(PAD, 8); btnConvert.Enabled = false;
            btnConvert.Click += BtnConvert_Click;
            lblStatus = new Label { Text = "Select a FiveM resource pack directory.", Location = new Point(194, 14), AutoSize = true, ForeColor = Theme.Muted };
            var btnOpenOutput = Theme.MakeButton("📂 Open Output", 120); btnOpenOutput.Dock = DockStyle.Right;
            btnOpenOutput.Click += (s, e) =>
            {
                var target = !string.IsNullOrEmpty(lastConvertedDir) && Directory.Exists(lastConvertedDir) ? lastConvertedDir : txtOutputFolder.Text.Trim();
                if (Directory.Exists(target)) System.Diagnostics.Process.Start("explorer.exe", target);
                else MessageBox.Show("Output folder doesn't exist yet — run a conversion first.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            bottom.Controls.AddRange(new Control[] { btnConvert, lblStatus, btnOpenOutput });

            this.Controls.AddRange(new Control[] { center, progressPanel, bottom, summaryBar, binaryWarnPanel, dlcStrip, top });
        }

        private void LoadSourceFolder(string path)
        {
            sourceRoot = path; txtSourceFolder.Text = path;
            txtOutputFolder.Text = Path.Combine(path, "SP_Converted_Output");
            dlcStrip.Visible = false; binaryWarnPanel.Visible = false;
            entries = EupConverter.Scan(path, txtOutputFolder.Text.Trim()); btnRescan.Visible = true;
            RefreshUiList();
        }

        private void RefreshUiList()
        {
            listView.BeginUpdate(); listView.Items.Clear();
            int skip = 0, change = 0, plain = 0;
            foreach (var e in entries)
            {
                var relPath = e.SourcePath.Substring(sourceRoot.Length).TrimStart(Path.DirectorySeparatorChar);
                var item = new ListViewItem(relPath) { Tag = e };
                if (e.Skip) { item.SubItems.Add("—"); item.SubItems.Add($"❌ Skip ({e.SkipReason})"); item.ForeColor = Theme.Muted; skip++; }
                else
                {
                    item.SubItems.Add(e.OutputName);
                    item.SubItems.Add(e.IsBinary ? "Copy (Binary / RSC7)" : e.WillChange ? "XML Content Patch" : "Copy unaltered");
                    item.ForeColor = e.WillChange ? Theme.Success : Theme.TextDim;
                    if (e.WillChange) change++; else plain++;
                }
                listView.Items.Add(item);
            }
            listView.EndUpdate();
            dropHint.Visible = entries.Count == 0; listView.Visible = entries.Count > 0;
            btnConvert.Enabled = entries.Any(e => !e.Skip);
            lblSummary.Text = $"{entries.Count} files found  ·  {change} renamed  ·  {plain} copied unchanged  ·  {skip} skipped";
            lblStatus.Text = btnConvert.Enabled ? $"Ready to extract {entries.Count - skip} files." : "No convertible files found.";
            lblStatus.ForeColor = btnConvert.Enabled ? Theme.Success : Theme.Muted;
        }

        private async void BtnConvert_Click(object sender, EventArgs e)
        {
            if (btnConvert.Text == "Cancel") { cancelOperation = true; return; }
            string outDir = txtOutputFolder.Text.Trim();
            if (string.IsNullOrEmpty(outDir)) { MessageBox.Show("Choose a destination folder.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            cancelOperation = false;
            btnConvert.Text = "Cancel"; btnConvert.BackColor = Theme.Danger;
            progressBar.Value = 0; progressBar.Maximum = entries.Count;
            progressPanel.Visible = true; dlcStrip.Visible = false; binaryWarnPanel.Visible = false;
            bool overwrite = chkOverwrite.Checked; int copied = 0, skipped = 0, failed = 0; List<string> binaryWarnings = null;
            await Task.Run(() =>
            {
                var res = EupConverter.Execute(entries, outDir, overwrite,
                    (done, name) => this.Invoke((Action)(() => { progressBar.Value = done; lblProgress.Text = $"Processing: {name}"; })),
                    ref cancelOperation);
                copied = res.copied; skipped = res.skipped; failed = res.failed; binaryWarnings = res.binaryWarnings;
            });
            btnConvert.Text = "Extract & Convert to SP"; btnConvert.BackColor = Theme.Accent; progressPanel.Visible = false;
            if (cancelOperation) { lblStatus.Text = "Cancelled."; lblStatus.ForeColor = Theme.Warning; return; }
            lblStatus.Text = $"Done. {copied} copied, {skipped} skipped, {failed} failed."; lblStatus.ForeColor = failed > 0 ? Theme.Danger : Theme.Success;
            if (copied > 0 && failed == 0) { lastConvertedDir = outDir; dlcStrip.Visible = true; }
            if (binaryWarnings?.Count > 0) { binaryWarnPanel.Visible = true; lblBinaryWarn.Text = $"⚠ {binaryWarnings.Count} .ymt/.meta files are RSC7 encrypted — copied without inner patching."; }
        }

        private void BtnBuildDlc_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(lastConvertedDir) || !Directory.Exists(lastConvertedDir))
            {
                MessageBox.Show("Converted files folder not found.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // ── Resolve the stream/ subfolder if present ─────────────────────
            string scanDir = lastConvertedDir;
            string streamSub = Path.Combine(lastConvertedDir, "stream");
            if (Directory.Exists(streamSub)) scanDir = streamSub;

            var allFiles = Directory.GetFiles(scanDir, "*.*", SearchOption.AllDirectories);
            bool hasVehicles = allFiles.Any(f => f.EndsWith(".yft",
                                     StringComparison.OrdinalIgnoreCase));
            bool hasClothing = allFiles.Any(f => f.EndsWith(".ydd",
                                     StringComparison.OrdinalIgnoreCase));

            // ── Ask for GTA V directory once ──────────────────────────────────
            string gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;

            if (hasVehicles && !hasClothing)
            {
                // ── Vehicle DLC path ─────────────────────────────────────────
                var (vehicles, metaFiles) = VehicleDlcBuilder.Scan(scanDir);
                if (vehicles.Count == 0)
                {
                    MessageBox.Show("No vehicle .yft files found.", "Build Aborted",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!RunPreflightLightCheck(vehicles, scanDir)) return;

                using var dlg = new VehicleDlcDialog(
                    scanDir, vehicles[0].SpawnName, vehicles, metaFiles);
                if (dlg.ShowDialog(this.FindForm()) != DialogResult.OK) return;

                var writeDialog = new RpfWriteDialog();
                writeDialog.Show(this.FindForm());

                System.Threading.Tasks.Task.Run(() =>
                {
                    var result = RpfPackager.PackageVehicleDlcFromConvertedFiles(
                        gtaRoot: gtaRoot,
                        settings: dlg.Settings,
                        convertedFilesDir: scanDir,
                        progress: msg => writeDialog.AppendLog(msg));

                    writeDialog.Finish(result);

                    if (result.Success)
                        this.Invoke((Action)(() =>
                            ShowDlcSuccess(Path.GetDirectoryName(result.RpfPath), result.Log)));
                });
            }
            else
            {
                // ── Clothing DLC path — now produces a real dlc.rpf via
                //    ClothingDlcPackager. The .ymt remains a manual
                //    OpenFormats import unless the source already shipped a
                //    pre-compiled one — see ClothingDlcPackager's own
                //    comments for why. ───────────────────────────────────────
                var (detectedPed, drawables) = DlcBuilder.Scan(scanDir);
                if (drawables.Count == 0 &&
                    !allFiles.Any(f => Path.GetFileName(f).StartsWith("p_",
                                       StringComparison.OrdinalIgnoreCase)))
                {
                    MessageBox.Show("No .ydd or prop files detected.", "Scan Empty",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using var dlg = new DlcMetaDialog(
                    scanDir, detectedPed, "custom_eup_pack", drawables);
                if (dlg.ShowDialog(this.FindForm()) != DialogResult.OK) return;

                var writeDialog = new RpfWriteDialog();
                writeDialog.Show(this.FindForm());

                System.Threading.Tasks.Task.Run(() =>
                {
                    var result = ClothingDlcPackager.Package(
                        s: dlg.Settings,
                        convertedFilesDir: scanDir,
                        gtaRoot: gtaRoot,
                        progress: msg => writeDialog.AppendLog(msg));

                    writeDialog.Finish(result);

                    if (result.Success)
                        this.Invoke((Action)(() =>
                            ShowDlcSuccess(Path.GetDirectoryName(result.RpfPath), result.Log)));
                });
            }
        }

        // ── Merge the converted resource into an existing dlc.rpf (e.g. a
        //    combined LSPDFR pack, or a combined EUP/clothing pack) instead
        //    of creating a brand new dlcpacks/<name>/ folder for it. Always
        //    backs up the existing archive first — see DlcMerger for the
        //    actual merge logic for each content type. ───────────────────────
        private void BtnMergeDlc_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(lastConvertedDir) || !Directory.Exists(lastConvertedDir))
            {
                MessageBox.Show("Converted files folder not found.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string scanDir = lastConvertedDir;
            string streamSub = Path.Combine(lastConvertedDir, "stream");
            if (Directory.Exists(streamSub)) scanDir = streamSub;

            var allFiles = Directory.GetFiles(scanDir, "*.*", SearchOption.AllDirectories);
            bool hasVehicles = allFiles.Any(f => f.EndsWith(".yft", StringComparison.OrdinalIgnoreCase));
            bool hasClothing = allFiles.Any(f => f.EndsWith(".ydd", StringComparison.OrdinalIgnoreCase));

            if (!hasVehicles && !hasClothing)
            {
                MessageBox.Show("No vehicle (.yft) or clothing (.ydd) files were detected in the converted output.",
                    "Not Applicable", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;

            if (hasVehicles && !hasClothing)
            {
                var (vehicles, metaFiles) = VehicleDlcBuilder.Scan(scanDir);
                if (vehicles.Count == 0)
                {
                    MessageBox.Show("No vehicle .yft files found.", "Merge Aborted",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!RunPreflightLightCheck(vehicles, scanDir)) return;

                // Reuse the same confirm dialog as the standalone build — its
                // DLC name / output folder fields aren't meaningful for a merge
                // (we're writing into an existing pack you pick next), only the
                // siren preset / ELS / regenerate-carcols choices matter here.
                using var dlg = new VehicleDlcDialog(scanDir, vehicles[0].SpawnName, vehicles, metaFiles);
                if (dlg.ShowDialog(this.FindForm()) != DialogResult.OK) return;

                string existingDlcRpfPath = PickExistingDlcRpf(gtaRoot);
                if (existingDlcRpfPath == null) return;

                if (!ConfirmMerge($"{vehicles.Count} vehicle(s)", existingDlcRpfPath)) return;

                var writeDialog = new RpfWriteDialog();
                writeDialog.Show(this.FindForm());

                System.Threading.Tasks.Task.Run(() =>
                {
                    var result = DlcMerger.MergeVehicleIntoExistingDlc(
                        gtaRoot: gtaRoot,
                        existingDlcRpfPath: existingDlcRpfPath,
                        settings: dlg.Settings,
                        convertedFilesDir: scanDir,
                        progress: msg => writeDialog.AppendLog(msg));

                    writeDialog.Finish(result);
                });
            }
            else
            {
                // ── Clothing/EUP merge ──────────────────────────────────────
                var (detectedPed, drawables) = DlcBuilder.Scan(scanDir);
                if (drawables.Count == 0 &&
                    !allFiles.Any(f => Path.GetFileName(f).StartsWith("p_", StringComparison.OrdinalIgnoreCase)))
                {
                    MessageBox.Show("No .ydd or prop files detected.", "Scan Empty",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using var dlg = new DlcMetaDialog(scanDir, detectedPed, "custom_eup_pack", drawables);
                if (dlg.ShowDialog(this.FindForm()) != DialogResult.OK) return;

                // Defaults the picker to dlcpacks\eup\ — EUP/clothing packs
                // always live there (see ClothingDlcPackager), kept separate
                // from vehicle packs so the two can't get cross-merged.
                string existingDlcRpfPath = PickExistingDlcRpf(gtaRoot, subfolder: "eup");
                if (existingDlcRpfPath == null) return;

                if (existingDlcRpfPath.IndexOf("eup", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    MessageBox.Show(
                        "That file isn't inside a folder containing \"eup\" in its path.\n\n" +
                        "EUP/clothing packs must be kept in their own \"eup\" folder, separate from vehicle " +
                        "packs — pick (or create) one under dlcpacks\\eup\\ instead.",
                        "Wrong Location", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!ConfirmMerge($"{dlg.Settings.Drawables.Count} component/prop drawable(s)", existingDlcRpfPath,
                    extraNote: "\n\nNote: the existing pack's .ymt can't be read or auto-merged exactly " +
                               "(it's a compiled binary file) — a best-effort replacement .ymt.xml covering " +
                               "the merged set will be written next to dlc.rpf for you to import manually " +
                               "via OpenFormats afterward."))
                    return;

                var writeDialog = new RpfWriteDialog();
                writeDialog.Show(this.FindForm());

                System.Threading.Tasks.Task.Run(() =>
                {
                    var result = DlcMerger.MergeClothingIntoExistingDlc(
                        gtaRoot: gtaRoot,
                        existingDlcRpfPath: existingDlcRpfPath,
                        settings: dlg.Settings,
                        convertedFilesDir: scanDir,
                        progress: msg => writeDialog.AppendLog(msg));

                    writeDialog.Finish(result);
                });
            }
        }

        private string PickExistingDlcRpf(string gtaRoot, string subfolder = null)
        {
            string initialDir = subfolder != null
                ? Path.Combine(gtaRoot, "mods", "update", "x64", "dlcpacks", subfolder)
                : Path.Combine(gtaRoot, "mods", "update", "x64", "dlcpacks");
            // Fall back to the plain dlcpacks folder if the subfolder doesn't
            // exist yet (e.g. first-ever EUP merge, before any eup/ folder
            // has been created) — OpenFileDialog throws on a missing
            // InitialDirectory rather than just falling back itself.
            if (!Directory.Exists(initialDir))
                initialDir = Path.Combine(gtaRoot, "mods", "update", "x64", "dlcpacks");

            using var pickDlg = new OpenFileDialog
            {
                Title = subfolder != null
                    ? $"Select the existing dlc.rpf to merge into (should be under dlcpacks\\{subfolder}\\)"
                    : "Select the existing dlc.rpf to merge into",
                Filter = "dlc.rpf|dlc.rpf|RPF archives (*.rpf)|*.rpf",
                InitialDirectory = initialDir
            };
            return pickDlg.ShowDialog(this.FindForm()) == DialogResult.OK ? pickDlg.FileName : null;
        }

        private bool ConfirmMerge(string whatDescription, string existingDlcRpfPath, string extraNote = null)
        {
            var msg = $"This will merge {whatDescription} into:\n{existingDlcRpfPath}\n\n" +
                "The existing file will be backed up first (a timestamped .backup_ copy " +
                "next to it) before anything is changed." + extraNote + "\n\nContinue?";
            return MessageBox.Show(msg, "Confirm Merge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes;
        }

        /// <summary>
        /// Runs the same LightAttributes check as the RPF Explorer's
        /// "Check Lights" button, automatically, on every detected vehicle
        /// before a build/merge — so a vehicle with no siren/light data baked
        /// in (confirmed earlier this session as a real, silent failure mode
        /// no amount of carcols.meta/ELS config can fix) gets flagged before
        /// spending time on a full build, instead of discovered after.
        /// Returns false if the user chooses to abort after seeing the warning.
        /// </summary>
        private bool RunPreflightLightCheck(List<VehicleEntry> vehicles, string scanDir)
        {
            var zeroLightVehicles = new List<string>();

            foreach (var v in vehicles)
            {
                string yftPath = Path.Combine(scanDir, v.SpawnName + ".yft");
                if (!File.Exists(yftPath)) continue;

                var check = RpfReader.CheckYftLightsFromFile(yftPath);
                if (check.Success && check.LightAttributeEntries == 0)
                    zeroLightVehicles.Add(v.SpawnName);
            }

            if (zeroLightVehicles.Count == 0) return true;

            var sb = new StringBuilder();
            sb.AppendLine("⚠ The following vehicle(s) have NO siren/light data baked into their model");
            sb.AppendLine("(LightAttributes count = 0). Native siren lights and ELS will not work for");
            sb.AppendLine("them regardless of what metadata gets generated:");
            sb.AppendLine();
            foreach (var name in zeroLightVehicles) sb.AppendLine($"  • {name}");
            sb.AppendLine();
            sb.AppendLine("You can still build/merge — this only affects whether lights/sirens work,");
            sb.AppendLine("nothing else about the vehicle. Continue anyway?");

            return MessageBox.Show(sb.ToString(), "Light Check Warning",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes;
        }

        private void ShowDlcSuccess(string path, List<string> logs)
        {
            var sb = new StringBuilder();
            sb.AppendLine("✨ SP Addon DLC Pack generated successfully!");
            sb.AppendLine(); sb.AppendLine($"Output: {path}");
            sb.AppendLine(); sb.AppendLine("See HOW_TO_INSTALL.txt for OpenIV import steps.");
            sb.AppendLine(); sb.AppendLine("— Log —");
            foreach (var l in logs.Take(15)) sb.AppendLine($" • {l}");
            if (logs.Count > 15) sb.AppendLine($" … and {logs.Count - 15} more.");
            MessageBox.Show(sb.ToString(), "DLC Built", MessageBoxButtons.OK, MessageBoxIcon.Information);
            try { System.Diagnostics.Process.Start("explorer.exe", $"\"{path}\""); } catch { }
        }
    }

    // =========================================================================
    //  VehicleAddonPanel  —  one-stop vehicle DLC builder.
    //
    //  Accepts any of: a raw FiveM resource, an already-converted FiveM
    //  output folder, or a standard SP addon vehicle pack (plain .yft/.ytd/
    //  meta files, no FiveM involved at all) — all three get routed through
    //  the same EupConverter.Scan/Execute pass first, which gracefully
    //  no-ops on files that don't need any patching, so there's no need to
    //  separately detect which kind of input it is.
    //
    //  Two build paths:
    //   - Instant Build: zero dialog, uses sensible defaults (PoliceLSPD
    //     preset, 2 lights, carcols regenerated) plus whatever this panel's
    //     own ELS checkbox is set to.
    //   - Configure & Build: same VehicleDlcDialog flow as the FiveM EUP→SP
    //     tab, for full control over name/output/siren details.
    //  Both also support merging into an existing pack, reusing DlcMerger.
    // =========================================================================

    internal class VehicleAddonPanel : UserControl
    {
        private const int PAD = 14;

        private TextBox txtSourceFolder;
        private Button btnBrowse, btnBrowseRpf, btnInstantBuild, btnConfigureBuild, btnMergeIntoExisting, btnGenerateFromTemplate, btnShowLoadLog;
        private string lastLoadLog = "";
        private Label lblStatus, lblDetected;
        private CheckBox chkEls;
        private ComboBox cboSiren;
        private ComboBox cboMultiVehicleMode;
        private Label lblMultiVehicleMode;
        private NumericUpDown numSirenCount;
        private Panel dropPanel;

        private string sourceFolder;
        private string convertedDir;
        private string loadedFromDlcRpfPath; // null unless loaded via "Load dlc.rpf"
        private List<VehicleEntry> detectedVehicles = new List<VehicleEntry>();
        private List<string> detectedMetaFiles = new List<string>();

        public VehicleAddonPanel()
        {
            this.BackColor = Theme.Background;
            this.AllowDrop = true;
            this.DragEnter += Panel_DragEnter;
            this.DragDrop += Panel_DragDrop;

            int y = PAD;
            var lblTitle = Theme.MakeLabel("🚗  Vehicle Addon — drop a vehicle folder to build a dlc.rpf", true);
            lblTitle.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
            lblTitle.Location = new Point(PAD, y); this.Controls.Add(lblTitle); y += 28;

            var lblHint = new Label
            {
                Text = "Works with a raw FiveM resource, an already-converted folder, or a plain SP addon vehicle pack — any of the three.",
                AutoSize = true,
                ForeColor = Theme.Muted,
                Font = new Font("Segoe UI", 8.5f),
                Location = new Point(PAD, y)
            };
            this.Controls.Add(lblHint); y += 26;

            txtSourceFolder = Theme.MakeTextBox("", 460); txtSourceFolder.Location = new Point(PAD, y); txtSourceFolder.ReadOnly = true;
            this.Controls.Add(txtSourceFolder);
            btnBrowse = Theme.MakeButton("📂 Browse Folder…", 140, 26, true); btnBrowse.Location = new Point(PAD + 468, y - 1);
            btnBrowse.Click += (s, e) =>
            {
                using var d = new FolderBrowserDialog { Description = "Select a vehicle folder (FiveM resource, converted output, or standard addon pack)" };
                if (d.ShowDialog() == DialogResult.OK) LoadFolder(d.SelectedPath);
            };
            this.Controls.Add(btnBrowse);
            btnBrowseRpf = Theme.MakeButton("📦 Load dlc.rpf…", 140, 26); btnBrowseRpf.Location = new Point(PAD + 614, y - 1);
            btnBrowseRpf.Click += (s, e) =>
            {
                using var d = new OpenFileDialog { Title = "Select a dlc.rpf to read vehicles from", Filter = "dlc.rpf|dlc.rpf|RPF archives (*.rpf)|*.rpf" };
                if (d.ShowDialog() == DialogResult.OK) LoadDlcRpf(d.FileName);
            };
            this.Controls.Add(btnBrowseRpf);
            btnShowLoadLog = Theme.MakeButton("📋 Show Load Log", 150, 26); btnShowLoadLog.Location = new Point(PAD + 760, y - 1); btnShowLoadLog.Enabled = false;
            btnShowLoadLog.Click += (s, e) =>
            {
                var writeDialog = new RpfWriteDialog();
                writeDialog.Show(this.FindForm());
                foreach (var line in (lastLoadLog ?? "(no log yet)").Split('\n'))
                    writeDialog.AppendLog(line.TrimEnd('\r'));
                writeDialog.Finish(new RpfBuilder.BuildResult { Success = true, RpfPath = sourceFolder ?? "", DlcEntry = "" });
            };
            this.Controls.Add(btnShowLoadLog); y += 34;

            dropPanel = new Panel { Location = new Point(PAD, y), Size = new Size(700, 60), BackColor = Theme.Surface2, BorderStyle = BorderStyle.FixedSingle, AllowDrop = true };
            dropPanel.DragEnter += Panel_DragEnter;
            dropPanel.DragDrop += Panel_DragDrop;
            var dropLbl = new Label { Text = "⬇  …or drag and drop a folder OR a dlc.rpf file anywhere on this tab", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, ForeColor = Theme.Muted };
            dropPanel.Controls.Add(dropLbl);
            this.Controls.Add(dropPanel); y += 72;

            lblDetected = new Label { AutoSize = true, ForeColor = Theme.Muted, Location = new Point(PAD, y), Text = "No folder loaded yet.", MaximumSize = new Size(820, 0) };
            this.Controls.Add(lblDetected); y += 30;

            // ── Siren / ELS options — visible directly on the panel so
            //    Instant Build has something sensible to use without a
            //    dialog, and Configure & Build pre-fills from these too. ──
            chkEls = new CheckBox
            {
                Text = "This vehicle uses ELS (Emergency Lighting System)",
                AutoSize = true,
                ForeColor = Theme.Text,
                Location = new Point(PAD, y)
            };
            this.Controls.Add(chkEls); y += 28;

            var lblSiren = Theme.MakeLabel("Siren / light preset:", true); lblSiren.Location = new Point(PAD, y + 3); this.Controls.Add(lblSiren);
            cboSiren = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Location = new Point(PAD + 150, y), Width = 180 };
            cboSiren.Items.AddRange(Enum.GetNames(typeof(SirenPreset)));
            cboSiren.SelectedIndex = (int)SirenPreset.PoliceLSPD;
            this.Controls.Add(cboSiren);
            var lblCount = Theme.MakeLabel("Lights:", true); lblCount.Location = new Point(PAD + 340, y + 3); this.Controls.Add(lblCount);
            numSirenCount = new NumericUpDown { Location = new Point(PAD + 392, y - 1), Width = 50, Minimum = 1, Maximum = 8, Value = 2 };
            this.Controls.Add(numSirenCount); y += 36;

            lblMultiVehicleMode = Theme.MakeLabel("Multiple vehicles found — build as:", true);
            lblMultiVehicleMode.Location = new Point(PAD, y + 3); lblMultiVehicleMode.Visible = false;
            this.Controls.Add(lblMultiVehicleMode);
            cboMultiVehicleMode = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Location = new Point(PAD + 220, y), Width = 260, Visible = false };
            cboMultiVehicleMode.Items.AddRange(new object[] {
                "One combined pack (all vehicles together)",
                "Separate packs (one dlc.rpf per vehicle)"
            });
            cboMultiVehicleMode.SelectedIndex = 0;
            this.Controls.Add(cboMultiVehicleMode); y += 36;

            btnGenerateFromTemplate = Theme.MakeButton("🧬 Generate Meta From Template…", 250, 30);
            btnGenerateFromTemplate.Location = new Point(PAD, y);
            btnGenerateFromTemplate.Click += BtnGenerateFromTemplate_Click;
            this.Controls.Add(btnGenerateFromTemplate);
            var lblTemplateHint = new Label
            {
                Text = "Have known-good .meta files for a similar vehicle? Generate matching ones for this vehicle's name first.",
                AutoSize = true,
                ForeColor = Theme.Muted,
                Font = new Font("Segoe UI", 8.5f),
                Location = new Point(PAD + 260, y + 7)
            };
            this.Controls.Add(lblTemplateHint);
            y += 40;

            btnInstantBuild = Theme.MakeButton("⚡ Instant Build", 160, 32, true); btnInstantBuild.Location = new Point(PAD, y); btnInstantBuild.Enabled = false;
            btnInstantBuild.Click += BtnInstantBuild_Click;
            this.Controls.Add(btnInstantBuild);

            btnConfigureBuild = Theme.MakeButton("⚙ Configure & Build…", 190, 32); btnConfigureBuild.Location = new Point(PAD + 170, y); btnConfigureBuild.Enabled = false;
            btnConfigureBuild.Click += BtnConfigureBuild_Click;
            this.Controls.Add(btnConfigureBuild);

            btnMergeIntoExisting = Theme.MakeButton("🔗 Merge into Existing Pack…", 220, 32); btnMergeIntoExisting.Location = new Point(PAD + 370, y); btnMergeIntoExisting.Enabled = false;
            btnMergeIntoExisting.Click += BtnMergeIntoExisting_Click;
            this.Controls.Add(btnMergeIntoExisting);
            y += 42;

            lblStatus = new Label { AutoSize = true, ForeColor = Theme.Muted, Location = new Point(PAD, y), MaximumSize = new Size(760, 0) };
            this.Controls.Add(lblStatus);
        }

        private void Panel_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
        }

        private void Panel_DragDrop(object sender, DragEventArgs e)
        {
            var paths = (string[])e.Data.GetData(DataFormats.FileDrop);
            var rpfFile = paths.FirstOrDefault(p => File.Exists(p) && p.EndsWith(".rpf", StringComparison.OrdinalIgnoreCase));
            if (rpfFile != null) { LoadDlcRpf(rpfFile); return; }

            var folder = paths.FirstOrDefault(p => Directory.Exists(p)) ?? Path.GetDirectoryName(paths.FirstOrDefault() ?? "");
            if (!string.IsNullOrEmpty(folder)) LoadFolder(folder);
        }

        /// <summary>
        /// Runs ANY input folder through the same EupConverter pass used by
        /// the FiveM EUP→SP tab — harmless no-op for files that need no
        /// patching (already-converted or standard addon files just get
        /// copied through unchanged), so this works uniformly for all three
        /// accepted input types without needing to tell them apart first.
        /// </summary>
        private void LoadFolder(string path)
        {
            sourceFolder = path;
            loadedFromDlcRpfPath = null; // loose files — always safe to copy directly
            txtSourceFolder.Text = path;
            lblStatus.Text = "";
            btnInstantBuild.Enabled = btnConfigureBuild.Enabled = btnMergeIntoExisting.Enabled = false;
            lblDetected.Text = "Scanning…"; lblDetected.ForeColor = Theme.Muted;

            var log = new StringBuilder();
            try
            {
                string outDir = Path.Combine(path, "SP_Converted_Output");
                var entries = EupConverter.Scan(path, outDir);
                log.AppendLine($"Scan found {entries.Count} file(s) in source.");
                bool cancel = false;
                // EupConverter.Execute calls progress(...) unconditionally
                // with no null-check internally — passing null here throws
                // a NullReferenceException the moment it processes the first
                // entry, so a no-op lambda is required, not null.
                var res = EupConverter.Execute(entries, outDir, overwrite: true,
                    progress: (done, name) => log.AppendLine($"  [{done}/{entries.Count}] {name}"),
                    cancel: ref cancel);
                log.AppendLine($"Copy step: {res.copied} copied, {res.skipped} skipped, {res.failed} failed.");
                if (res.binaryWarnings.Count > 0)
                    log.AppendLine($"Binary warnings (compiled files copied as-is, not patched): {string.Join(", ", res.binaryWarnings)}");

                string scanDir = Directory.Exists(Path.Combine(outDir, "stream")) ? Path.Combine(outDir, "stream") : outDir;
                var yftList = Directory.Exists(scanDir) ? Directory.GetFiles(scanDir, "*.yft", SearchOption.AllDirectories) : new string[0];
                var ytdList = Directory.Exists(scanDir) ? Directory.GetFiles(scanDir, "*.ytd", SearchOption.AllDirectories) : new string[0];
                log.AppendLine($"Output contains {yftList.Length} .yft file(s) and {ytdList.Length} .ytd file(s):");
                foreach (var f in yftList) log.AppendLine($"  .yft: {Path.GetFileName(f)} ({new FileInfo(f).Length / 1024} KB)");
                foreach (var f in ytdList) log.AppendLine($"  .ytd: {Path.GetFileName(f)} ({new FileInfo(f).Length / 1024} KB)");

                lastLoadLog = log.ToString();

                if (yftList.Length == 0)
                {
                    // The conversion step itself is the thing to look at here,
                    // not vehicle detection — show exactly what happened
                    // instead of a generic "not found" that hides whether
                    // files were even attempted, skipped, or silently failed.
                    lblDetected.Text =
                        $"No .yft ended up in the converted output. Scan found {entries.Count} file(s) total " +
                        $"({entries.Count(x => x.Skip)} skipped as FiveM-only markers). Copy step: " +
                        $"{res.copied} copied, {res.skipped} skipped, {res.failed} failed silently. " +
                        "Click 📋 Show Load Log for full detail.";
                    lblDetected.ForeColor = Theme.Danger;
                    btnShowLoadLog.Enabled = true;
                    return;
                }

                btnShowLoadLog.Enabled = true;
                DetectVehiclesIn(scanDir);
            }
            catch (Exception ex)
            {
                log.AppendLine($"ERROR: {ex.Message}");
                lastLoadLog = log.ToString();
                btnShowLoadLog.Enabled = true;
                lblDetected.Text = $"Could not scan this folder: {ex.Message}";
                lblDetected.ForeColor = Theme.Danger;
            }
        }

        /// <summary>
        /// Reads an already-built dlc.rpf directly — for standard addon
        /// vehicle packs distributed as a finished archive rather than loose
        /// files. Extracts data/*.meta and the model files from
        /// x64/vehicles.rpf into a flat temp folder (matching the layout
        /// VehicleDlcBuilder.Scan already expects from a converted folder),
        /// then runs the same detection path as a loose-folder load.
        /// </summary>
        private void LoadDlcRpf(string rpfPath)
        {
            sourceFolder = rpfPath;
            loadedFromDlcRpfPath = rpfPath; // extraction path — binary copy unreliable, see SourceDlcRpfPath
            txtSourceFolder.Text = rpfPath;
            lblStatus.Text = "";
            btnInstantBuild.Enabled = btnConfigureBuild.Enabled = btnMergeIntoExisting.Enabled = false;
            lblDetected.Text = "Reading dlc.rpf…"; lblDetected.ForeColor = Theme.Muted;

            try
            {
                string tempDir = Path.Combine(Path.GetTempPath(), $"vehicleaddon_{Guid.NewGuid():N}");
                Directory.CreateDirectory(tempDir);

                var rpf = RpfReader.Load(rpfPath);
                var root = RpfReader.BuildTree(rpf);

                var diag = new StringBuilder();
                diag.AppendLine($"Root contains {root.Children.Count} item(s): " +
                    string.Join(", ", root.Children.Select(c => $"{c.Name}{(c.IsDirectory ? "/" : c.IsArchive ? " [archive]" : "")}")));

                // Fully recursive — walks every directory AND every nested
                // archive (vehicles.rpf or otherwise), wherever they actually
                // are, rather than assuming the specific data/ + x64/vehicles.rpf
                // layout our own tool happens to use. Third-party packs aren't
                // guaranteed to follow that exact convention, and a previous,
                // narrower version of this method silently missed anything
                // that didn't.
                int totalFilesWritten = 0;
                ExtractAllFilesRecursive(root, tempDir, diag, ref totalFilesWritten);
                diag.AppendLine($"{totalFilesWritten} file(s) extracted in total.");

                var extractedYft = Directory.GetFiles(tempDir, "*.yft");
                var extractedYtd = Directory.GetFiles(tempDir, "*.ytd");
                diag.AppendLine($"Of those: {extractedYft.Length} .yft, {extractedYtd.Length} .ytd.");
                foreach (var f in extractedYft) diag.AppendLine($"  .yft: {Path.GetFileName(f)} ({new FileInfo(f).Length / 1024} KB)");
                foreach (var f in extractedYtd) diag.AppendLine($"  .ytd: {Path.GetFileName(f)} ({new FileInfo(f).Length / 1024} KB)");

                lastLoadLog = diag.ToString();
                btnShowLoadLog.Enabled = true;

                if (totalFilesWritten == 0)
                {
                    lblDetected.Text = diag.ToString();
                    lblDetected.ForeColor = Theme.Danger;
                    return;
                }

                DetectVehiclesIn(tempDir);
            }
            catch (Exception ex)
            {
                lastLoadLog = (lastLoadLog ?? "") + $"\nERROR: {ex.Message}\n{ex.StackTrace}";
                btnShowLoadLog.Enabled = true;
                lblDetected.Text = $"Could not read this dlc.rpf: {ex.Message}";
                lblDetected.ForeColor = Theme.Danger;
            }
        }

        /// <summary>
        /// Recursively extracts every file from an RPF tree — including
        /// inside nested archives like vehicles.rpf, wherever they're
        /// located — into a single flat output folder, matching the layout
        /// VehicleDlcBuilder.Scan already expects. Logs a warning rather
        /// than silently overwriting if two files anywhere in the archive
        /// happen to share the same name.
        /// </summary>
        private void ExtractAllFilesRecursive(RpfReader.RpfNode node, string outputDir, StringBuilder diag, ref int filesWritten)
        {
            foreach (var child in node.Children)
            {
                if (child.IsDirectory)
                {
                    ExtractAllFilesRecursive(child, outputDir, diag, ref filesWritten);
                }
                else if (child.IsArchive)
                {
                    try
                    {
                        var nested = RpfReader.LoadNested(child);
                        var nestedRoot = RpfReader.BuildTree(nested);
                        diag.AppendLine($"Nested archive {child.Name} — {nestedRoot.Children.Count} item(s), extracting…");
                        ExtractAllFilesRecursive(nestedRoot, outputDir, diag, ref filesWritten);
                    }
                    catch (Exception ex)
                    {
                        diag.AppendLine($"Could not open nested archive {child.Name}: {ex.Message}");
                    }
                }
                else
                {
                    try
                    {
                        string dest = Path.Combine(outputDir, child.Name);
                        if (File.Exists(dest))
                            diag.AppendLine($"WARNING: {child.Name} appears more than once in this archive — later copy overwrote the earlier one.");
                        File.WriteAllBytes(dest, RpfReader.ExtractBytesResourceAware(child));
                        filesWritten++;
                    }
                    catch (Exception ex)
                    {
                        diag.AppendLine($"Could not extract {child.Name}: {ex.Message}");
                    }
                }
            }
        }

        private bool hasCriticalMetaFiles;

        private void DetectVehiclesIn(string scanDir)
        {
            var (vehicles, metaFiles) = VehicleDlcBuilder.Scan(scanDir);
            detectedVehicles = vehicles; detectedMetaFiles = metaFiles;
            convertedDir = scanDir;

            if (vehicles.Count == 0)
            {
                lblDetected.Text = "No vehicle .yft files detected.";
                lblDetected.ForeColor = Theme.Warning;
                return;
            }

            // handling.meta/vehicles.meta/carvariations.meta missing from a
            // REAL vehicle's source is a real danger sign, not just a minor
            // gap — the auto-generate fallback only has basic info (mass,
            // top speed, category) to work with, nothing about wheel
            // positions, collision bounds, or physics, which is exactly the
            // kind of incomplete data that crashes the game once it tries to
            // stream the vehicle in. Very common cause: a combined pack
            // where these files are shared in a parent "data" folder, not
            // inside the individual vehicle's own subfolder that got scanned.
            string[] criticalFiles = { "handling.meta", "vehicles.meta", "carvariations.meta" };
            var missingCritical = criticalFiles.Where(f => !File.Exists(Path.Combine(scanDir, f))).ToList();
            hasCriticalMetaFiles = missingCritical.Count == 0;

            if (!hasCriticalMetaFiles)
            {
                lblDetected.Text =
                    $"⚠ {vehicles.Count} vehicle(s) detected, BUT missing: {string.Join(", ", missingCritical)}.\n" +
                    "These would get auto-generated from minimal data (no real wheel/collision/physics info) — " +
                    "this is a common cause of crashes once the game tries to stream the vehicle in. This often " +
                    "means the real meta files live in a shared parent \"data\" folder, not this specific vehicle's " +
                    "subfolder — check for one and select that instead, or use Merge into Existing Pack if this " +
                    "vehicle belongs to a combined pack you already have set up.";
                lblDetected.ForeColor = Theme.Danger;
                btnInstantBuild.Enabled = false; // too risky for the zero-review path
                btnConfigureBuild.Enabled = btnMergeIntoExisting.Enabled = true; // still allowed, but will warn again
                return;
            }

            lblDetected.Text = $"✔ {vehicles.Count} vehicle(s) detected: {string.Join(", ", vehicles.Select(v => v.SpawnName))}";
            lblDetected.ForeColor = Theme.Success;
            btnInstantBuild.Enabled = btnConfigureBuild.Enabled = btnMergeIntoExisting.Enabled = true;
            lblMultiVehicleMode.Visible = cboMultiVehicleMode.Visible = vehicles.Count > 1;
        }

        private VehicleDlcBuildSettings BuildSettingsFromPanel(string dlcName, string outputRoot)
        {
            return new VehicleDlcBuildSettings
            {
                DlcName = dlcName,
                OutputRoot = outputRoot,
                Vehicles = detectedVehicles,
                MetaFiles = detectedMetaFiles,
                IsElsVehicle = chkEls.Checked,
                RegenerateCarcols = true,
                LightAudioConfig = new VehicleLightAudioConfig
                {
                    SirenPreset = (SirenPreset)cboSiren.SelectedIndex,
                    SirenCount = (int)numSirenCount.Value
                },
                SourceDlcRpfPath = loadedFromDlcRpfPath
            };
        }

        private bool RunPreflightLightCheck()
        {
            var zeroLightVehicles = new List<string>();
            foreach (var v in detectedVehicles)
            {
                string yftPath = Path.Combine(convertedDir, v.SpawnName + ".yft");
                if (!File.Exists(yftPath)) continue;
                var check = RpfReader.CheckYftLightsFromFile(yftPath);
                if (check.Success && check.LightAttributeEntries == 0) zeroLightVehicles.Add(v.SpawnName);
            }
            if (zeroLightVehicles.Count == 0) return true;

            var sb = new StringBuilder();
            sb.AppendLine("⚠ The following vehicle(s) have NO siren/light data baked into their model:");
            sb.AppendLine();
            foreach (var name in zeroLightVehicles) sb.AppendLine($"  • {name}");
            sb.AppendLine();
            sb.AppendLine("Native siren lights and ELS will not work for them regardless of metadata. Continue anyway?");
            return MessageBox.Show(sb.ToString(), "Light Check Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes;
        }

        private void BtnInstantBuild_Click(object sender, EventArgs e)
        {
            if (!RunPreflightLightCheck()) return;
            string gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;

            bool buildSeparate = detectedVehicles.Count > 1 && cboMultiVehicleMode.Visible && cboMultiVehicleMode.SelectedIndex == 1;

            if (buildSeparate)
            {
                BuildSeparatePacks(gtaRoot);
                return;
            }

            string dlcName = (detectedVehicles.Count == 1 ? detectedVehicles[0].SpawnName : Path.GetFileName(sourceFolder.TrimEnd(Path.DirectorySeparatorChar)))
                .ToLowerInvariant().Replace(" ", "_");
            if (!ConfirmNoCollision(gtaRoot, dlcName)) return;

            var settings = BuildSettingsFromPanel(dlcName, gtaRoot);

            var writeDialog = new RpfWriteDialog();
            writeDialog.Show(this.FindForm());
            System.Threading.Tasks.Task.Run(() =>
            {
                var result = RpfPackager.PackageVehicleDlcFromConvertedFiles(
                    gtaRoot: gtaRoot, settings: settings, convertedFilesDir: convertedDir,
                    progress: msg => writeDialog.AppendLog(msg));
                writeDialog.Finish(result);
            });
        }

        /// <summary>
        /// Batch mode — builds one independent dlc.rpf per detected vehicle,
        /// each named after that vehicle's own spawn name, instead of one
        /// combined pack. Collision-checks and confirms each one up front
        /// (before any building starts) so a problem with vehicle #4 doesn't
        /// surface after #1-3 already built; then builds them sequentially,
        /// all logged into a single shared write dialog.
        /// </summary>
        private void BuildSeparatePacks(string gtaRoot)
        {
            var toBuild = new List<(VehicleEntry vehicle, string dlcName)>();
            foreach (var v in detectedVehicles)
            {
                string dlcName = v.SpawnName.ToLowerInvariant().Replace(" ", "_");
                if (!ConfirmNoCollision(gtaRoot, dlcName)) return; // bail before building anything
                toBuild.Add((v, dlcName));
            }

            var writeDialog = new RpfWriteDialog();
            writeDialog.Show(this.FindForm());
            System.Threading.Tasks.Task.Run(() =>
            {
                int succeeded = 0, failed = 0;
                foreach (var (v, dlcName) in toBuild)
                {
                    writeDialog.AppendLog($"=== Building {dlcName} ({v.SpawnName}) ===");
                    var settings = BuildSettingsFromPanel(dlcName, gtaRoot);
                    settings.Vehicles = new List<VehicleEntry> { v }; // this pack gets only this one vehicle
                    var result = RpfPackager.PackageVehicleDlcFromConvertedFiles(
                        gtaRoot: gtaRoot, settings: settings, convertedFilesDir: convertedDir,
                        progress: msg => writeDialog.AppendLog("  " + msg));
                    if (result.Success) succeeded++; else failed++;
                    writeDialog.AppendLog(result.Success ? $"  ✔ {dlcName} done." : $"  ✕ {dlcName} FAILED: {result.Error}");
                    writeDialog.AppendLog("");
                }

                var summary = new RpfBuilder.BuildResult
                {
                    Success = failed == 0,
                    RpfPath = $"{succeeded} pack(s) built, {failed} failed",
                    DlcEntry = string.Join(", ", toBuild.Select(t => $"dlcpacks:/{t.dlcName}/")),
                    Error = failed > 0 ? $"{failed} pack(s) failed — see log above for details." : null
                };
                writeDialog.Finish(summary);
            });
        }

        /// <summary>
        /// Pre-flight check, shown before any build proceeds — warns clearly
        /// if the chosen DLC name already exists as a folder and/or is
        /// already registered in dlclist.xml, rather than silently
        /// overwriting whatever's already there. This is exactly the gap
        /// that caused the "police3" incident earlier this session — that
        /// one turned out to be empty, but there was no warning either way.
        /// Read-only check (RpfBuilder.CheckDlcNameCollision never writes
        /// anything); returns true if the build should proceed.
        /// </summary>
        private bool ConfirmNoCollision(string gtaRoot, string dlcName)
        {
            var collision = RpfBuilder.CheckDlcNameCollision(gtaRoot, dlcName);
            if (!collision.HasAnyCollision) return true;

            var msg = new StringBuilder();
            msg.AppendLine($"\"{dlcName}\" already exists:");
            msg.AppendLine();
            if (collision.FolderExists) msg.AppendLine($"  • A folder already exists at:\n    {collision.FolderPath}");
            if (collision.RegisteredInDlcList) msg.AppendLine($"  • \"{dlcName}\" is already registered in dlclist.xml");
            msg.AppendLine();
            msg.AppendLine("Building now will back up and overwrite the existing dlc.rpf (a backup is " +
                "always made automatically), but if that existing pack is something you actually use, " +
                "consider renaming this build first instead.");
            msg.AppendLine();
            msg.AppendLine("Continue anyway?");

            return MessageBox.Show(msg.ToString(), "DLC Name Already In Use", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes;
        }

        private void BtnConfigureBuild_Click(object sender, EventArgs e)
        {
            if (!RunPreflightLightCheck()) return;

            if (!hasCriticalMetaFiles)
            {
                var confirm = MessageBox.Show(
                    "handling.meta, vehicles.meta, and/or carvariations.meta were not found for this vehicle and " +
                    "would be auto-generated from minimal data — no real wheel positions, collision bounds, or " +
                    "physics info. This is a known cause of crashes once the game streams the vehicle in.\n\n" +
                    "This usually means the real meta files live in a shared parent folder, separate from this " +
                    "vehicle's own subfolder. Check for one before proceeding if possible.\n\n" +
                    "Build anyway with auto-generated (incomplete) meta?",
                    "Missing Critical Meta — Crash Risk", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirm != DialogResult.Yes) return;
            }

            string gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;

            using var dlg = new VehicleDlcDialog(convertedDir, detectedVehicles[0].SpawnName, detectedVehicles, detectedMetaFiles);
            if (dlg.ShowDialog(this.FindForm()) != DialogResult.OK) return;

            var settings = dlg.Settings;
            settings.SourceDlcRpfPath = loadedFromDlcRpfPath;
            if (!ConfirmNoCollision(gtaRoot, settings.DlcName)) return;

            var writeDialog = new RpfWriteDialog();
            writeDialog.Show(this.FindForm());
            System.Threading.Tasks.Task.Run(() =>
            {
                var result = RpfPackager.PackageVehicleDlcFromConvertedFiles(
                    gtaRoot: gtaRoot, settings: settings, convertedFilesDir: convertedDir,
                    progress: msg => writeDialog.AppendLog(msg));
                writeDialog.Finish(result);
            });
        }

        private void BtnMergeIntoExisting_Click(object sender, EventArgs e)
        {
            if (!RunPreflightLightCheck()) return;
            string gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;

            using var pickDlg = new OpenFileDialog
            {
                Title = "Select the existing dlc.rpf to merge into",
                Filter = "dlc.rpf|dlc.rpf|RPF archives (*.rpf)|*.rpf",
                InitialDirectory = Path.Combine(gtaRoot, "mods", "update", "x64", "dlcpacks")
            };
            if (pickDlg.ShowDialog(this.FindForm()) != DialogResult.OK) return;

            var confirm = MessageBox.Show(
                $"This will merge {detectedVehicles.Count} vehicle(s) into:\n{pickDlg.FileName}\n\n" +
                "The existing file will be backed up first. Continue?",
                "Confirm Merge", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes) return;

            var settings = BuildSettingsFromPanel("merge", gtaRoot);
            var writeDialog = new RpfWriteDialog();
            writeDialog.Show(this.FindForm());
            System.Threading.Tasks.Task.Run(() =>
            {
                var result = DlcMerger.MergeVehicleIntoExistingDlc(
                    gtaRoot: gtaRoot, existingDlcRpfPath: pickDlg.FileName, settings: settings,
                    convertedFilesDir: convertedDir, progress: msg => writeDialog.AppendLog(msg));
                writeDialog.Finish(result);
            });
        }

        private void BtnGenerateFromTemplate_Click(object sender, EventArgs e)
        {
            using var dlg = new MetaTemplateDialog(convertedDir);
            if (dlg.ShowDialog(this.FindForm()) != DialogResult.OK) return;

            var written = MetaTemplateGenerator.Generate(
                templateFolder: dlg.TemplateFolder,
                oldName: dlg.OldName,
                newName: dlg.NewName,
                outputFolder: dlg.OutputFolder,
                normalizeSirenIds: dlg.NormalizeSirenIds,
                log: null);

            MessageBox.Show(
                $"Generated {written.Count} file(s) in:\n{dlg.OutputFolder}\n\n" +
                string.Join("\n", written.Select(f => $"  • {f}")) +
                "\n\nIf this vehicle's folder is already loaded above, click Browse Folder again " +
                "(or re-drop it) to re-scan and pick these up.",
                "Template Generated", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    // =========================================================================
    //  MetaTemplateGenerator — precise, case-aware name substitution across a
    //  known-good single-vehicle .meta template, instead of hand-writing or
    //  guessing file content from scratch (which is what produced corrupt
    //  game data earlier in this conversation). Only ever replaces a name
    //  when it's the ENTIRE content of an XML element (matched as >old<,
    //  never as a substring) — so compound identifiers that happen to
    //  contain the old name (e.g. a shared preset like
    //  "STD_POLICE3_FRONT_LEFT") are never touched, only true identity
    //  fields like <modelName>/<txdName>/<gameName>/<handlingName>/<name>.
    // =========================================================================
    //  BuiltInVehicleTemplate
    //  Known-good, complete single-vehicle .meta set for "police3" (confirmed
    //  working by the user), embedded directly so the Generate Meta From
    //  Template feature no longer needs the user to browse to a template folder
    //  each time — just provide a new vehicle name and everything else is
    //  automatic. Goes through the exact same precise, exact-element-content-only
    //  substitution as MetaTemplateGenerator.Generate already does for an
    //  external template — nothing about the substitution logic changes, only
    //  where the source content comes from.
    // =========================================================================

    internal static class BuiltInVehicleTemplate
    {
        public const string OldName = "police3";

        public static readonly Dictionary<string, string> Files = new Dictionary<string, string>
        {
            ["vehicles.meta"] = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<CVehicleModelInfo__InitDataList>
  <residentTxd>vehshare</residentTxd>
  <residentAnims />
  <InitDatas>
    <Item>
      <modelName>police3</modelName>
      <txdName>police3</txdName>
      <handlingId>POLICE</handlingId>
      <gameName>police3</gameName>
      <vehicleMakeName>20FORD</vehicleMakeName>
      <expressionDictName>null</expressionDictName>
      <expressionName>null</expressionName>
      <animConvRoofDictName>null</animConvRoofDictName>
      <animConvRoofName>null</animConvRoofName>
      <animConvRoofWindowsAffected />
      <ptfxAssetName>null</ptfxAssetName>
      <audioNameHash>sentinel</audioNameHash>
      <layout>LAYOUT_STANDARD</layout>
      <coverBoundOffsets>CAVALCADE_COVER_OFFSET_INFO</coverBoundOffsets>
      <explosionInfo>EXPLOSION_INFO_DEFAULT</explosionInfo>
      <scenarioLayout />
      <cameraName>DEFAULT_FOLLOW_VEHICLE_CAMERA</cameraName>
      <aimCameraName>DEFAULT_THIRD_PERSON_VEHICLE_AIM_CAMERA</aimCameraName>
      <bonnetCameraName>VEHICLE_BONNET_CAMERA_MID_NEAR</bonnetCameraName>
      <povCameraName>DEFAULT_POV_CAMERA_LOOKAROUND</povCameraName>
      <FirstPersonDriveByIKOffset x=""0.000000"" y=""-0.050000"" z=""-0.030000"" />
      <FirstPersonDriveByUnarmedIKOffset x=""0.000000"" y=""0.000000"" z=""0.000000"" />
	  <FirstPersonProjectileDriveByIKOffset x=""0.000000"" y=""-0.088000"" z=""0.093000"" />
	  <FirstPersonProjectileDriveByPassengerIKOffset x=""0.020000"" y=""0.060000"" z=""-0.090000"" />
	  <FirstPersonProjectileDriveByRearLeftIKOffset x=""0.000000"" y=""0.000000"" z=""-0.055000"" />
	  <FirstPersonProjectileDriveByRearRightIKOffset x=""0.000000"" y=""0.000000"" z=""-0.055000"" />
	  <FirstPersonDriveByLeftPassengerIKOffset x=""0.000000"" y=""0.000000"" z=""-0.040000"" />
	  <FirstPersonDriveByRightPassengerIKOffset x=""-0.045000"" y=""-0.048000"" z=""-0.040000"" />
	  <FirstPersonDriveByRightRearPassengerIKOffset x=""0.000000"" y=""0.000000"" z=""-0.040000"" />
	  <FirstPersonDriveByLeftPassengerUnarmedIKOffset x=""0.000000"" y=""0.000000"" z=""0.000000"" />
	  <FirstPersonDriveByRightPassengerUnarmedIKOffset x=""0.000000"" y=""0.000000"" z=""0.000000"" />
	  <FirstPersonMobilePhoneOffset x=""0.150000"" y=""0.268000"" z=""0.503000"" />
      <FirstPersonPassengerMobilePhoneOffset x=""0.136000"" y=""0.223000"" z=""0.425000"" />
      <FirstPersonMobilePhoneSeatIKOffset>
		<Item>
			<Offset x=""0.156000"" y=""0.223000"" z=""0.493000"" />
			<SeatIndex value=""2"" />
		</Item>
		<Item>
			<Offset x=""0.156000"" y=""0.223000"" z=""0.493000"" />
			<SeatIndex value=""3"" />
		</Item>
	  </FirstPersonMobilePhoneSeatIKOffset>
      <PovCameraOffset x=""0.000000"" y=""-0.180000"" z=""0.620000"" />
      <PovCameraVerticalAdjustmentForRollCage value=""0.000000"" />
      <PovPassengerCameraOffset x=""0.000000"" y=""0.000000"" z=""0.030000"" />
      <PovRearPassengerCameraOffset x=""0.000000"" y=""0.000000"" z=""0.070000"" />
      <vfxInfoName>VFXVEHICLEINFO_CAR_GENERIC</vfxInfoName>
      <shouldUseCinematicViewMode value=""true"" />
      <shouldCameraTransitionOnClimbUpDown value=""false"" />
      <shouldCameraIgnoreExiting value=""false"" />
      <AllowPretendOccupants value=""true"" />
      <AllowJoyriding value=""false"" />
      <AllowSundayDriving value=""false"" />
      <AllowBodyColorMapping value=""true"" />
      <wheelScale value=""0.259000"" />
      <wheelScaleRear value=""0.259000"" />
      <dirtLevelMin value=""0.000000"" />
      <dirtLevelMax value=""50.000000"" />
      <envEffScaleMin value=""0.000000"" />
      <envEffScaleMax value=""1.000000"" />
      <envEffScaleMin2 value=""0.000000"" />
      <envEffScaleMax2 value=""1.000000"" />
      <damageMapScale value=""0.900000"" />
      <damageOffsetScale value=""1.000000"" />
      <diffuseTint value=""0xD1000000"" />
      <steerWheelMult value=""1.000000"" />
      <HDTextureDist value=""5.000000"" />
      <lodDistances content=""float_array"">
        25.000000
        40.000000
        100.000000
        150.000000
        300.000000
        500.000000
      </lodDistances>
      <minSeatHeight value=""0.966"" />
      <identicalModelSpawnDistance value=""20"" />
      <maxNumOfSameColor value=""10"" />
      <defaultBodyHealth value=""1000.000000"" />
      <pretendOccupantsScale value=""1.000000"" />
      <visibleSpawnDistScale value=""1.000000"" />
      <trackerPathWidth value=""2.000000"" />
      <weaponForceMult value=""1.000000"" />
      <frequency value=""100"" />
      <swankness>SWANKNESS_1</swankness>
      <maxNum value=""999"" />
      <flags>FLAG_USE_INTERIOR_RED_LIGHT FLAG_HAS_LIVERY FLAG_HAS_INTERIOR_EXTRAS FLAG_LAW_ENFORCEMENT FLAG_EMERGENCY_SERVICE FLAG_ALLOW_HATS_NO_ROOF</flags>
      <type>VEHICLE_TYPE_CAR</type>
      <plateType>VPT_FRONT_AND_BACK_PLATES</plateType>
	  <dashboardType>VDT_FEROCI</dashboardType>
      <vehicleClass>VC_EMERGENCY</vehicleClass>
      <wheelType>VWT_SPORT</wheelType>
      <trailers />
      <additionalTrailers />
      <drivers />
      <extraIncludes />
      <doorsWithCollisionWhenClosed />
      <driveableDoors />
      <bumpersNeedToCollideWithMap value=""false"" />
      <needsRopeTexture value=""false"" />
      <requiredExtras />
      <rewards />
      <cinematicPartCamera>
        <Item>WHEEL_FRONT_RIGHT_CAMERA</Item>
        <Item>WHEEL_FRONT_LEFT_CAMERA</Item>
        <Item>WHEEL_REAR_RIGHT_CAMERA</Item>
        <Item>WHEEL_REAR_LEFT_CAMERA</Item>
      </cinematicPartCamera>
      <NmBraceOverrideSet />
      <buoyancySphereOffset x=""0.000000"" y=""0.000000"" z=""0.000000"" />
      <buoyancySphereSizeScale value=""1.000000"" />
      <pOverrideRagdollThreshold type=""NULL"" />
      <firstPersonDrivebyData>
        <Item>RANGER_CAVALCADE_FRONT_LEFT</Item>
        <Item>RANGER_FRONT_RIGHT</Item>
        <Item>RANGER_PRANGER_REAR_LEFT</Item>
        <Item>RANGER_PRANGER_REAR_RIGHT</Item>
      </firstPersonDrivebyData>
    </Item>
  </InitDatas>
  <txdRelationships>
    <Item>
      <parent>vehicles_feroci_interior</parent>
      <child>bpd22</child>
    </Item>
  </txdRelationships>
</CVehicleModelInfo__InitDataList>",
            ["handling.meta"] = @"<?xml version=""1.0"" encoding=""UTF-8""?>

<CHandlingDataMgr>
  <HandlingData>
    <Item type=""CHandlingData"">
      <handlingName>POLICE3</handlingName>
      <fMass value=""2104.000000"" />
      <fInitialDragCoeff value=""8.000000"" />
      <fPercentSubmerged value=""85.000000"" />
      <vecCentreOfMassOffset x=""0.000000"" y=""0.050000"" z=""0.000000"" />
      <vecInertiaMultiplier x=""1.000000"" y=""1.600000"" z=""1.400000"" />
      <fDriveBiasFront value=""0.600000"" />
      <nInitialDriveGears value=""6"" />
      <fInitialDriveForce value=""0.300000"" />
      <fDriveInertia value=""0.900000"" />
      <fClutchChangeRateScaleUpShift value=""2.100000"" />
      <fClutchChangeRateScaleDownShift value=""2.100000"" />
      <fInitialDriveMaxFlatVel value=""175.000000"" />
      <fBrakeForce value=""0.700000"" />
      <fBrakeBiasFront value=""0.650000"" />
      <fHandBrakeForce value=""0.600000"" />
      <fSteeringLock value=""42.000000"" />
      <fTractionCurveMax value=""2.600000"" />
      <fTractionCurveMin value=""2.300000"" />
      <fTractionCurveLateral value=""24.000000"" />
      <fTractionSpringDeltaMax value=""0.150000"" />
      <fLowSpeedTractionLossMult value=""1.000000"" />
      <fCamberStiffnesss value=""0.000000"" />
      <fTractionBiasFront value=""0.450000"" />
      <fTractionLossMult value=""1.000000"" />
      <fSuspensionForce value=""3.000000"" />
      <fSuspensionCompDamp value=""1.300000"" />
      <fSuspensionReboundDamp value=""1.300000"" />
      <fSuspensionUpperLimit value=""0.110000"" />
      <fSuspensionLowerLimit value=""-0.120000"" />
      <fSuspensionRaise value=""0.000000"" />
      <fSuspensionBiasFront value=""0.520000"" />
      <fAntiRollBarForce value=""0.900000"" />
      <fAntiRollBarBiasFront value=""0.520000"" />
      <fRollCentreHeightFront value=""0.300000"" />
      <fRollCentreHeightRear value=""0.300000"" />
      <fCollisionDamageMult value=""1.000000"" />
      <fWeaponDamageMult value=""1.000000"" />
      <fDeformationDamageMult value=""0.800000"" />
      <fEngineDamageMult value=""1.500000"" />
      <fPetrolTankVolume value=""80.000000"" />
      <fOilVolume value=""8.000000"" />
      <fSeatOffsetDistX value=""0.000000"" />
      <fSeatOffsetDistY value=""0.000000"" />
      <fSeatOffsetDistZ value=""0.000000"" />
      <nMonetaryValue value=""50000"" />
      <strModelFlags>440010</strModelFlags>
      <strHandlingFlags>0</strHandlingFlags>
      <strDamageFlags>0</strDamageFlags>
      <AIHandling>AVERAGE</AIHandling>
      <SubHandlingData>
        <Item type=""CCarHandlingData"">
          <fBackEndPopUpCarImpulseMult value=""0.100000"" />
          <fBackEndPopUpBuildingImpulseMult value=""0.030000"" />
          <fBackEndPopUpMaxDeltaSpeed value=""0.600000"" />
        </Item>
        <Item type=""NULL"" />
        <Item type=""NULL"" />
      </SubHandlingData>
    </Item>
  </HandlingData>
</CHandlingDataMgr>",
            ["carvariations.meta"] = @"<?xml version=""1.0"" encoding=""UTF-8""?>

<CVehicleModelInfoVariation>
  <variationData>
    <Item>
      <modelName>police3</modelName>
     <colors>
        <Item>
          <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
          <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
          <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
          <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
          <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
          <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
        <Item>
	  <indices content=""char_array"">
            134 
            140 
            0 
            0 
          </indices>
          <liveries>
            <Item value=""false"" />
          </liveries>
        </Item>
      </colors>
      <kits>
        <Item>0_default_modkit</Item>
      </kits>
      <windowsWithExposedEdges />
      <plateProbabilities>
        <Probabilities>
          <Item>
            <Name>Police guv plate</Name>
            <Value value=""100"" />
          </Item>
        </Probabilities>
      </plateProbabilities>
      <lightSettings value=""0"" />
      <sirenSettings value=""3124"" />
    </Item>
  </variationData>
</CVehicleModelInfoVariation>",
            ["vehiclesstreamingdata.meta"] = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<CVehicleStreamingDataMgr__InitDataList>
  <InitDatas>
    <Item>
      <modelName>police3</modelName>
      <audioNameHash>police3</audioNameHash>
    </Item>
  </InitDatas>
</CVehicleStreamingDataMgr__InitDataList>",
            ["carcols.meta"] = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<CVehicleModelInfoVarGlobal>
  <Sirens>
    <Item>
      <id value=""3124""/>
      <name>police3</name>
      <timeMultiplier value=""1.0""/>
      <lightFalloffMax value=""10.0""/>
      <lightFalloffExponent value=""10.0""/>
      <lightInnerConeAngle value=""2.29061000""/>
      <lightOuterConeAngle value=""70.0""/>
      <lightOffset value=""0.00000000""/>
      <textureName>VehicleLight_sirenlight</textureName>
      <sequencerBpm value=""1140""/>
      <leftHeadLight>
        <sequencer value=""0""/>
      </leftHeadLight>
      <rightHeadLight>
        <sequencer value=""0""/>
      </rightHeadLight>
      <leftTailLight>
        <sequencer value=""0""/>
      </leftTailLight>
      <rightTailLight>
        <sequencer value=""0""/>
      </rightTailLight>
      <leftHeadLightMultiples value=""1""/>
      <rightHeadLightMultiples value=""1""/>
      <leftTailLightMultiples value=""2""/>
      <rightTailLightMultiples value=""2""/>
      <useRealLights value=""true""/>
      <sirens>
        <Item>
          <!-- Siren 1 -->
          <rotation>
            <delta value=""0.00000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""0""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""2852170240""/>
            <multiples value=""1""/>
            <direction value=""true""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFF0000FF""/>
          <intensity value=""3.5""/>
          <lightGroup value=""2""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 2 -->
          <rotation>
            <delta value=""0.00000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""3.14159265""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""2852170240""/>
            <multiples value=""1""/>
            <direction value=""true""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFF0000FF""/>
          <intensity value=""3.5""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 3 -->
          <rotation>
            <delta value=""0.00000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""0""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""11141290""/>
            <multiples value=""1""/>
            <direction value=""true""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFF0000""/>
          <intensity value=""3.5""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 4 -->
          <rotation>
            <delta value=""-0.01000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""3.14159265""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""11141290""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFF0000""/>
          <intensity value=""3.5""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 5 -->
          <rotation>
            <delta value=""-0.01000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""0""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""1227128832""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFF0000FF""/>
          <intensity value=""3.5""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 6 -->
          <rotation>
            <delta value=""-0.01000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""0""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""1227128832""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFF0000""/>
          <intensity value=""3.5""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 7 -->
          <rotation>
            <delta value=""0.00000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""3.14159265""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""2852170240""/>
            <multiples value=""1""/>
            <direction value=""true""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFF0000""/>
          <intensity value=""3.5""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 8 -->
          <rotation>
            <delta value=""-0.01000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""3.14159265""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""11141290""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFF0000FF""/>
          <intensity value=""3.5""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 9 -->
          <rotation>
            <delta value=""0.00000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""-0.57595865""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""1227128832""/>
            <multiples value=""2""/>
            <direction value=""true""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFF0000FF""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""true""/>
          <spotLight value=""true""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 10 -->
          <rotation>
            <delta value=""-0.01000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""0.57595865""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""4681""/>
            <multiples value=""2""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFF0000""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""true""/>
          <spotLight value=""true""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 11 -->
          <rotation>
            <delta value=""0.00000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""3.14159265""/>
            <start value=""4.71238900""/>
            <speed value=""1.00000000""/>
            <sequencer value=""11141290""/>
            <multiples value=""2""/>
            <direction value=""true""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFFFFFF""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""true""/>
          <spotLight value=""true""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 12 -->
          <rotation>
            <delta value=""-0.01000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""3.14159265""/>
            <start value=""0.00000000""/>
            <speed value=""28.68000000""/>
            <sequencer value=""2852170240""/>
            <multiples value=""2""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFFFFFF""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 13 -->
          <rotation>
            <delta value=""0.00000000""/>
            <start value=""0.00000000""/>
            <speed value=""1.00000000""/>
            <sequencer value=""0""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""false""/>
          </rotation>
          <flashiness>
            <delta value=""0""/>
            <start value=""0.00000000""/>
            <speed value=""1.00000000""/>
            <sequencer value=""4681""/>
            <multiples value=""2""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFFFFFF""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 14 -->
          <rotation>
            <delta value=""-0.01000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""0""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""4681""/>
            <multiples value=""2""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFFFFFF""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""true""/>
          <spotLight value=""true""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 15 -->
          <rotation>
            <delta value=""0.00000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""0""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""1227128832""/>
            <multiples value=""2""/>
            <direction value=""true""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFF0000FF""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""true""/>
          <spotLight value=""true""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 16 -->
          <rotation>
            <delta value=""-0.01000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""0""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""1227128832""/>
            <multiples value=""2""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFF0000""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""true""/>
          <spotLight value=""true""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 17 -->
          <rotation>
            <delta value=""0.00000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""-1.57079633""/>
            <start value=""4.71238900""/>
            <speed value=""1.00000000""/>
            <sequencer value=""11141290""/>
            <multiples value=""2""/>
            <direction value=""true""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFF0000""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""true""/>
          <spotLight value=""true""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 18 -->
          <rotation>
            <delta value=""-0.01000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""-1.57079633""/>
            <start value=""0.00000000""/>
            <speed value=""28.68000000""/>
            <sequencer value=""2852170240""/>
            <multiples value=""2""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFF0000FF""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 19 -->
          <rotation>
            <delta value=""0.00000000""/>
            <start value=""0.00000000""/>
            <speed value=""1.00000000""/>
            <sequencer value=""0""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""false""/>
          </rotation>
          <flashiness>
            <delta value=""1.57079633""/>
            <start value=""0.00000000""/>
            <speed value=""1.00000000""/>
            <sequencer value=""11141290""/>
            <multiples value=""2""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFFFF0000""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""false""/>
          <spotLight value=""false""/>
          <castShadows value=""false""/>
        </Item>
        <Item>
          <!-- Siren 20 -->
          <rotation>
            <delta value=""-0.01000000""/>
            <start value=""0.00000000""/>
            <speed value=""3.00000000""/>
            <sequencer value=""4294967295""/>
            <multiples value=""1""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </rotation>
          <flashiness>
            <delta value=""1.57079633""/>
            <start value=""0.00000000""/>
            <speed value=""0.00000000""/>
            <sequencer value=""2852170240""/>
            <multiples value=""2""/>
            <direction value=""false""/>
            <syncToBpm value=""true""/>
          </flashiness>
          <corona>
            <intensity value=""25.00000000""/>
            <size value=""0.50000000""/>
            <pull value=""0.15000000""/>
            <faceCamera value=""false""/>
          </corona>
          <color value=""0xFF0000FF""/>
          <intensity value=""1""/>
          <lightGroup value=""1""/>
          <rotate value=""false""/>
          <scale value=""true""/>
          <scaleFactor value=""100""/>
          <flash value=""true""/>
          <light value=""true""/>
          <spotLight value=""true""/>
          <castShadows value=""false""/>
        </Item>
      </sirens>
    </Item>
  </Sirens>
</CVehicleModelInfoVarGlobal>",
        };
    }

    // =========================================================================

    internal static class MetaTemplateGenerator
    {
        public static readonly string[] TemplateFileNames =
            { "vehicles.meta", "handling.meta", "carvariations.meta", "vehiclesstreamingdata.meta", "carcols.meta" };

        public static List<string> Generate(
            string templateFolder, string oldName, string newName, string outputFolder,
            bool normalizeSirenIds, Action<string> log)
        {
            Directory.CreateDirectory(outputFolder);
            var written = new List<string>();
            string oldLower = oldName.ToLowerInvariant();
            string newLower = newName.ToLowerInvariant();
            string oldUpper = oldName.ToUpperInvariant();
            string newUpper = newName.ToUpperInvariant();
            string oldTitle = oldName.Length > 0 ? char.ToUpperInvariant(oldName[0]) + oldName.Substring(1).ToLowerInvariant() : oldName;
            string newTitle = newName.Length > 0 ? char.ToUpperInvariant(newName[0]) + newName.Substring(1).ToLowerInvariant() : newName;

            bool useBuiltIn = string.IsNullOrWhiteSpace(templateFolder);

            foreach (var fileName in TemplateFileNames)
            {
                string content;
                if (useBuiltIn)
                {
                    if (!BuiltInVehicleTemplate.Files.TryGetValue(fileName, out content))
                    {
                        log?.Invoke($"{fileName}: not in the built-in template, skipped.");
                        continue;
                    }
                }
                else
                {
                    string srcPath = Path.Combine(templateFolder, fileName);
                    if (!File.Exists(srcPath))
                    {
                        log?.Invoke($"{fileName}: not found in template, skipped.");
                        continue;
                    }
                    content = File.ReadAllText(srcPath);
                }

                content = ReplaceExactElementContent(content, oldLower, newLower);
                content = ReplaceExactElementContent(content, oldUpper, newUpper);
                if (oldTitle != oldLower && oldTitle != oldUpper)
                    content = ReplaceExactElementContent(content, oldTitle, newTitle);

                if (normalizeSirenIds && fileName.Equals("carvariations.meta", StringComparison.OrdinalIgnoreCase))
                {
                    // Match the standalone build's own carcols.meta convention
                    // (always id=1 for a single fresh vehicle) instead of
                    // carrying over a number from the template's original
                    // accumulated-pack context, which would mismatch and
                    // silently produce non-working sirens again.
                    content = System.Text.RegularExpressions.Regex.Replace(
                        content, @"<sirenSettings value=""\d+""\s*/>", "<sirenSettings value=\"1\" />");
                    content = System.Text.RegularExpressions.Regex.Replace(
                        content, @"<lightSettings value=""\d+""\s*/>", "<lightSettings value=\"1\" />");
                }

                string destPath = Path.Combine(outputFolder, fileName);
                File.WriteAllText(destPath, content, Encoding.UTF8);
                written.Add(fileName);
                log?.Invoke($"{fileName}: generated for \"{newName}\".");
            }

            return written;
        }

        private static string ReplaceExactElementContent(string content, string oldToken, string newToken)
        {
            if (string.IsNullOrEmpty(oldToken)) return content;
            return System.Text.RegularExpressions.Regex.Replace(
                content,
                $@"(?<=>){System.Text.RegularExpressions.Regex.Escape(oldToken)}(?=<)",
                newToken);
        }
    }

    // =========================================================================
    //  MetaTemplateDialog — pick a known-good template folder + old/new names
    // =========================================================================

    internal class MetaTemplateDialog : Form
    {
        public string TemplateFolder { get; private set; } // null = use built-in
        public string OldName { get; private set; }
        public string NewName { get; private set; }
        public string OutputFolder { get; private set; }
        public bool NormalizeSirenIds { get; private set; }

        private CheckBox chkUseCustom;
        private TextBox txtTemplateFolder, txtOldName, txtNewName, txtOutputFolder;
        private Button btnPickTemplate;
        private CheckBox chkNormalize;
        private Label lblFound, lblBuiltInInfo;

        public MetaTemplateDialog(string defaultOutputFolder)
        {
            this.Text = "Generate Meta From Template";
            this.Size = new Size(640, 400); this.MinimumSize = new Size(560, 360);
            this.StartPosition = FormStartPosition.CenterParent; this.FormBorderStyle = FormBorderStyle.Sizable;
            this.BackColor = Theme.Surface; this.ForeColor = Theme.Text;
            int y = 14;
            void AddLbl(string t) { var l = Theme.MakeLabel(t, true); l.Location = new Point(14, y); this.Controls.Add(l); }

            lblBuiltInInfo = new Label
            {
                Text = $"Using the built-in known-good template (based on \"{BuiltInVehicleTemplate.OldName}\") — " +
                       "just type the new vehicle's name below.",
                AutoSize = true,
                ForeColor = Theme.Success,
                Location = new Point(14, y),
                MaximumSize = new Size(600, 0)
            };
            this.Controls.Add(lblBuiltInInfo); y += 36;

            AddLbl("New vehicle name:"); y += 18;
            txtNewName = Theme.MakeTextBox("", 220); txtNewName.Location = new Point(14, y); this.Controls.Add(txtNewName); y += 32;

            chkUseCustom = new CheckBox
            {
                Text = "Use a different template folder instead (advanced)",
                AutoSize = true,
                ForeColor = Theme.Muted,
                Location = new Point(14, y)
            };
            chkUseCustom.CheckedChanged += (s, e) =>
            {
                bool custom = chkUseCustom.Checked;
                txtTemplateFolder.Visible = btnPickTemplate.Visible = txtOldName.Visible = lblFound.Visible = custom;
                lblBuiltInInfo.Visible = !custom;
            };
            this.Controls.Add(chkUseCustom); y += 26;

            txtTemplateFolder = Theme.MakeTextBox("", 460); txtTemplateFolder.Location = new Point(14, y); txtTemplateFolder.Visible = false;
            this.Controls.Add(txtTemplateFolder);
            btnPickTemplate = Theme.MakeButton("…", 36); btnPickTemplate.Location = new Point(480, y - 1); btnPickTemplate.Visible = false;
            btnPickTemplate.Click += (s, e) =>
            {
                using var d = new FolderBrowserDialog { Description = "Select the folder with the known-good .meta files" };
                if (d.ShowDialog() == DialogResult.OK) { txtTemplateFolder.Text = d.SelectedPath; TryAutoDetectOldName(d.SelectedPath); }
            };
            this.Controls.Add(btnPickTemplate); y += 30;

            lblFound = new Label { AutoSize = true, ForeColor = Theme.Muted, Location = new Point(14, y), Text = "", Visible = false };
            this.Controls.Add(lblFound); y += 24;

            txtOldName = Theme.MakeTextBox("", 220); txtOldName.Location = new Point(14, y); txtOldName.Visible = false;
            this.Controls.Add(txtOldName); y += 32;

            AddLbl("Output folder (where the generated files go — usually your vehicle's own folder):"); y += 18;
            txtOutputFolder = Theme.MakeTextBox("", 460); txtOutputFolder.Text = defaultOutputFolder ?? ""; txtOutputFolder.Location = new Point(14, y);
            this.Controls.Add(txtOutputFolder);
            var btnPickOutput = Theme.MakeButton("…", 36); btnPickOutput.Location = new Point(480, y - 1);
            btnPickOutput.Click += (s, e) => { using var d = new FolderBrowserDialog(); if (d.ShowDialog() == DialogResult.OK) txtOutputFolder.Text = d.SelectedPath; };
            this.Controls.Add(btnPickOutput); y += 32;

            chkNormalize = new CheckBox
            {
                Text = "Normalize siren/light settings to 1 (recommended for a fresh standalone build)",
                AutoSize = true,
                ForeColor = Theme.Text,
                Location = new Point(14, y),
                Checked = true
            };
            this.Controls.Add(chkNormalize); y += 34;

            var btnGenerate = Theme.MakeButton("🧬 Generate", 140, 30, true); btnGenerate.DialogResult = DialogResult.OK;
            btnGenerate.Click += (s, e) =>
            {
                bool custom = chkUseCustom.Checked;
                if (string.IsNullOrWhiteSpace(txtNewName.Text) || string.IsNullOrWhiteSpace(txtOutputFolder.Text) ||
                    (custom && (string.IsNullOrWhiteSpace(txtTemplateFolder.Text) || string.IsNullOrWhiteSpace(txtOldName.Text))))
                {
                    MessageBox.Show("Please fill in all required fields.", "Missing Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.DialogResult = DialogResult.None;
                    return;
                }
                TemplateFolder = custom ? txtTemplateFolder.Text.Trim() : null;
                OldName = custom ? txtOldName.Text.Trim() : BuiltInVehicleTemplate.OldName;
                NewName = txtNewName.Text.Trim();
                OutputFolder = txtOutputFolder.Text.Trim();
                NormalizeSirenIds = chkNormalize.Checked;
            };
            var btnCancel = Theme.MakeButton("Cancel", 80, 30); btnCancel.DialogResult = DialogResult.Cancel;
            var btnPanel = new FlowLayoutPanel { Dock = DockStyle.Bottom, FlowDirection = FlowDirection.RightToLeft, Height = 44, BackColor = Theme.Surface, Padding = new Padding(8, 6, 8, 6) };
            btnPanel.Controls.AddRange(new Control[] { btnCancel, btnGenerate }); this.Controls.Add(btnPanel);
            this.AcceptButton = btnGenerate; this.CancelButton = btnCancel;
        }

        private void TryAutoDetectOldName(string folder)
        {
            try
            {
                string vehiclesMetaPath = Path.Combine(folder, "vehicles.meta");
                if (!File.Exists(vehiclesMetaPath)) { lblFound.Text = "vehicles.meta not found in this folder."; lblFound.ForeColor = Theme.Warning; return; }
                string content = File.ReadAllText(vehiclesMetaPath);
                var m = System.Text.RegularExpressions.Regex.Match(content, @"<modelName>([^<]+)</modelName>");
                if (m.Success)
                {
                    txtOldName.Text = m.Groups[1].Value;
                    var present = MetaTemplateGenerator.TemplateFileNames.Where(f => File.Exists(Path.Combine(folder, f)));
                    lblFound.Text = $"✔ Detected \"{m.Groups[1].Value}\" — found: {string.Join(", ", present)}";
                    lblFound.ForeColor = Theme.Success;
                }
                else
                {
                    lblFound.Text = "Could not auto-detect modelName — please fill in Old vehicle name manually.";
                    lblFound.ForeColor = Theme.Warning;
                }
            }
            catch (Exception ex)
            {
                lblFound.Text = $"Could not read template: {ex.Message}";
                lblFound.ForeColor = Theme.Danger;
            }
        }
    }

    // =========================================================================
    //  AddonCreatorPanel  — NOW with Siren & Audio columns
    // =========================================================================

    internal class AddonCreatorPanel : UserControl
    {
        private TextBox txtDlcName, txtOutputDir;
        private DataGridView gridVehicles, gridPeds;
        private List<AddonVehicleEntry> vehicles = new List<AddonVehicleEntry>();
        private List<AddonPedEntry> peds = new List<AddonPedEntry>();

        // ── NEW: light/audio config dictionary ───────────────────────────────
        private Dictionary<string, VehicleLightAudioConfig> lightAudioConfigs
            = new Dictionary<string, VehicleLightAudioConfig>();

        private Dictionary<string, ElsConfig> elsConfigs
    = new Dictionary<string, ElsConfig>();

        private Button btnAddVehicle, btnRemoveVehicle, btnGenerateVehicle;
        private Button btnAddPed, btnRemovePed, btnGeneratePed;
        private Button btnGenerateAll;
        private Label lblStatus;
        private TabControl innerTabs;

        private static readonly string[] SirenNames = Enum.GetNames(typeof(SirenPreset));
        private static readonly string[] AudioNames = Enum.GetNames(typeof(AudioPreset));
        private static readonly string[] VehicleTypeNames = {
            "VEHICLE_TYPE_CAR","VEHICLE_TYPE_BIKE","VEHICLE_TYPE_BICYCLE","VEHICLE_TYPE_BOAT",
            "VEHICLE_TYPE_HELI","VEHICLE_TYPE_PLANE","VEHICLE_TYPE_QUADBIKE","VEHICLE_TYPE_SUBMARINE",
            "VEHICLE_TYPE_TRAILER","VEHICLE_TYPE_TRAIN","VEHICLE_TYPE_AMPHIBIOUS_AUTOMOBILE",
        };
        private static readonly string[] VehicleLayoutNames = {
            "LAYOUT_STD","LAYOUT_LOW","LAYOUT_VAN","LAYOUT_TRUCK","LAYOUT_SUV",
            "LAYOUT_MOTORBIKE","LAYOUT_BIKE","LAYOUT_BOAT_AIRBOAT","LAYOUT_HELI",
            "LAYOUT_PLANE_FIGHTER","LAYOUT_TRUCK_ARTIC1",
        };
        private static readonly string[] SwanknessNames = { "SWANKNESS_1", "SWANKNESS_2", "SWANKNESS_3", "SWANKNESS_4", "SWANKNESS_5" };
        private static readonly string[] PlateTypeNames = { "VPT_FRONT_AND_BACK_PLATES", "VPT_FRONT_PLATES", "VPT_BACK_PLATES", "VPT_NONE" };
        private static readonly string[] TerrainStateNames = { "WALKING", "ON_ROAD", "OFF_ROAD", "STAIRS" };

        // ── Vehicle master / detail state ─────────────────────────────────────
        private int selectedVehicleIndex = -1;
        private int selectedPedIndex = -1;
        private bool _loadingDetail = false;

        private TextBox dvSpawn, dvGameName, dvMake, dvElsName, dvAudioInherit;
        private ComboBox dvCategory, dvVehicleType, dvLayout, dvSwankness, dvPlateType, dvSiren, dvAudioPreset;
        private CheckBox dvUseEls, dvHi;
        private NumericUpDown dvMass, dvDriveForce, dvTopSpeed, dvGears, dvBrakeForce, dvDriveBias, dvSirenCount, dvNumWheels, dvHp, dvMaxNum;
        private Button dvBtnColors, dvBtnEls;
        private Panel vehicleDetailPanel, vehicleEmptyPanel;
        private Label lblVehicleDetailTitle;

        // ── Ped master / detail state ───────────────────────────────────────
        private TextBox dpModel, dpClipDict, dpStrafeClip, dpVoiceGroup;
        private ComboBox dpPedType, dpMovement, dpPersonality, dpSpawnSet, dpTerrainState;
        private CheckBox dpStreamed, dpInheritProps;
        private Panel pedDetailPanel, pedEmptyPanel;
        private Label lblPedDetailTitle;

        public AddonCreatorPanel()
        {
            this.BackColor = Theme.Background;
            Theme.ThemeChanged += () => this.BackColor = Theme.Background;
            Build();
        }

        private void Build()
        {
            const int PAD = 12;
            var header = new Panel { Dock = DockStyle.Top, Height = 70, BackColor = Theme.Surface };
            header.Paint += (s, e) => { using var p = new Pen(Theme.Border); e.Graphics.DrawLine(p, PAD, 62, header.Width - PAD, 62); };
            var lblTitle = new Label { Text = "🔧  Addon Creator", Location = new Point(PAD, 10), AutoSize = true, ForeColor = Theme.Accent, Font = new Font("Segoe UI", 11f, FontStyle.Bold) };
            var lblSub = new Label { Text = "Generate GTA V addon DLC meta files — vehicles.meta, handling.meta, carvariations.meta, carcols.meta, peds.meta, content.xml, setup2.xml", Location = new Point(PAD, 32), AutoSize = true, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            var lblDlc = Theme.MakeLabel("DLC name (lowercase, no spaces):"); lblDlc.Location = new Point(620, 10);
            txtDlcName = Theme.MakeTextBox("e.g. my_addon", 160); txtDlcName.Location = new Point(620, 28);
            var lblOut = Theme.MakeLabel("Output folder:"); lblOut.Location = new Point(790, 10);
            txtOutputDir = Theme.MakeTextBox("C:\\GTA V Mods\\output", 200); txtOutputDir.Location = new Point(790, 28);
            var btnBrowse = Theme.MakeButton("…", 28); btnBrowse.Location = new Point(995, 27);
            btnBrowse.Click += (s, e) => { using var d = new FolderBrowserDialog(); if (d.ShowDialog() == DialogResult.OK) txtOutputDir.Text = d.SelectedPath; };
            header.Controls.AddRange(new Control[] { lblTitle, lblSub, lblDlc, txtDlcName, lblOut, txtOutputDir, btnBrowse });
            header.Resize += (s, e) => { int r = header.Width - PAD; btnBrowse.Location = new Point(r - 28, 27); txtOutputDir.Width = r - 28 - 796; };

            innerTabs = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            var tabVehicle = new TabPage("  🚗  Vehicles  ");
            var tabPed = new TabPage("  🧍  Peds  ");
            var tabPreview = new TabPage("  📄  Preview XML  ");
            tabVehicle.BackColor = tabPed.BackColor = tabPreview.BackColor = Theme.Background;
            innerTabs.TabPages.AddRange(new[] { tabVehicle, tabPed, tabPreview });

            BuildVehicleTab(tabVehicle);
            BuildPedTab(tabPed);
            BuildPreviewTab(tabPreview);

            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 46, BackColor = Theme.Surface, Padding = new Padding(PAD, 8, PAD, 8) };
            bottom.Paint += (s, e) => { using var p = new Pen(Theme.Border); e.Graphics.DrawLine(p, PAD, 0, bottom.Width - PAD, 0); };
            btnGenerateAll = Theme.MakeButton("▶  Generate All Meta Files", 200, 28, true); btnGenerateAll.Location = new Point(PAD, 8);
            btnGenerateAll.Click += BtnGenerateAll_Click;
            lblStatus = new Label { Text = "Add vehicles or peds above, then click Generate.", AutoSize = true, Location = new Point(220, 14), ForeColor = Theme.Muted };
            bottom.Controls.AddRange(new Control[] { btnGenerateAll, lblStatus });

            this.Controls.Add(innerTabs);
            this.Controls.Add(bottom);
            this.Controls.Add(header);
        }

        private void BuildVehicleTab(TabPage tab)
        {
            const int PAD = 8;
            var toolbar = new Panel { Dock = DockStyle.Top, Height = 38, BackColor = Theme.Surface2 };

            btnAddVehicle = Theme.MakeButton("＋ Add Vehicle", 110, 26, true);
            btnRemoveVehicle = Theme.MakeButton("✕ Remove", 80);
            btnGenerateVehicle = Theme.MakeButton("⬇ Save vehicles/handling/carcols", 210);

            btnAddVehicle.Location = new Point(PAD, 6);
            btnRemoveVehicle.Location = new Point(PAD + 116, 6);
            btnGenerateVehicle.Location = new Point(PAD + 202, 6);

            btnAddVehicle.Click += (s, e) =>
            {
                var v = new AddonVehicleEntry { SpawnName = $"vehicle_{vehicles.Count + 1}" };
                vehicles.Add(v);
                lightAudioConfigs[v.SpawnName] = new VehicleLightAudioConfig();
                elsConfigs[v.SpawnName] = new ElsConfig();
                RefreshVehicleGrid();
                if (gridVehicles.Rows.Count > 0)
                {
                    var row = gridVehicles.Rows[gridVehicles.Rows.Count - 1];
                    gridVehicles.ClearSelection();
                    row.Selected = true;
                    gridVehicles.CurrentCell = row.Cells[0];
                }
            };

            btnRemoveVehicle.Click += (s, e) =>
            {
                if (selectedVehicleIndex < 0 || selectedVehicleIndex >= vehicles.Count) return;
                var removed = vehicles[selectedVehicleIndex];
                lightAudioConfigs.Remove(removed.SpawnName);
                elsConfigs.Remove(removed.SpawnName);
                int idx = selectedVehicleIndex;
                vehicles.RemoveAt(idx);
                RefreshVehicleGrid();
                if (vehicles.Count == 0)
                {
                    LoadVehicleDetail(-1);
                }
                else
                {
                    int newIdx = Math.Min(idx, vehicles.Count - 1);
                    gridVehicles.ClearSelection();
                    gridVehicles.Rows[newIdx].Selected = true;
                    gridVehicles.CurrentCell = gridVehicles.Rows[newIdx].Cells[0];
                }
            };

            btnGenerateVehicle.Click += (s, e) => SaveIndividualFiles();

            toolbar.Controls.AddRange(new Control[] { btnAddVehicle, btnRemoveVehicle, btnGenerateVehicle });

            // ── ELS name disclaimer ──────────────────────────────────────────────
            var elsDisclaimer = new Label
            {
                Text = "ℹ  Use ELS — tick to generate an ELS .xml config for this vehicle (requires Emergency Lighting System mod). " +
                       "ELS Name must exactly match the vehicle's spawn name as registered in ELS. " +
                       "Leave 'Use ELS' unticked for vanilla GTA siren lights.",
                Dock = DockStyle.Top,
                Height = 36,
                Padding = new Padding(8, 6, 8, 0),
                ForeColor = Theme.Warning,
                BackColor = Color.FromArgb(40, 35, 10),
                Font = new Font("Segoe UI", 7.8f),
                AutoEllipsis = true,
            };

            var hint = MakeHintLabel(
                "Select a vehicle on the left to edit its full details on the right. " +
                "Use ELS — tick for Emergency Lighting System support (generates an ELS .xml). " +
                "Engine Audio — Inherit borrows a vanilla bank.");

            // ── Master list (left) ──────────────────────────────────────────────
            var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterDistance = 300, BackColor = Theme.Background };

            gridVehicles = MakeGrid();
            gridVehicles.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Spawn Name", Name = "spawn", FillWeight = 45 });
            gridVehicles.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Category", Name = "cat", FillWeight = 30 });
            gridVehicles.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Siren / ELS", Name = "siren", FillWeight = 25 });
            gridVehicles.ReadOnly = true;
            gridVehicles.MultiSelect = false;
            gridVehicles.AllowUserToResizeRows = false;
            gridVehicles.SelectionChanged += (s, e) =>
            {
                LoadVehicleDetail(gridVehicles.SelectedRows.Count > 0 ? gridVehicles.SelectedRows[0].Index : -1);
            };
            split.Panel1.Controls.Add(gridVehicles);

            // ── Detail panel (right) ────────────────────────────────────────────
            var detailHost = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Theme.Background };

            vehicleEmptyPanel = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Background };
            vehicleEmptyPanel.Controls.Add(new Label
            {
                Text = "Select a vehicle from the list, or click ＋ Add Vehicle to create one.",
                AutoSize = true,
                Location = new Point(24, 24),
                ForeColor = Theme.Muted,
                Font = new Font("Segoe UI", 9f)
            });

            vehicleDetailPanel = new Panel { Location = new Point(0, 0), Width = 560, BackColor = Theme.Background };

            lblVehicleDetailTitle = new Label { Location = new Point(16, 12), AutoSize = true, ForeColor = Theme.Accent, Font = new Font("Segoe UI", 10.5f, FontStyle.Bold) };
            vehicleDetailPanel.Controls.Add(lblVehicleDetailTitle);

            int y = 46;
            y = DSection(vehicleDetailPanel, y, "Identity");
            dvSpawn = DTxt(); y = DRow(vehicleDetailPanel, 16, y, "Spawn Name", dvSpawn, 220);
            dvGameName = DTxt(); dvGameName.PlaceholderText = "e.g. BUFFALO"; y = DRow(vehicleDetailPanel, 16, y, "Game Name (display)", dvGameName, 220);
            dvMake = DTxt(); dvMake.PlaceholderText = "MAKE_GENERIC"; y = DRow(vehicleDetailPanel, 16, y, "Make", dvMake, 220);
            dvCategory = DCbo(VehicleCategories.All.ToArray()); y = DRow(vehicleDetailPanel, 16, y, "Category", dvCategory, 220);
            dvVehicleType = DCbo(VehicleTypeNames); y = DRow(vehicleDetailPanel, 16, y, "Vehicle Type", dvVehicleType, 220);
            dvLayout = DCbo(VehicleLayoutNames); y = DRow(vehicleDetailPanel, 16, y, "Seat Layout", dvLayout, 220);
            dvHi = DChk("Has Hi-detail model (_hi.yft)"); dvHi.Location = new Point(16, y); vehicleDetailPanel.Controls.Add(dvHi); y += 32;

            y = DSection(vehicleDetailPanel, y, "Handling");
            dvMass = DNum(1, 20000, 10, 1); y = DRow(vehicleDetailPanel, 16, y, "Mass (kg)", dvMass, 130);
            dvTopSpeed = DNum(1, 500, 1, 1); y = DRow(vehicleDetailPanel, 16, y, "Top Speed", dvTopSpeed, 130);
            dvDriveForce = DNum(0, 5, 0.01m, 3); y = DRow(vehicleDetailPanel, 16, y, "Drive Force", dvDriveForce, 130);
            dvGears = DNum(1, 10, 1, 0); y = DRow(vehicleDetailPanel, 16, y, "Drive Gears", dvGears, 130);
            dvBrakeForce = DNum(0, 5, 0.01m, 3); y = DRow(vehicleDetailPanel, 16, y, "Brake Force", dvBrakeForce, 130);
            dvDriveBias = DNum(-1, 1, 0.05m, 2); y = DRow(vehicleDetailPanel, 16, y, "Drive Bias (Front)", dvDriveBias, 130);

            y = DSection(vehicleDetailPanel, y, "Extra Attributes");
            dvSwankness = DCbo(SwanknessNames); y = DRow(vehicleDetailPanel, 16, y, "Swankness", dvSwankness, 220);
            dvPlateType = DCbo(PlateTypeNames); y = DRow(vehicleDetailPanel, 16, y, "Plate Type", dvPlateType, 220);
            dvNumWheels = DNum(1, 8, 1, 0); y = DRow(vehicleDetailPanel, 16, y, "Number of Wheels", dvNumWheels, 130);
            dvHp = DNum(0, 99999, 50, 0); y = DRow(vehicleDetailPanel, 16, y, "Engine HP value", dvHp, 130);
            dvMaxNum = DNum(1, 50, 1, 0); y = DRow(vehicleDetailPanel, 16, y, "Max Population Count", dvMaxNum, 130);

            y = DSection(vehicleDetailPanel, y, "Siren & Audio");
            dvUseEls = DChk("Use ELS (Emergency Lighting System)"); dvUseEls.Location = new Point(16, y); vehicleDetailPanel.Controls.Add(dvUseEls); y += 30;
            dvElsName = DTxt(); dvElsName.PlaceholderText = "must match ELS registered name"; y = DRow(vehicleDetailPanel, 16, y, "ELS Name", dvElsName, 220);
            dvSiren = DCbo(SirenNames); y = DRow(vehicleDetailPanel, 16, y, "Siren Preset (non-ELS)", dvSiren, 220);
            dvSirenCount = DNum(1, 8, 1, 0); y = DRow(vehicleDetailPanel, 16, y, "Siren Light Count", dvSirenCount, 130);
            dvAudioPreset = DCbo(AudioNames); y = DRow(vehicleDetailPanel, 16, y, "Engine Audio", dvAudioPreset, 220);
            dvAudioInherit = DTxt(); dvAudioInherit.PlaceholderText = "police"; y = DRow(vehicleDetailPanel, 16, y, "Inherit Audio From", dvAudioInherit, 220);

            dvBtnColors = Theme.MakeButton("🎨 Edit Colours…", 160, 26); dvBtnColors.Location = new Point(16, y);
            dvBtnEls = Theme.MakeButton("⚡ Edit ELS Config…", 160, 26); dvBtnEls.Location = new Point(184, y);
            vehicleDetailPanel.Controls.Add(dvBtnColors);
            vehicleDetailPanel.Controls.Add(dvBtnEls);
            y += 40;
            vehicleDetailPanel.Height = y + 20;

            detailHost.Controls.Add(vehicleDetailPanel);
            detailHost.Controls.Add(vehicleEmptyPanel);
            split.Panel2.Controls.Add(detailHost);

            // ── Wire up live commit handlers ────────────────────────────────────
            dvSpawn.TextChanged += (s, e) =>
            {
                if (_loadingDetail || selectedVehicleIndex < 0) return;
                var v = vehicles[selectedVehicleIndex];
                string oldName = v.SpawnName;
                string newName = dvSpawn.Text;
                if (oldName != newName)
                {
                    if (lightAudioConfigs.ContainsKey(oldName)) { lightAudioConfigs[newName] = lightAudioConfigs[oldName]; lightAudioConfigs.Remove(oldName); }
                    if (elsConfigs.ContainsKey(oldName)) { elsConfigs[newName] = elsConfigs[oldName]; elsConfigs.Remove(oldName); }
                    v.SpawnName = newName;
                    lblVehicleDetailTitle.Text = "🚗  " + (string.IsNullOrWhiteSpace(newName) ? "(unnamed vehicle)" : newName);
                    RefreshVehicleRowSummary(selectedVehicleIndex);
                }
            };
            dvGameName.TextChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].GameName = dvGameName.Text; };
            dvMake.TextChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].MakeName = dvMake.Text; };
            dvCategory.SelectedIndexChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) { vehicles[selectedVehicleIndex].Category = dvCategory.SelectedItem?.ToString() ?? vehicles[selectedVehicleIndex].Category; RefreshVehicleRowSummary(selectedVehicleIndex); } };
            dvVehicleType.SelectedIndexChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].VehicleType = dvVehicleType.SelectedItem?.ToString() ?? vehicles[selectedVehicleIndex].VehicleType; };
            dvLayout.SelectedIndexChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].Layout = dvLayout.SelectedItem?.ToString() ?? vehicles[selectedVehicleIndex].Layout; };
            dvHi.CheckedChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].HasHiModel = dvHi.Checked; };

            dvMass.ValueChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].Mass = (float)dvMass.Value; };
            dvTopSpeed.ValueChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].TopSpeed = (float)dvTopSpeed.Value; };
            dvDriveForce.ValueChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].DriveForce = (float)dvDriveForce.Value; };
            dvGears.ValueChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].DriveGears = (int)dvGears.Value; };
            dvBrakeForce.ValueChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].BrakeForce = (float)dvBrakeForce.Value; };
            dvDriveBias.ValueChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].DriveBias = (float)dvDriveBias.Value; };

            dvSwankness.SelectedIndexChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].Swankness = dvSwankness.SelectedItem?.ToString() ?? vehicles[selectedVehicleIndex].Swankness; };
            dvPlateType.SelectedIndexChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].PlateType = dvPlateType.SelectedItem?.ToString() ?? vehicles[selectedVehicleIndex].PlateType; };
            dvNumWheels.ValueChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].NumWheels = (int)dvNumWheels.Value; };
            dvHp.ValueChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].Hp = (int)dvHp.Value; };
            dvMaxNum.ValueChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) vehicles[selectedVehicleIndex].MaxNum = (int)dvMaxNum.Value; };

            dvUseEls.CheckedChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) { vehicles[selectedVehicleIndex].UseEls = dvUseEls.Checked; RefreshVehicleRowSummary(selectedVehicleIndex); } };
            dvElsName.TextChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) { vehicles[selectedVehicleIndex].ElsName = dvElsName.Text; RefreshVehicleRowSummary(selectedVehicleIndex); } };
            dvSiren.SelectedIndexChanged += (s, e) =>
            {
                if (_loadingDetail || selectedVehicleIndex < 0) return;
                var cfg = GetOrCreateVehicleCfg(vehicles[selectedVehicleIndex].SpawnName);
                if (Enum.TryParse<SirenPreset>(dvSiren.SelectedItem?.ToString(), out var sp)) cfg.SirenPreset = sp;
                RefreshVehicleRowSummary(selectedVehicleIndex);
            };
            dvSirenCount.ValueChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) GetOrCreateVehicleCfg(vehicles[selectedVehicleIndex].SpawnName).SirenCount = (int)dvSirenCount.Value; };
            dvAudioPreset.SelectedIndexChanged += (s, e) =>
            {
                if (_loadingDetail || selectedVehicleIndex < 0) return;
                var cfg = GetOrCreateVehicleCfg(vehicles[selectedVehicleIndex].SpawnName);
                if (Enum.TryParse<AudioPreset>(dvAudioPreset.SelectedItem?.ToString(), out var ap)) cfg.AudioPreset = ap;
            };
            dvAudioInherit.TextChanged += (s, e) => { if (!_loadingDetail && selectedVehicleIndex >= 0) GetOrCreateVehicleCfg(vehicles[selectedVehicleIndex].SpawnName).AudioInheritFrom = dvAudioInherit.Text; };

            dvBtnColors.Click += (s, e) =>
            {
                if (selectedVehicleIndex < 0 || selectedVehicleIndex >= vehicles.Count) return;
                var v = vehicles[selectedVehicleIndex];
                using var dlg = new CarVariationsDialog(v.SpawnName, v.ColorVariations);
                if (dlg.ShowDialog(this.FindForm()) == DialogResult.OK)
                    v.ColorVariations = dlg.Result;
            };

            dvBtnEls.Click += (s, e) =>
            {
                if (selectedVehicleIndex < 0 || selectedVehicleIndex >= vehicles.Count) return;
                var v = vehicles[selectedVehicleIndex];

                if (!v.UseEls)
                {
                    MessageBox.Show(
                        "This vehicle is not set to use ELS.\n\n" +
                        "Tick 'Use ELS' first, then click Edit ELS Config… to configure the ELS XML.",
                        "ELS Not Enabled",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (string.IsNullOrWhiteSpace(v.ElsName))
                {
                    MessageBox.Show(
                        "Please fill in the ELS Name field before editing the ELS config.\n\n" +
                        "The ELS Name must match the spawn name ELS uses for this vehicle " +
                        "(usually the same as the Spawn Name).",
                        "ELS Name Required",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!elsConfigs.TryGetValue(v.SpawnName, out var cfg))
                {
                    lightAudioConfigs.TryGetValue(v.SpawnName, out var lac);
                    cfg = ElsConfig.FromSirenPreset(lac?.SirenPreset ?? SirenPreset.None, lac);
                    elsConfigs[v.SpawnName] = cfg;
                }

                using var dlg = new ElsEditorDialog(v.ElsName, cfg);
                if (dlg.ShowDialog(this.FindForm()) == DialogResult.OK)
                    elsConfigs[v.SpawnName] = dlg.Result;
            };

            LoadVehicleDetail(-1);

            tab.Controls.Add(split);
            tab.Controls.Add(hint);
            tab.Controls.Add(elsDisclaimer);
            tab.Controls.Add(toolbar);
        }

        private VehicleLightAudioConfig GetOrCreateVehicleCfg(string spawnName)
        {
            if (!lightAudioConfigs.TryGetValue(spawnName, out var cfg))
            { cfg = new VehicleLightAudioConfig(); lightAudioConfigs[spawnName] = cfg; }
            return cfg;
        }

        private void RefreshVehicleRowSummary(int idx)
        {
            if (idx < 0 || idx >= vehicles.Count || idx >= gridVehicles.Rows.Count) return;
            var v = vehicles[idx];
            lightAudioConfigs.TryGetValue(v.SpawnName, out var cfg);
            cfg ??= new VehicleLightAudioConfig();
            string sirenStatus = v.UseEls
                ? "ELS: " + (string.IsNullOrWhiteSpace(v.ElsName) ? "(unset)" : v.ElsName)
                : (cfg.SirenPreset != SirenPreset.None ? cfg.SirenPreset.ToString() : "—");
            var row = gridVehicles.Rows[idx];
            row.Cells["spawn"].Value = v.SpawnName;
            row.Cells["cat"].Value = v.Category;
            row.Cells["siren"].Value = sirenStatus;
        }

        private static void SetNum(NumericUpDown n, decimal v)
        {
            if (v < n.Minimum) v = n.Minimum;
            if (v > n.Maximum) v = n.Maximum;
            n.Value = v;
        }

        private static void SelectComboText(ComboBox c, string text)
        {
            int i = c.Items.IndexOf(text);
            c.SelectedIndex = i >= 0 ? i : (c.Items.Count > 0 ? 0 : -1);
        }

        private void LoadVehicleDetail(int idx)
        {
            selectedVehicleIndex = idx;
            if (idx < 0 || idx >= vehicles.Count)
            {
                vehicleDetailPanel.Visible = false;
                vehicleEmptyPanel.Visible = true;
                return;
            }

            var v = vehicles[idx];
            lightAudioConfigs.TryGetValue(v.SpawnName, out var cfg);
            cfg ??= new VehicleLightAudioConfig();

            _loadingDetail = true;
            vehicleEmptyPanel.Visible = false;
            vehicleDetailPanel.Visible = true;

            lblVehicleDetailTitle.Text = "🚗  " + (string.IsNullOrWhiteSpace(v.SpawnName) ? "(unnamed vehicle)" : v.SpawnName);
            dvSpawn.Text = v.SpawnName;
            dvGameName.Text = v.GameName;
            dvMake.Text = v.MakeName;
            SelectComboText(dvCategory, v.Category);
            SelectComboText(dvVehicleType, v.VehicleType);
            SelectComboText(dvLayout, v.Layout);
            dvHi.Checked = v.HasHiModel;

            SetNum(dvMass, (decimal)v.Mass);
            SetNum(dvTopSpeed, (decimal)v.TopSpeed);
            SetNum(dvDriveForce, (decimal)v.DriveForce);
            SetNum(dvGears, v.DriveGears);
            SetNum(dvBrakeForce, (decimal)v.BrakeForce);
            SetNum(dvDriveBias, (decimal)v.DriveBias);

            SelectComboText(dvSwankness, v.Swankness);
            SelectComboText(dvPlateType, v.PlateType);
            SetNum(dvNumWheels, v.NumWheels);
            SetNum(dvHp, v.Hp);
            SetNum(dvMaxNum, v.MaxNum);

            dvUseEls.Checked = v.UseEls;
            dvElsName.Text = v.ElsName;
            SelectComboText(dvSiren, cfg.SirenPreset.ToString());
            SetNum(dvSirenCount, cfg.SirenCount);
            SelectComboText(dvAudioPreset, cfg.AudioPreset.ToString());
            dvAudioInherit.Text = cfg.AudioInheritFrom;

            _loadingDetail = false;
        }

        private void BuildPedTab(TabPage tab)
        {
            const int PAD = 8;
            var toolbar = new Panel { Dock = DockStyle.Top, Height = 38, BackColor = Theme.Surface2 };
            btnAddPed = Theme.MakeButton("＋ Add Ped", 100, 26, true);
            btnRemovePed = Theme.MakeButton("✕ Remove", 80);
            btnGeneratePed = Theme.MakeButton("⬇ Save peds.meta", 150);
            btnAddPed.Location = new Point(PAD, 6);
            btnRemovePed.Location = new Point(PAD + 106, 6);
            btnGeneratePed.Location = new Point(PAD + 192, 6);
            btnAddPed.Click += (s, e) =>
            {
                peds.Add(new AddonPedEntry { ModelName = $"ped_{peds.Count + 1}" });
                RefreshPedGrid();
                if (gridPeds.Rows.Count > 0)
                {
                    var row = gridPeds.Rows[gridPeds.Rows.Count - 1];
                    gridPeds.ClearSelection();
                    row.Selected = true;
                    gridPeds.CurrentCell = row.Cells[0];
                }
            };
            btnRemovePed.Click += (s, e) =>
            {
                if (selectedPedIndex < 0 || selectedPedIndex >= peds.Count) return;
                int idx = selectedPedIndex;
                peds.RemoveAt(idx);
                RefreshPedGrid();
                if (peds.Count == 0)
                {
                    LoadPedDetail(-1);
                }
                else
                {
                    int newIdx = Math.Min(idx, peds.Count - 1);
                    gridPeds.ClearSelection();
                    gridPeds.Rows[newIdx].Selected = true;
                    gridPeds.CurrentCell = gridPeds.Rows[newIdx].Cells[0];
                }
            };
            btnGeneratePed.Click += (s, e) => SavePedMeta();
            toolbar.Controls.AddRange(new Control[] { btnAddPed, btnRemovePed, btnGeneratePed });

            var hint = MakeHintLabel("Select a ped on the left to edit its full details on the right. Ped Type controls AI, Movement controls animation set, Personality controls threat response.");

            var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterDistance = 300, BackColor = Theme.Background };

            gridPeds = MakeGrid();
            gridPeds.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Model Name", Name = "model", FillWeight = 45 });
            gridPeds.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ped Type", Name = "pedtype", FillWeight = 35 });
            gridPeds.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Streamed", Name = "stream", FillWeight = 20 });
            gridPeds.ReadOnly = true;
            gridPeds.MultiSelect = false;
            gridPeds.AllowUserToResizeRows = false;
            gridPeds.SelectionChanged += (s, e) =>
            {
                LoadPedDetail(gridPeds.SelectedRows.Count > 0 ? gridPeds.SelectedRows[0].Index : -1);
            };
            split.Panel1.Controls.Add(gridPeds);

            var detailHost = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Theme.Background };

            pedEmptyPanel = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Background };
            pedEmptyPanel.Controls.Add(new Label
            {
                Text = "Select a ped from the list, or click ＋ Add Ped to create one.",
                AutoSize = true,
                Location = new Point(24, 24),
                ForeColor = Theme.Muted,
                Font = new Font("Segoe UI", 9f)
            });

            pedDetailPanel = new Panel { Location = new Point(0, 0), Width = 560, BackColor = Theme.Background };

            lblPedDetailTitle = new Label { Location = new Point(16, 12), AutoSize = true, ForeColor = Theme.Accent, Font = new Font("Segoe UI", 10.5f, FontStyle.Bold) };
            pedDetailPanel.Controls.Add(lblPedDetailTitle);

            int y = 46;
            y = DSection(pedDetailPanel, y, "Identity");
            dpModel = DTxt(); y = DRow(pedDetailPanel, 16, y, "Model Name", dpModel, 220);
            dpPedType = DCbo(PedTables.PedTypes); y = DRow(pedDetailPanel, 16, y, "Ped Type", dpPedType, 260);
            dpPersonality = DCbo(PedTables.Personalities); y = DRow(pedDetailPanel, 16, y, "Personality", dpPersonality, 220);
            dpSpawnSet = DCbo(PedTables.Personalities); y = DRow(pedDetailPanel, 16, y, "Default Spawn Set", dpSpawnSet, 220);
            dpStreamed = DChk("Is Streamed Ped"); dpStreamed.Location = new Point(16, y); pedDetailPanel.Controls.Add(dpStreamed); y += 32;

            y = DSection(pedDetailPanel, y, "Animation");
            dpMovement = DCbo(PedTables.Movements); y = DRow(pedDetailPanel, 16, y, "Movement Clip Set", dpMovement, 260);
            dpClipDict = DTxt(); dpClipDict.PlaceholderText = "move_m@generic"; y = DRow(pedDetailPanel, 16, y, "Clip Dictionary Name", dpClipDict, 220);
            dpStrafeClip = DTxt(); dpStrafeClip.PlaceholderText = "CLIPSET_ID_MOVE_STRAFE_WALK"; y = DRow(pedDetailPanel, 16, y, "Strafe Clip Set", dpStrafeClip, 220);
            dpTerrainState = DCbo(TerrainStateNames); y = DRow(pedDetailPanel, 16, y, "Terrain State", dpTerrainState, 220);

            y = DSection(pedDetailPanel, y, "Voice & Props");
            dpVoiceGroup = DTxt(); dpVoiceGroup.PlaceholderText = "e.g. S_M_Y_COP_01_WHITE_FULL_01"; y = DRow(pedDetailPanel, 16, y, "Voice Group", dpVoiceGroup, 260);
            dpInheritProps = DChk("Inherit props from parent ped"); dpInheritProps.Location = new Point(16, y); pedDetailPanel.Controls.Add(dpInheritProps); y += 32;

            detailHost.Controls.Add(pedDetailPanel);
            detailHost.Controls.Add(pedEmptyPanel);
            split.Panel2.Controls.Add(detailHost);

            dpModel.TextChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) { peds[selectedPedIndex].ModelName = dpModel.Text; lblPedDetailTitle.Text = "🧍  " + (string.IsNullOrWhiteSpace(dpModel.Text) ? "(unnamed ped)" : dpModel.Text); RefreshPedRowSummary(selectedPedIndex); } };
            dpPedType.SelectedIndexChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) { peds[selectedPedIndex].PedType = dpPedType.SelectedItem?.ToString() ?? peds[selectedPedIndex].PedType; RefreshPedRowSummary(selectedPedIndex); } };
            dpPersonality.SelectedIndexChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) peds[selectedPedIndex].Personality = dpPersonality.SelectedItem?.ToString() ?? peds[selectedPedIndex].Personality; };
            dpSpawnSet.SelectedIndexChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) peds[selectedPedIndex].DefaultSpawnSet = dpSpawnSet.SelectedItem?.ToString() ?? peds[selectedPedIndex].DefaultSpawnSet; };
            dpStreamed.CheckedChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) { peds[selectedPedIndex].IsStreamed = dpStreamed.Checked; RefreshPedRowSummary(selectedPedIndex); } };

            dpMovement.SelectedIndexChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) peds[selectedPedIndex].Movement = dpMovement.SelectedItem?.ToString() ?? peds[selectedPedIndex].Movement; };
            dpClipDict.TextChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) peds[selectedPedIndex].ClipDictionaryName = dpClipDict.Text; };
            dpStrafeClip.TextChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) peds[selectedPedIndex].StrafeClipSet = dpStrafeClip.Text; };
            dpTerrainState.SelectedIndexChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) peds[selectedPedIndex].TerrainStateName = dpTerrainState.SelectedItem?.ToString() ?? peds[selectedPedIndex].TerrainStateName; };

            dpVoiceGroup.TextChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) peds[selectedPedIndex].VoiceGroup = dpVoiceGroup.Text; };
            dpInheritProps.CheckedChanged += (s, e) => { if (!_loadingDetail && selectedPedIndex >= 0) peds[selectedPedIndex].InheritPropsFromParent = dpInheritProps.Checked; };

            LoadPedDetail(-1);

            tab.Controls.Add(split);
            tab.Controls.Add(hint);
            tab.Controls.Add(toolbar);
        }

        private void RefreshPedRowSummary(int idx)
        {
            if (idx < 0 || idx >= peds.Count || idx >= gridPeds.Rows.Count) return;
            var p = peds[idx];
            var row = gridPeds.Rows[idx];
            row.Cells["model"].Value = p.ModelName;
            row.Cells["pedtype"].Value = p.PedType;
            row.Cells["stream"].Value = p.IsStreamed ? "✓" : "—";
        }

        private void LoadPedDetail(int idx)
        {
            selectedPedIndex = idx;
            if (idx < 0 || idx >= peds.Count)
            {
                pedDetailPanel.Visible = false;
                pedEmptyPanel.Visible = true;
                return;
            }

            var p = peds[idx];
            _loadingDetail = true;
            pedEmptyPanel.Visible = false;
            pedDetailPanel.Visible = true;

            lblPedDetailTitle.Text = "🧍  " + (string.IsNullOrWhiteSpace(p.ModelName) ? "(unnamed ped)" : p.ModelName);
            dpModel.Text = p.ModelName;
            SelectComboText(dpPedType, p.PedType);
            SelectComboText(dpPersonality, p.Personality);
            SelectComboText(dpSpawnSet, p.DefaultSpawnSet);
            dpStreamed.Checked = p.IsStreamed;

            SelectComboText(dpMovement, p.Movement);
            dpClipDict.Text = p.ClipDictionaryName;
            dpStrafeClip.Text = p.StrafeClipSet;
            SelectComboText(dpTerrainState, p.TerrainStateName);

            dpVoiceGroup.Text = p.VoiceGroup;
            dpInheritProps.Checked = p.InheritPropsFromParent;

            _loadingDetail = false;
        }

        // ── Small helpers for building the vehicle/ped detail panels ───────────
        private Label DLbl(string t) => new Label { Text = t, AutoSize = true, ForeColor = Theme.TextDim, Font = new Font("Segoe UI", 8.3f) };
        private TextBox DTxt() => new TextBox { BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 9f) };
        private ComboBox DCbo(string[] items)
        {
            var c = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Theme.Background, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) };
            c.Items.AddRange(items);
            return c;
        }
        private NumericUpDown DNum(decimal min, decimal max, decimal inc, int decimals) => new NumericUpDown
        {
            Minimum = min,
            Maximum = max,
            Increment = inc,
            DecimalPlaces = decimals,
            BackColor = Theme.Background,
            ForeColor = Theme.Text,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("Consolas", 9f)
        };
        private CheckBox DChk(string text) => new CheckBox { Text = text, AutoSize = true, ForeColor = Theme.Text, Font = new Font("Segoe UI", 8.5f) };

        /// <summary>Places a label above a control at (x, y) and returns the y for the next row.</summary>
        private int DRow(Panel host, int x, int y, string label, Control ctl, int ctlWidth)
        {
            var lbl = DLbl(label);
            lbl.Location = new Point(x, y);
            host.Controls.Add(lbl);
            ctl.Location = new Point(x, y + 18);
            ctl.Width = ctlWidth;
            host.Controls.Add(ctl);
            return y + 50;
        }

        /// <summary>Adds a full-width section header bar and returns the y for the first row beneath it.</summary>
        private int DSection(Panel host, int y, string text)
        {
            var bar = new Label
            {
                Text = text,
                AutoSize = false,
                Height = 24,
                Width = 528,
                Location = new Point(0, y),
                ForeColor = Theme.Accent,
                BackColor = Theme.Surface2,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(12, 0, 0, 0),
            };
            host.Controls.Add(bar);
            return y + 34;
        }

        private void BuildPreviewTab(TabPage tab)
        {
            var toolbar = new Panel { Dock = DockStyle.Top, Height = 38, BackColor = Theme.Surface2, Padding = new Padding(8, 6, 8, 6) };
            var cboFile = new ComboBox { Location = new Point(8, 6), Width = 240, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Theme.Background, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) };
            cboFile.Items.AddRange(new object[] {
    "vehicles.meta", "handling.meta", "carvariations.meta",
    "carcols.meta", "vehiclesstreamingdata.meta",
    "peds.meta", "content.xml", "setup2.xml",
    "els_<first vehicle>.xml"   // NEW
});
            cboFile.SelectedIndex = 0;
            var btnRefresh = Theme.MakeButton("🔄 Refresh", 100); btnRefresh.Location = new Point(252, 6);
            var txtPreview = new TextBox { Dock = DockStyle.Fill, Multiline = true, ScrollBars = ScrollBars.Both, ReadOnly = true, WordWrap = false, BackColor = Theme.ListBg, ForeColor = Theme.TextDim, BorderStyle = BorderStyle.None, Font = new Font("Consolas", 8.5f) };

            void Refresh() => RefreshPreview(cboFile.SelectedItem?.ToString() ?? "", txtPreview);
            btnRefresh.Click += (s, e) => Refresh();
            cboFile.SelectedIndexChanged += (s, e) => Refresh();

            toolbar.Controls.AddRange(new Control[] { cboFile, btnRefresh });
            tab.Controls.Add(txtPreview); tab.Controls.Add(toolbar);
        }

        private void RefreshPreview(string file, TextBox txt)
        {
            ReadGridVehicles(); ReadGridPeds();
            var dlcName = txtDlcName.Text.Trim();
            if (string.IsNullOrEmpty(dlcName)) dlcName = "my_addon";
            try
            {
                switch (file)
                {
                    case "vehicles.meta": txt.Text = AddonGeneratorEx.BuildVehiclesMetaWithSirens(vehicles, lightAudioConfigs); break;
                    case "handling.meta": txt.Text = AddonGenerator.BuildHandlingMeta(vehicles); break;
                    case "carvariations.meta": txt.Text = AddonGenerator.BuildCarVariationsMeta(vehicles); break;
                    case "carcols.meta": txt.Text = AddonGenerator2.BuildCarcolsMeta(vehicles, lightAudioConfigs); break;
                    case "els_<first vehicle>.xml":
                        var firstV = vehicles.FirstOrDefault();
                        if (firstV == null) { txt.Text = "// No vehicles defined."; break; }
                        elsConfigs.TryGetValue(firstV.SpawnName, out var previewEls);
                        if (previewEls == null)
                        {
                            lightAudioConfigs.TryGetValue(firstV.SpawnName, out var lac);
                            previewEls = ElsConfig.FromSirenPreset(lac?.SirenPreset ?? SirenPreset.None, lac);
                        }
                        txt.Text = ElsGenerator.BuildElsXml(firstV.SpawnName, previewEls);
                        break;
                    case "vehiclesstreamingdata.meta":
                        // Build inline preview
                        var sb = new StringBuilder();
                        sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                        sb.AppendLine("<CVehicleStreamingDataMgr__InitDataList><InitDatas>");
                        foreach (var v in vehicles)
                        {
                            lightAudioConfigs.TryGetValue(v.SpawnName, out var cfg); cfg ??= new VehicleLightAudioConfig();
                            string bank = cfg.AudioPreset == AudioPreset.Inherit ? (cfg.AudioInheritFrom ?? v.SpawnName) : v.SpawnName;
                            sb.AppendLine($"  <Item><modelName>{v.SpawnName}</modelName><audioNameHash>{bank}</audioNameHash></Item>");
                        }
                        sb.AppendLine("</InitDatas></CVehicleStreamingDataMgr__InitDataList>");
                        txt.Text = sb.ToString(); break;
                    case "peds.meta": txt.Text = AddonGenerator.BuildPedsMeta(peds, dlcName); break;
                    case "content.xml": txt.Text = AddonGenerator.BuildContentXml(dlcName, vehicles, peds); break;
                    case "setup2.xml": txt.Text = AddonGenerator.BuildSetup2Xml(dlcName); break;
                }
            }
            catch (Exception ex) { txt.Text = $"Error: {ex.Message}"; }
        }

        private DataGridView MakeGrid()
        {
            var g = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Theme.ListBg,
                ForeColor = Theme.Text,
                GridColor = Theme.Border,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Font = new Font("Consolas", 8.5f),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            };
            g.DefaultCellStyle.BackColor = Theme.ListBg;
            g.DefaultCellStyle.ForeColor = Theme.Text;
            g.DefaultCellStyle.SelectionBackColor = Theme.AccentDim;
            g.DefaultCellStyle.SelectionForeColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.BackColor = Theme.Surface2;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Theme.TextDim;
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            g.EnableHeadersVisualStyles = false;
            return g;
        }

        private Label MakeHintLabel(string text) => new Label
        {
            Text = "ℹ  " + text,
            Dock = DockStyle.Bottom,
            Height = 28,
            ForeColor = Theme.Muted,
            Font = new Font("Segoe UI", 8f),
            Padding = new Padding(8, 4, 8, 0),
            BackColor = Theme.Surface,
        };

        private void RefreshVehicleGrid()
        {
            gridVehicles.Rows.Clear();
            foreach (var v in vehicles)
            {
                lightAudioConfigs.TryGetValue(v.SpawnName, out var cfg);
                cfg ??= new VehicleLightAudioConfig();
                string sirenStatus = v.UseEls
                    ? "ELS: " + (string.IsNullOrWhiteSpace(v.ElsName) ? "(unset)" : v.ElsName)
                    : (cfg.SirenPreset != SirenPreset.None ? cfg.SirenPreset.ToString() : "—");
                gridVehicles.Rows.Add(v.SpawnName, v.Category, sirenStatus);
            }
        }

        private void RefreshPedGrid()
        {
            gridPeds.Rows.Clear();
            foreach (var p in peds) gridPeds.Rows.Add(p.ModelName, p.PedType, p.IsStreamed ? "✓" : "—");
        }

        // ── The detail panels commit changes live as the user edits them, so no
        //    separate "read grid back into model" pass is needed before saving. ──
        private void ReadGridVehicles() { }

        private void ReadGridPeds() { }

        private bool ValidateElsNames()
        {
            var missing = vehicles
                .Where(v => v.UseEls
                            && string.IsNullOrWhiteSpace(v.ElsName))
                .Select(v => v.SpawnName)
                .ToList();

            if (missing.Count == 0) return true;

            MessageBox.Show(
                "The following vehicles have 'Use ELS' ticked but no ELS Name filled in:\n\n" +
                string.Join("\n", missing.Select(n => $"  • {n}")) +
                "\n\nPlease fill in the ELS Name field (usually the same as the Spawn Name) " +
                "before generating.",
                "ELS Name Required",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        private string ValidateDlcName()
        {
            var name = txtDlcName.Text.Trim().ToLowerInvariant().Replace(" ", "_");
            if (string.IsNullOrEmpty(name)) { MessageBox.Show("Enter a DLC name first.", "Missing DLC Name", MessageBoxButtons.OK, MessageBoxIcon.Warning); return null; }
            return name;
        }

        private string ValidateOutputDir()
        {
            var dir = txtOutputDir.Text.Trim();
            if (string.IsNullOrEmpty(dir)) { MessageBox.Show("Choose an output folder first.", "Missing Output Folder", MessageBoxButtons.OK, MessageBoxIcon.Warning); return null; }
            return dir;
        }

        private void SaveIndividualFiles()
        {
            ReadGridVehicles();
            if (vehicles.Count == 0) { MessageBox.Show("No vehicles defined.", "Nothing to Generate", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            var dlcName = ValidateDlcName(); if (dlcName == null) return;
            var outDir = ValidateOutputDir(); if (outDir == null) return;
            var dataDir = Path.Combine(outDir, dlcName, "dlc.rpf", "data");
            Directory.CreateDirectory(dataDir);
            File.WriteAllText(Path.Combine(dataDir, "vehicles.meta"), AddonGeneratorEx.BuildVehiclesMetaWithSirens(vehicles, lightAudioConfigs), Encoding.UTF8);
            File.WriteAllText(Path.Combine(dataDir, "handling.meta"), AddonGenerator.BuildHandlingMeta(vehicles), Encoding.UTF8);
            File.WriteAllText(Path.Combine(dataDir, "carvariations.meta"), AddonGenerator.BuildCarVariationsMeta(vehicles), Encoding.UTF8);
            File.WriteAllText(Path.Combine(dataDir, "carcols.meta"), AddonGenerator2.BuildCarcolsMeta(vehicles, lightAudioConfigs), Encoding.UTF8);
            MessageBox.Show($"Saved to:\n{dataDir}", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            try { System.Diagnostics.Process.Start("explorer.exe", $"\"{dataDir}\""); } catch { }
        }

        private void SavePedMeta()
        {
            ReadGridPeds();
            if (peds.Count == 0) { MessageBox.Show("No peds defined.", "Nothing to Generate", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            var dlcName = ValidateDlcName(); if (dlcName == null) return;
            var outDir = ValidateOutputDir(); if (outDir == null) return;
            var dataDir = Path.Combine(outDir, dlcName, "dlc.rpf", "data");
            Directory.CreateDirectory(dataDir);
            File.WriteAllText(Path.Combine(dataDir, "peds.meta"), AddonGenerator.BuildPedsMeta(peds, dlcName), Encoding.UTF8);
            MessageBox.Show($"Saved to:\n{dataDir}", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            try { System.Diagnostics.Process.Start("explorer.exe", $"\"{dataDir}\""); } catch { }
        }

        private string PickGtaDirectory()
        {
            using var dlg = new FolderBrowserDialog { Description = "Select your GTA V main game directory (containing GTA5.exe)", ShowNewFolderButton = false };
            string[] commonPaths = {
                @"C:\Program Files\Rockstar Games\Grand Theft Auto V",
                @"C:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto V",
                @"C:\Program Files\Steam\steamapps\common\Grand Theft Auto V",
                @"D:\SteamLibrary\steamapps\common\Grand Theft Auto V",
                @"D:\Games\Grand Theft Auto V",
            };
            foreach (var p in commonPaths) if (Directory.Exists(p)) { dlg.SelectedPath = p; break; }
            if (dlg.ShowDialog(this.FindForm()) != DialogResult.OK) return null;
            if (!File.Exists(Path.Combine(dlg.SelectedPath, "GTA5.exe")))
            {
                if (MessageBox.Show("GTA5.exe not found. Continue anyway?", "Directory Validation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No) return null;
            }
            string modsPath = Path.Combine(dlg.SelectedPath, "mods");
            if (!Directory.Exists(modsPath))
            {
                if (MessageBox.Show("No 'mods' folder found. Create it?", "Mods Folder Missing", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    Directory.CreateDirectory(modsPath);
                else return null;
            }
            return dlg.SelectedPath;
        }

        private void BtnGenerateAll_Click(object sender, EventArgs e)
        {
            ReadGridVehicles(); ReadGridPeds();
            if (vehicles.Count == 0 && peds.Count == 0)
            {
                MessageBox.Show("Add at least one vehicle or ped first.",
                    "Nothing to Generate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var dlcName = ValidateDlcName(); if (dlcName == null) return;

            // ── Ask for GTA V directory (remembers between sessions) ──────────
            string gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;   // user cancelled

            // ── Show progress dialog and run on background thread ────────────
            var writeDialog = new RpfWriteDialog();
            // Only pass ELS configs for vehicles that have UseEls ticked
            var activeElsConfigs = elsConfigs
                .Where(kv => vehicles.Any(v => v.SpawnName == kv.Key && v.UseEls))
                .ToDictionary(kv => kv.Key, kv => kv.Value);

            writeDialog.Show(this.FindForm());

            System.Threading.Tasks.Task.Run(() =>
            {
                var result = RpfPackager.PackageVehicleAddon(
                    gtaRoot: gtaRoot,
                    dlcName: dlcName,
                    vehicles: vehicles,
                    peds: peds,
                    lightAudioConfigs: lightAudioConfigs,
                    elsConfigs: activeElsConfigs,
                    sourceModelFilesDir: "",          // no model files from this panel
                    progress: msg => writeDialog.AppendLog(msg));

                writeDialog.Finish(result);

                if (result.Success)
                {
                    this.Invoke((Action)(() =>
                    {
                        lblStatus.Text = $"✔ dlc.rpf written — {result.RpfPath}";
                        lblStatus.ForeColor = Theme.Success;

                        bool hasSirens = vehicles.Exists(v =>
                            lightAudioConfigs.TryGetValue(v.SpawnName, out var c) &&
                            c.SirenPreset != SirenPreset.None);
                        bool hasEls = activeElsConfigs.Count > 0;

                        string audioNote = hasSirens
                            ? "\n\nSirens detected — audiovehicles_OPENFORMATS.xml is in\n" +
                              "data/audio/sfx/. See AUDIO_README.txt for CodeWalker steps."
                            : "";
                        string elsNote = hasEls
                            ? $"\n\nELS files written to dlc.rpf/ELS/ and also to\n" +
                              $"ELS_copy_to_pack_default/ beside the RPF.\n" +
                              $"Copy els_*.xml → <GTA V>\\ELS\\pack_default\\"
                            : "";

                        MessageBox.Show(
                            $"✨ dlc.rpf written to:\n{result.RpfPath}\n\n" +
                            $"dlclist.xml: {result.DlcEntry}\n" +
                            $"(The tool attempted to patch dlclist.xml automatically.)" +
                            $"{audioNote}{elsNote}\n\nSee HOW_TO_INSTALL.txt for any manual steps.",
                            "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        try
                        {
                            System.Diagnostics.Process.Start("explorer.exe",
                                $"\"{System.IO.Path.GetDirectoryName(result.RpfPath)}\"");
                        }
                        catch { }
                    }));
                }
            });
        }
    }

    // =========================================================================
    //  CarVariationsDialog
    // =========================================================================

    internal class CarVariationsDialog : Form
    {
        public List<ColorVariation> Result { get; private set; }
        private DataGridView grid;

        public CarVariationsDialog(string spawnName, List<ColorVariation> existing)
        {
            this.Text = $"Color Variations — {spawnName}"; this.Size = new Size(560, 420); this.MinimumSize = new Size(420, 300);
            this.StartPosition = FormStartPosition.CenterParent; this.FormBorderStyle = FormBorderStyle.Sizable;
            this.BackColor = Theme.Surface; this.ForeColor = Theme.Text;
            var hint = Theme.MakeLabel("Each row = one color variation. Values are GTA colour indices (0–160+).", muted: true);
            hint.Location = new Point(12, 10); hint.MaximumSize = new Size(520, 40);
            grid = new DataGridView { Location = new Point(12, 52), BackgroundColor = Theme.ListBg, ForeColor = Theme.Text, GridColor = Theme.Border, BorderStyle = BorderStyle.None, AllowUserToAddRows = true, AllowUserToDeleteRows = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, Font = new Font("Consolas", 8.5f), AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
            grid.DefaultCellStyle.BackColor = Theme.ListBg; grid.DefaultCellStyle.ForeColor = Theme.Text; grid.DefaultCellStyle.SelectionBackColor = Theme.Accent;
            grid.ColumnHeadersDefaultCellStyle.BackColor = Theme.Surface2; grid.ColumnHeadersDefaultCellStyle.ForeColor = Theme.Muted; grid.EnableHeadersVisualStyles = false;
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Primary", Name = "primary", FillWeight = 25 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Secondary", Name = "secondary", FillWeight = 25 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Pearl", Name = "pearl", FillWeight = 25 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Wheel", Name = "wheel", FillWeight = 25 });
            foreach (var cv in existing) grid.Rows.Add(cv.Primary, cv.Secondary, cv.Pearl, cv.Wheel);
            var btnOk = Theme.MakeButton("OK", 80, 28, true); btnOk.DialogResult = DialogResult.OK; btnOk.Click += (s, e) => Commit();
            var btnCancel = Theme.MakeButton("Cancel", 80, 28); btnCancel.DialogResult = DialogResult.Cancel;
            var btnAdd = Theme.MakeButton("+ Row", 80, 28); btnAdd.Click += (s, e) => grid.Rows.Add(0, 0, 0, 0);
            var btnPanel = new FlowLayoutPanel { Dock = DockStyle.Bottom, FlowDirection = FlowDirection.RightToLeft, Height = 44, BackColor = Theme.Surface, Padding = new Padding(8, 6, 8, 6) };
            btnPanel.Controls.AddRange(new Control[] { btnCancel, btnOk, btnAdd });
            this.Controls.AddRange(new Control[] { hint, grid, btnPanel });
            this.AcceptButton = btnOk; this.CancelButton = btnCancel;
            this.Resize += (s, e) => { grid.Size = new Size(this.ClientSize.Width - 24, Math.Max(60, this.ClientSize.Height - 44 - 64)); };
        }

        private void Commit()
        {
            Result = new List<ColorVariation>();
            foreach (DataGridViewRow row in grid.Rows)
            {
                if (row.IsNewRow) continue;
                int.TryParse(row.Cells["primary"].Value?.ToString(), out int p);
                int.TryParse(row.Cells["secondary"].Value?.ToString(), out int s);
                int.TryParse(row.Cells["pearl"].Value?.ToString(), out int pe);
                int.TryParse(row.Cells["wheel"].Value?.ToString(), out int w);
                Result.Add(new ColorVariation { Primary = p, Secondary = s, Pearl = pe, Wheel = w });
            }
        }
    }

    // =========================================================================
    //  VehicleDlcDialog
    // =========================================================================

    internal class VehicleDlcDialog : Form
    {
        public VehicleDlcBuildSettings Settings { get; private set; }
        private TextBox txtDlcName, txtOutputDir;
        private DataGridView grid;
        private CheckBox chkEls;
        private ComboBox cboSiren;
        private NumericUpDown numSirenCount;
        private CheckBox chkRegenCarcols;

        public VehicleDlcDialog(string convertedDir, string suggestedDlcName, List<VehicleEntry> vehicles, List<string> metaFiles)
        {
            this.Text = "Build SP Vehicle Addon DLC — Confirm"; this.Size = new Size(780, 630); this.MinimumSize = new Size(640, 520);
            this.StartPosition = FormStartPosition.CenterParent; this.FormBorderStyle = FormBorderStyle.Sizable;
            this.BackColor = Theme.Surface; this.ForeColor = Theme.Text;
            int y = 14;
            void AddLbl(string t) { var l = Theme.MakeLabel(t, true); l.Location = new Point(14, y); this.Controls.Add(l); }
            AddLbl("DLC name (no spaces, lowercase):"); y += 18;
            txtDlcName = Theme.MakeTextBox(suggestedDlcName, 220); txtDlcName.Text = suggestedDlcName; txtDlcName.Location = new Point(14, y); this.Controls.Add(txtDlcName); y += 30;
            AddLbl("Output root folder:"); y += 18;
            txtOutputDir = Theme.MakeTextBox("", 560); txtOutputDir.Text = Path.GetDirectoryName(convertedDir) ?? convertedDir; txtOutputDir.Location = new Point(14, y); this.Controls.Add(txtOutputDir);
            var btnB = Theme.MakeButton("…", 36); btnB.Location = new Point(580, y - 1); this.Controls.Add(btnB);
            btnB.Click += (s, e) => { using var d = new FolderBrowserDialog(); if (d.ShowDialog() == DialogResult.OK) txtOutputDir.Text = d.SelectedPath; }; y += 32;

            // ── Siren / light preset — without this, carcols.meta and
            //    vehicles.meta have no siren data at all, so no lights or
            //    sirens get generated regardless of the ELS option below. ──
            AddLbl("Siren / light preset (used for carcols.meta + vehicles.meta, and ELS if enabled):"); y += 18;
            cboSiren = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Location = new Point(14, y), Width = 200 };
            cboSiren.Items.AddRange(Enum.GetNames(typeof(SirenPreset)));
            cboSiren.SelectedIndex = (int)SirenPreset.PoliceLSPD;
            this.Controls.Add(cboSiren);
            var lblCount = Theme.MakeLabel("Siren lights (count):", true); lblCount.Location = new Point(228, y + 3); this.Controls.Add(lblCount);
            numSirenCount = new NumericUpDown { Location = new Point(360, y - 1), Width = 50, Minimum = 1, Maximum = 8, Value = 2 };
            this.Controls.Add(numSirenCount); y += 30;

            // ── Force-regenerate carcols.meta — most FiveM vehicle packs
            //    already ship their own carcols.meta, which the build silently
            //    copies through untouched (the auto-generate path only runs
            //    when carcols.meta is *missing*), so the preset picked above
            //    would otherwise never reach the file. Checking this gives
            //    you working native GTA siren lights regardless of what the
            //    source carcols.meta did or didn't define — and unlike ELS,
            //    it doesn't depend on the model's "extra" object layout. ──
            chkRegenCarcols = new CheckBox
            {
                Text = "Regenerate carcols.meta with the preset above (recommended — overwrites source carcols.meta)",
                AutoSize = true,
                ForeColor = Theme.Text,
                Location = new Point(14, y),
                Checked = true
            };
            this.Controls.Add(chkRegenCarcols); y += 24;
            var lblCarcolsHint = new Label
            {
                Text = "Gives working native siren lights even if the source carcols.meta had none. handling.meta and vehicles.meta\n" +
                       "are left untouched either way, since they carry model-specific data this tool can't reproduce.",
                AutoSize = true,
                ForeColor = Theme.Muted,
                Font = new Font("Segoe UI", 8.25f),
                Location = new Point(32, y)
            };
            this.Controls.Add(lblCarcolsHint); y += 36;

            // ── ELS option — only ever shown here, i.e. only when the tool
            //    has actually detected a vehicle resource. ──────────────────
            chkEls = new CheckBox
            {
                Text = "This vehicle uses ELS (Emergency Lighting System)",
                AutoSize = true,
                ForeColor = Theme.Text,
                Location = new Point(14, y),
                Checked = false
            };
            this.Controls.Add(chkEls); y += 24;
            var lblElsHint = new Label
            {
                Text = "ELS uses a generic 12-light template that may not match this model's \"extra\" objects — if lights still don't\n" +
                       "show in-game after enabling, the native carcols lights above are the more reliable fallback.",
                AutoSize = true,
                ForeColor = Theme.Muted,
                Font = new Font("Segoe UI", 8.25f),
                Location = new Point(32, y)
            };
            this.Controls.Add(lblElsHint); y += 36;

            if (metaFiles.Count > 0) { AddLbl($"Meta files: {string.Join("  ", metaFiles)}"); y += 22; }
            AddLbl($"Detected vehicles ({vehicles.Count}):"); y += 18;
            grid = MakeGrid(); grid.Location = new Point(14, y);
            foreach (var v in vehicles) grid.Rows.Add(v.SpawnName, v.HasHiModel ? "✔" : "—", string.Join(", ", v.YtdNames));
            this.Controls.Add(grid);
            var btnOk = Theme.MakeButton("▶  Build Vehicle DLC Folder", 180, 28, true); btnOk.DialogResult = DialogResult.OK; btnOk.Click += (s, e) => Commit(vehicles, metaFiles);
            var btnCancel = Theme.MakeButton("Cancel", 80, 28); btnCancel.DialogResult = DialogResult.Cancel;
            var btnPanel = new FlowLayoutPanel { Dock = DockStyle.Bottom, FlowDirection = FlowDirection.RightToLeft, Height = 44, BackColor = Theme.Surface, Padding = new Padding(8, 6, 8, 6) };
            btnPanel.Controls.AddRange(new Control[] { btnCancel, btnOk }); this.Controls.Add(btnPanel);
            this.AcceptButton = btnOk; this.CancelButton = btnCancel;
            this.Resize += (s, e) => { int bh = 44, bot = this.ClientSize.Height - bh - 12; grid.Size = new Size(this.ClientSize.Width - 28, Math.Max(80, bot - grid.Top)); };
        }

        private DataGridView MakeGrid()
        {
            var g = new DataGridView { BackgroundColor = Theme.Background, ForeColor = Theme.Text, GridColor = Theme.Border, BorderStyle = BorderStyle.None, RowHeadersVisible = false, AllowUserToAddRows = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, Font = new Font("Consolas", 8.5f), AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
            g.DefaultCellStyle.BackColor = Theme.Background; g.DefaultCellStyle.ForeColor = Theme.Text; g.DefaultCellStyle.SelectionBackColor = Theme.Accent;
            g.ColumnHeadersDefaultCellStyle.BackColor = Theme.Surface2; g.ColumnHeadersDefaultCellStyle.ForeColor = Theme.Muted; g.EnableHeadersVisualStyles = false;
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Spawn Name", Name = "spawn", FillWeight = 25 });
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Hi Model", Name = "hi", FillWeight = 10, ReadOnly = true });
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Textures", Name = "ytds", FillWeight = 65, ReadOnly = true });
            return g;
        }

        private void Commit(List<VehicleEntry> originals, List<string> metaFiles)
        {
            var list = new List<VehicleEntry>();
            for (int i = 0; i < grid.Rows.Count; i++)
            {
                var row = grid.Rows[i]; if (row.IsNewRow) continue;
                var orig = i < originals.Count ? originals[i] : null;
                list.Add(new VehicleEntry { SpawnName = row.Cells["spawn"].Value?.ToString()?.Trim() ?? (orig?.SpawnName ?? ""), HasHiModel = orig?.HasHiModel ?? false, YtdNames = orig?.YtdNames ?? new List<string>() });
            }
            Settings = new VehicleDlcBuildSettings
            {
                DlcName = txtDlcName.Text.Trim().ToLowerInvariant().Replace(" ", "_"),
                OutputRoot = txtOutputDir.Text.Trim(),
                Vehicles = list,
                MetaFiles = metaFiles,
                IsElsVehicle = chkEls.Checked,
                RegenerateCarcols = chkRegenCarcols.Checked,
                LightAudioConfig = new VehicleLightAudioConfig
                {
                    SirenPreset = (SirenPreset)cboSiren.SelectedIndex,
                    SirenCount = (int)numSirenCount.Value
                }
            };
        }
    }

    // =========================================================================
    //  DlcMetaDialog (clothing)
    // =========================================================================

    internal class DlcMetaDialog : Form
    {
        public DlcBuildSettings Settings { get; private set; }
        private TextBox txtPedName, txtDlcName, txtOutputDir;
        private DataGridView grid;

        public DlcMetaDialog(string convertedDir, string detectedPed, string suggestedDlcName, List<DlcDrawable> drawables)
        {
            this.Text = "Build SP Addon DLC — Confirm"; this.Size = new Size(780, 560); this.MinimumSize = new Size(640, 480);
            this.StartPosition = FormStartPosition.CenterParent; this.FormBorderStyle = FormBorderStyle.Sizable;
            this.BackColor = Theme.Surface; this.ForeColor = Theme.Text;
            int y = 14;
            void AddLbl(string t) { var l = Theme.MakeLabel(t, true); l.Location = new Point(14, y); this.Controls.Add(l); }
            AddLbl("Ped name (e.g. mp_f_freemode_01):"); y += 18;
            txtPedName = Theme.MakeTextBox("", 220); txtPedName.Text = detectedPed; txtPedName.Location = new Point(14, y); this.Controls.Add(txtPedName); y += 30;
            AddLbl("DLC name:"); y += 18;
            txtDlcName = Theme.MakeTextBox("", 220); txtDlcName.Text = suggestedDlcName; txtDlcName.Location = new Point(14, y); this.Controls.Add(txtDlcName); y += 30;
            AddLbl("Output root folder:"); y += 18;
            txtOutputDir = Theme.MakeTextBox("", 560); txtOutputDir.Text = Path.GetDirectoryName(convertedDir) ?? convertedDir; txtOutputDir.Location = new Point(14, y); this.Controls.Add(txtOutputDir);
            var btnB = Theme.MakeButton("…", 36); btnB.Location = new Point(580, y - 1); this.Controls.Add(btnB);
            btnB.Click += (s, e) => { using var d = new FolderBrowserDialog(); if (d.ShowDialog() == DialogResult.OK) txtOutputDir.Text = d.SelectedPath; }; y += 32;
            AddLbl($"Detected drawables ({drawables.Count}):"); y += 18;
            grid = new DataGridView { Location = new Point(14, y), BackgroundColor = Theme.Background, ForeColor = Theme.Text, GridColor = Theme.Border, BorderStyle = BorderStyle.None, RowHeadersVisible = false, AllowUserToAddRows = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, Font = new Font("Consolas", 8.5f), AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
            grid.DefaultCellStyle.BackColor = Theme.Background; grid.DefaultCellStyle.ForeColor = Theme.Text; grid.DefaultCellStyle.SelectionBackColor = Theme.Accent;
            grid.ColumnHeadersDefaultCellStyle.BackColor = Theme.Surface2; grid.ColumnHeadersDefaultCellStyle.ForeColor = Theme.Muted; grid.EnableHeadersVisualStyles = false;
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Slot", Name = "slot", ReadOnly = true, FillWeight = 10 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "YDD Name", Name = "ydd", ReadOnly = true, FillWeight = 30 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Drawable Index", Name = "idx", FillWeight = 12 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Texture Count", Name = "texcnt", FillWeight = 12 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "YTDs", Name = "ytds", ReadOnly = true, FillWeight = 36 });
            foreach (var d in drawables) grid.Rows.Add(d.SlotRoot, d.YddName, d.DrawableIndex.ToString(), d.YtdNames.Count.ToString(), string.Join(", ", d.YtdNames));
            this.Controls.Add(grid);
            var btnOk = Theme.MakeButton("▶  Build DLC Folder", 140, 28, true); btnOk.DialogResult = DialogResult.OK; btnOk.Click += BtnOk_Click;
            var btnCancel = Theme.MakeButton("Cancel", 80, 28); btnCancel.DialogResult = DialogResult.Cancel;
            var btnPanel = new FlowLayoutPanel { Dock = DockStyle.Bottom, FlowDirection = FlowDirection.RightToLeft, Height = 44, BackColor = Theme.Surface, Padding = new Padding(8, 6, 8, 6) };
            btnPanel.Controls.AddRange(new Control[] { btnCancel, btnOk }); this.Controls.Add(btnPanel);
            this.AcceptButton = btnOk; this.CancelButton = btnCancel;
            this.Resize += (s, e) => { int bh = 44, bot = this.ClientSize.Height - bh - 12; grid.Size = new Size(this.ClientSize.Width - 28, Math.Max(80, bot - grid.Top)); };
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            var drawables = new List<DlcDrawable>();
            foreach (DataGridViewRow row in grid.Rows)
            {
                if (row.IsNewRow) continue;
                int.TryParse(row.Cells["idx"].Value?.ToString(), out int idx);
                int.TryParse(row.Cells["texcnt"].Value?.ToString(), out int texCnt);
                var ytdRaw = row.Cells["ytds"].Value?.ToString() ?? "";
                var ytdList = ytdRaw.Split(new[] { ", " }, StringSplitOptions.RemoveEmptyEntries).ToList();
                if (texCnt < ytdList.Count) ytdList = ytdList.Take(texCnt).ToList();
                drawables.Add(new DlcDrawable { SlotRoot = row.Cells["slot"].Value?.ToString() ?? "", DrawableIndex = idx, YddName = row.Cells["ydd"].Value?.ToString() ?? "", YtdNames = ytdList });
            }
            Settings = new DlcBuildSettings { PedName = txtPedName.Text.Trim(), DlcName = txtDlcName.Text.Trim().ToLowerInvariant().Replace(" ", "_"), OutputRoot = txtOutputDir.Text.Trim(), Drawables = drawables };
        }
    }

    // =========================================================================
    //  FiveMConvertDialog
    // =========================================================================

    internal class FiveMConvertDialog : Form
    {
        public bool ApplyForAll => chkAll.Checked;
        public string ChosenSPToFiveMPrefix => cboPrefix.Enabled ? cboPrefix.Text.Trim() : null;
        private CheckBox chkAll;
        private ComboBox cboPrefix;

        public FiveMConvertDialog(string filename, string spExample, string detectedPrefix, int remainingCount)
        {
            this.Text = "FiveM Name Detected"; this.Size = new Size(520, 230);
            this.StartPosition = FormStartPosition.CenterParent; this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false; this.MinimizeBox = false;
            this.BackColor = Theme.Surface; this.ForeColor = Theme.Text;
            var lbl = new Label { Text = $"File: {filename}\nPrefix: {detectedPrefix ?? "None"}\nSP result: {spExample}", Location = new Point(15, 15), Size = new Size(480, 52), ForeColor = Theme.Text };
            var lblCbo = Theme.MakeLabel("Reverse (SP → FiveM) prefix:", muted: true); lblCbo.Location = new Point(15, 73);
            cboPrefix = new ComboBox { Location = new Point(15, 91), Width = 220, BackColor = Theme.Background, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat };
            cboPrefix.Items.AddRange(FormatConverter.KnownPrefixes);
            if (!string.IsNullOrEmpty(detectedPrefix)) cboPrefix.Text = detectedPrefix;
            chkAll = new CheckBox { Text = $"Apply for all remaining ({remainingCount})", Location = new Point(15, 122), AutoSize = true, ForeColor = Theme.Muted };
            var btnSp = Theme.MakeButton("Convert → SP", 140, 26, true); btnSp.Location = new Point(220, 160); btnSp.DialogResult = DialogResult.Yes;
            var btnFiveM = Theme.MakeButton("Map → FiveM Prefix", 140); btnFiveM.Location = new Point(366, 160); btnFiveM.DialogResult = DialogResult.Cancel;
            this.Controls.AddRange(new Control[] { lbl, lblCbo, cboPrefix, chkAll, btnSp, btnFiveM });
            this.AcceptButton = btnSp;
        }
    }

    // =========================================================================
    //  GroupConfigDialog
    // =========================================================================

    internal class GroupConfigDialog : Form
    {
        public bool SyncLinked => chkSync.Checked;
        private CheckBox chkSync;
        private TextBox txtNum;
        private ComboBox cboMode;

        public GroupConfigDialog(FileGroup grp, List<FileGroup> linked)
        {
            this.Text = $"Configure Group: {grp.Key}"; this.Size = new Size(480, 260);
            this.StartPosition = FormStartPosition.CenterParent; this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false; this.MinimizeBox = false;
            this.BackColor = Theme.Surface; this.ForeColor = Theme.Text;
            var lbl = new Label { Text = $"Extension: '{grp.Extension}'  ·  Files: {grp.Paths.Count}  ·  Dominant number: {grp.DominantNumber}", Location = new Point(15, 14), Size = new Size(440, 28), ForeColor = Theme.TextDim };
            var lblNum = Theme.MakeLabel("Target replacement number:", true); lblNum.Location = new Point(15, 52);
            txtNum = Theme.MakeTextBox("e.g. 002", 120); txtNum.Text = grp.TargetNumber; txtNum.Location = new Point(15, 70); txtNum.Font = new Font("Consolas", 11f);
            var lblMode = Theme.MakeLabel("Conversion mode:", true); lblMode.Location = new Point(160, 52);
            cboMode = new ComboBox { Location = new Point(160, 70), Width = 280, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Theme.Background, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat };
            cboMode.Items.AddRange(new object[] { "No conversion (rename only)", "FiveM → SP (strip prefix)", "SP → FiveM (add prefix)" });
            cboMode.SelectedIndex = (int)grp.ConvertMode;
            chkSync = new CheckBox { Text = $"Sync target number to {linked.Count} linked group(s)", Location = new Point(15, 120), AutoSize = true, Checked = true, Enabled = linked.Count > 0, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            var btnOk = Theme.MakeButton("Apply", 100, 26, true); btnOk.Location = new Point(246, 185); btnOk.DialogResult = DialogResult.OK;
            btnOk.Click += (s, e) => { grp.TargetNumber = txtNum.Text.Trim(); grp.ConvertMode = (FormatMode)cboMode.SelectedIndex; };
            var btnCancel = Theme.MakeButton("Cancel", 90, 26); btnCancel.Location = new Point(352, 185); btnCancel.DialogResult = DialogResult.Cancel;
            this.Controls.AddRange(new Control[] { lbl, lblNum, txtNum, lblMode, cboMode, chkSync, btnOk, btnCancel });
            this.AcceptButton = btnOk; this.CancelButton = btnCancel;
        }
    }

    // =========================================================================
    //  DLC Manager Panel
    //  Reads dlclist.xml from the mods folder, lets the user enable / disable
    //  individual DLC entries, detect conflicts / missing folders, reorder
    //  entries, and write the file back.
    // =========================================================================

    // =========================================================================
    //  Utility extension — .Tap() for inline property setting in control trees
    // =========================================================================
    internal static class ControlExtensions
    {
        public static T Tap<T>(this T obj, Action<T> action) { action(obj); return obj; }
    }

    internal class DlcManagerPanel : UserControl
    {
        private Button btnLoad, btnSave, btnAddEntry, btnRemoveEntry, btnMoveUp, btnMoveDown, btnRefreshStatus;
        private TextBox txtDlcListPath;
        private ListView list;
        private Label lblStatus, lblConflicts;
        private Panel infoBar;
        private string _loadedPath = "";
        private List<(string entry, bool enabled)> _entries = new List<(string, bool)>();

        // ── Set when entries were read straight out of a packed update.rpf
        //    (via RpfBuilder.ExtractDlcListXml) rather than a real loose
        //    dlclist.xml file. There's nowhere to Save back to in that case
        //    — see SaveDlcList() — so this is tracked separately from
        //    _loadedPath being merely empty. _lastGtaRoot is kept alongside
        //    it so RebuildList()'s "folder present" check still works
        //    without needing to derive a GTA root from _loadedPath's
        //    directory (which won't exist in this mode). ──────────────────
        private bool _readOnlyPackedSource = false;
        private string _lastGtaRoot = "";
        private ArchiveStatusIndicator _archiveStatus;

        public DlcManagerPanel()
        {
            this.BackColor = Theme.Background;
            Theme.ThemeChanged += () => { this.BackColor = Theme.Background; ApplyListTheme(); };
            Build();
        }

        private Button Btn(string t, int w) { var b = new Button { Text = t, Width = w, Height = 26, BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }
        private Label Lbl(string t) => new Label { Text = t, AutoSize = true, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 132, BackColor = Theme.Surface };

            top.Controls.Add(Lbl("dlclist.xml path:").Tap(l => l.Location = new Point(12, 12)));
            txtDlcListPath = new TextBox { Location = new Point(120, 9), Width = 620, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f) };
            top.Controls.Add(txtDlcListPath);

            var btnBrowse = Btn("Browse…", 74); btnBrowse.Location = new Point(748, 8);
            btnBrowse.Click += (s, e) => {
                using var d = new OpenFileDialog { Title = "Open dlclist.xml", Filter = "dlclist.xml|dlclist.xml|XML files|*.xml" };
                if (d.ShowDialog() == DialogResult.OK) { txtDlcListPath.Text = d.FileName; LoadDlcList(d.FileName); }
            };
            top.Controls.Add(btnBrowse);

            btnLoad = Btn("⬆ Load", 80); btnLoad.Location = new Point(12, 44); btnLoad.Click += (s, e) => LoadDlcList(txtDlcListPath.Text.Trim());
            btnSave = Btn("💾 Save", 80); btnSave.Location = new Point(98, 44); btnSave.Click += (s, e) => SaveDlcList(); btnSave.Enabled = false;
            btnAddEntry = Btn("＋ Add", 72); btnAddEntry.Location = new Point(186, 44); btnAddEntry.Click += BtnAddEntry_Click;
            btnRemoveEntry = Btn("✕ Remove", 80); btnRemoveEntry.Location = new Point(264, 44); btnRemoveEntry.Click += BtnRemoveEntry_Click;
            btnMoveUp = Btn("▲ Up", 60); btnMoveUp.Location = new Point(352, 44); btnMoveUp.Click += (s, e) => MoveSelected(-1);
            btnMoveDown = Btn("▼ Down", 60); btnMoveDown.Location = new Point(418, 44); btnMoveDown.Click += (s, e) => MoveSelected(+1);
            btnRefreshStatus = Btn("↺ Refresh Status", 120); btnRefreshStatus.Location = new Point(486, 44); btnRefreshStatus.Click += (s, e) => RefreshStatus();

            var btnAutoDetect = Btn("🔍 Auto-Detect", 110); btnAutoDetect.Location = new Point(614, 44);
            btnAutoDetect.Click += (s, e) => AutoDetectDlcList();

            // ── For archives our own RPF reader can't decrypt (see
            //    ConvertArchiveToLooseFolder's failure path in SaveDlcList),
            //    OpenIV can still do a full, correct Export since it has
            //    real decryption support this tool deliberately doesn't
            //    add. This just handles the safe part afterward: backing
            //    up the original update.rpf and swapping the exported
            //    folder in as the new loose override — no decryption
            //    happens here, just filesystem moves. ─────────────────────
            var btnFinishFromExport = Btn("📂 Finish Conversion (I exported via OpenIV)", 300);
            btnFinishFromExport.Location = new Point(12, 78);
            btnFinishFromExport.Click += (s, e) => FinishConversionFromOpenIvExport();
            top.Controls.Add(btnFinishFromExport);

            var btnRestoreBackup = Btn("↩ Restore Backup", 140);
            btnRestoreBackup.Location = new Point(320, 78);
            btnRestoreBackup.Click += (s, e) => RestoreUpdateRpfBackup();
            top.Controls.Add(btnRestoreBackup);

            var btnRepack = Btn("📦 Repack Loose Folder to .rpf", 220);
            btnRepack.Location = new Point(470, 78);
            btnRepack.Click += (s, e) => RepackLooseFolderToRpf();
            top.Controls.Add(btnRepack);

            top.Controls.AddRange(new Control[] { btnLoad, btnSave, btnAddEntry, btnRemoveEntry, btnMoveUp, btnMoveDown, btnRefreshStatus, btnAutoDetect });

            infoBar = new Panel { Dock = DockStyle.Top, Height = 28, BackColor = Color.FromArgb(22, 22, 22) };
            lblConflicts = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f) };
            infoBar.Controls.Add(lblConflicts);

            list = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, CheckBoxes = true, Font = new Font("Consolas", 8.5f), BackColor = Theme.ListBg, ForeColor = Theme.Text, BorderStyle = BorderStyle.None };
            list.Columns.Add("#", 40);
            list.Columns.Add("DLC Entry", 380);
            list.Columns.Add("Status", 120);
            list.Columns.Add("Folder present", 110);
            list.ItemChecked += (s, e) => {
                if (e.Item.Index < _entries.Count)
                    _entries[e.Item.Index] = (_entries[e.Item.Index].entry, e.Item.Checked);
                btnSave.Enabled = true;
            };

            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 36, BackColor = Theme.Surface };
            lblStatus = new Label { AutoSize = true, Location = new Point(12, 10), ForeColor = Theme.Muted };
            bottom.Controls.Add(lblStatus);

            this.Controls.Add(list);
            this.Controls.Add(bottom);
            this.Controls.Add(infoBar);
            _archiveStatus = new ArchiveStatusIndicator();
            _archiveStatus.Refresh(AppSettings.HasGtaDirectory ? AppSettings.GtaDirectory : null);
            this.Controls.Add(_archiveStatus);
            this.Controls.Add(top);
        }

        private void ApplyListTheme() { if (list != null) { list.BackColor = Theme.ListBg; list.ForeColor = Theme.Text; } }

        // ── For archives this tool's RPF reader can't decrypt (encrypted
        //    DLC-era content — see the "717 of 1042 files failed" case),
        //    this hands the actual decryption work to OpenIV (Export on
        //    update.rpf's root gives a complete, correctly-decrypted
        //    folder) and only automates what's safe to automate afterward:
        //    backing up the original archive and swapping the exported
        //    folder into its place. No decryption happens in this method —
        //    it's plain File.Move/Directory.Move, same backup-first pattern
        //    used everywhere else in this codebase for update.rpf. ────────
        // ── Every backup-producing operation in this app names its backups
        //    the same way: "update.rpf.bak_yyyyMMdd_HHmmss" — this lists
        //    all of them for the current GTA folder and lets you pick which
        //    to restore. Whatever's currently AT update.rpf (a file or a
        //    folder — it's been both at different points in this workflow)
        //    is renamed aside rather than deleted, so a wrong pick here is
        //    still recoverable. ─────────────────────────────────────────────
        // ── Packs the current loose update.rpf folder into a brand-new .rpf
        //    file, using RpfBuilder.PackFolderAsArchive — real CodeWalker
        //    write API, already proven for building addon dlc.rpf packages,
        //    just applied recursively here instead of to a small fixed set
        //    of files. IMPORTANT: this is a much larger scale than that API
        //    has been exercised at anywhere else in this project (a full
        //    update.rpf-sized folder vs. a handful of addon files), and
        //    isn't something that could be tested against a real archive
        //    from here. Always builds to a NEW path — never touches or
        //    removes the source loose folder — so the source stays
        //    available, known-working, as a fallback regardless of outcome.
        //    Only offers to activate (swap in) the result after it's built,
        //    and even then keeps the current loose folder as a recoverable
        //    *.superseded_* rename rather than deleting it. ────────────────
        private void RepackLooseFolderToRpf()
        {
            string gtaRoot = _lastGtaRoot;
            if (string.IsNullOrEmpty(gtaRoot))
                gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;
            _lastGtaRoot = gtaRoot;

            string updateRpfPath = System.IO.Path.Combine(gtaRoot, "mods", "update", "update.rpf");
            if (!System.IO.Directory.Exists(updateRpfPath))
            {
                MessageBox.Show(
                    $"update.rpf isn't a loose folder at:\n  {updateRpfPath}\n" +
                    "This packs a loose folder INTO a .rpf — there's nothing to pack if it's already a packed archive.",
                    "Nothing To Pack", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var confirm = MessageBox.Show(
                "This packs your current loose update.rpf folder into a brand-new .rpf file.\n\n" +
                "KNOWN ISSUE, confirmed in real use: nested-archive-shaped files (weapons.rpf, vehicles.rpf, " +
                "etc.) get skipped — including them crashes the packer, and a real test showed excluding them " +
                "produces an archive that breaks the game (loading screen and content issues). There is " +
                "currently no known-working configuration of this feature.\n\n" +
                "It builds to a NEW file only — your current loose folder is never touched, and this tool will " +
                "NOT offer to activate the result automatically. This is really only useful right now for " +
                "inspecting what a repack attempt produces, not for actually replacing your working update.rpf.\n\n" +
                "Continue anyway?",
                "Repack — Known To Break The Game", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;

            string outputPath = $"{updateRpfPath}.repacked_{DateTime.Now:yyyyMMdd_HHmmss}.rpf";

            btnSave.Enabled = false;
            lblStatus.Text = "Packing — this can take a while for a large folder …";
            lblStatus.ForeColor = Theme.Warning;
            Application.DoEvents();

            var pack = RpfBuilder.PackFolderAsArchive(gtaRoot, updateRpfPath, outputPath, msg =>
            {
                lblStatus.Text = msg;
                Application.DoEvents();
            });

            btnSave.Enabled = true;

            if (!pack.Success)
            {
                MessageBox.Show(
                    $"Packing failed: {pack.Error}\n\nYour loose update.rpf folder was not touched — it's still there, still working.",
                    "Pack Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Pack failed — your loose folder is untouched.";
                lblStatus.ForeColor = Theme.Danger;
                return;
            }

            lblStatus.Text = $"Packed {pack.FilesPacked} file(s) to {System.IO.Path.GetFileName(outputPath)}. NOT activated — see message.";
            lblStatus.ForeColor = Theme.Warning;

            // This used to offer to activate the repacked file directly
            // (renaming the current loose folder aside, moving the new
            // file into place). Removed after a real run: skipping
            // .rpf-named nested archives (weapons.rpf, vehicles.rpf, etc.
            // — the only option available, since including them crashes
            // CreateFile) produced an archive that loaded but broke the
            // game (loading-screen and content issues) — those files
            // aren't optional. There's no configuration of this feature
            // that's known to produce a working archive, so this no longer
            // offers to activate anything automatically. The file is still
            // written, in case it's useful for inspection, but activating
            // it is left as a fully manual, deliberate choice.
            string skippedNote = pack.SkippedFiles.Count > 0
                ? $"\n\n{pack.SkippedFiles.Count} .rpf-named file(s) were skipped (nested archives like weapons.rpf) — " +
                  "a real test showed a repack missing these breaks the game. This file is NOT known to be a safe " +
                  "replacement for update.rpf."
                : "";

            MessageBox.Show(
                $"Packed {pack.FilesPacked} file(s) to:\n  {outputPath}\n" +
                skippedNote +
                "\n\nThis is NOT activated and this tool won't activate it automatically — your current loose " +
                "folder is untouched and still what the game uses. If you want to experiment with this file " +
                "yourself, that's a fully manual step (rename your loose folder aside, rename this file to " +
                "update.rpf, test carefully) — not something this tool will do for you given what happened last time.",
                "Packed — Not Activated", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void RestoreUpdateRpfBackup()
        {
            string gtaRoot = _lastGtaRoot;
            if (string.IsNullOrEmpty(gtaRoot))
                gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;
            _lastGtaRoot = gtaRoot;

            string updateDir = System.IO.Path.Combine(gtaRoot, "mods", "update");
            string updateRpfPath = System.IO.Path.Combine(updateDir, "update.rpf");

            if (!System.IO.Directory.Exists(updateDir))
            {
                MessageBox.Show($"Couldn't find:\n  {updateDir}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Every backup-producing path in this app has used ONE of two
            // naming patterns: "update.rpf.bak_*" (a file — from
            // ConvertArchiveToLooseFolder, FinishConversionFromOpenIvExport,
            // and the AddonInjector .oiv path) or "update.rpf.superseded_*"
            // (a folder — from RestoreUpdateRpfBackup's own prior runs and
            // RepackLooseFolderToRpf's activation step). Only scanning for
            // the first of these meant a real superseded loose folder
            // wasn't found here after a repack activation went wrong —
            // both are included now.
            var backups = System.IO.Directory.GetFiles(updateDir, "update.rpf.bak_*")
                .Concat(System.IO.Directory.GetDirectories(updateDir, "update.rpf.superseded_*"))
                .OrderByDescending(f => f)
                .ToList();

            if (backups.Count == 0)
            {
                MessageBox.Show(
                    $"No backups found in:\n  {updateDir}\n(looking for update.rpf.bak_* files or update.rpf.superseded_* folders)",
                    "No Backups Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string chosen = null;
            using (var dlg = new Form
            {
                Text = "Restore Backup",
                Size = new Size(560, 360),
                StartPosition = FormStartPosition.CenterParent,
                BackColor = Theme.Surface,
                ForeColor = Theme.Text,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false
            })
            {
                var lbl = new Label
                {
                    Text = "Most recent first — pick which backup to restore as update.rpf:",
                    AutoSize = true,
                    Location = new Point(12, 12),
                    ForeColor = Theme.Muted
                };
                var listBox = new ListBox
                {
                    Location = new Point(12, 36),
                    Size = new Size(520, 240),
                    BackColor = Theme.Background,
                    ForeColor = Theme.Text,
                    Font = new Font("Consolas", 8.5f),
                    BorderStyle = BorderStyle.FixedSingle,
                };
                foreach (var b in backups)
                {
                    string sizeLabel;
                    if (System.IO.Directory.Exists(b))
                    {
                        sizeLabel = "(folder)";
                    }
                    else
                    {
                        var info = new System.IO.FileInfo(b);
                        double mb = info.Length / 1024.0 / 1024.0;
                        sizeLabel = $"{mb:0.#} MB";
                    }
                    listBox.Items.Add($"{System.IO.Path.GetFileName(b)}   ({sizeLabel})");
                }
                listBox.SelectedIndex = 0;

                var btnOk = new Button { Text = "Restore This", DialogResult = DialogResult.OK, Location = new Point(346, 288), Width = 100, Height = 28, BackColor = Theme.Accent, ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
                btnOk.FlatAppearance.BorderSize = 0;
                var btnCx = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Location = new Point(452, 288), Width = 80, Height = 28, BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat };
                btnCx.FlatAppearance.BorderColor = Theme.Border;

                dlg.Controls.AddRange(new Control[] { lbl, listBox, btnOk, btnCx });
                dlg.AcceptButton = btnOk;
                dlg.CancelButton = btnCx;

                if (dlg.ShowDialog(this.FindForm()) != DialogResult.OK || listBox.SelectedIndex < 0) return;
                chosen = backups[listBox.SelectedIndex];
            }

            try
            {
                bool currentIsFile = System.IO.File.Exists(updateRpfPath);
                bool currentIsDir = System.IO.Directory.Exists(updateRpfPath);

                if (currentIsFile || currentIsDir)
                {
                    string supersededPath = $"{updateRpfPath}.superseded_{DateTime.Now:yyyyMMdd_HHmmss}";
                    lblStatus.Text = "Moving current update.rpf aside …";
                    lblStatus.ForeColor = Theme.Warning;
                    Application.DoEvents();

                    if (currentIsFile)
                        System.IO.File.Move(updateRpfPath, supersededPath);
                    else
                        System.IO.Directory.Move(updateRpfPath, supersededPath);
                }

                bool backupIsDir = System.IO.Directory.Exists(chosen); // shouldn't normally happen (backups are always files) but handle it rather than assume
                lblStatus.Text = $"Restoring {System.IO.Path.GetFileName(chosen)} …";
                Application.DoEvents();

                if (backupIsDir)
                    System.IO.Directory.Move(chosen, updateRpfPath);
                else
                    System.IO.File.Move(chosen, updateRpfPath);

                // Restored state is unknown until reloaded — clear out
                // whatever was showing before rather than leave stale data
                // that no longer matches what's actually on disk.
                _loadedPath = "";
                _readOnlyPackedSource = false;
                _entries.Clear();
                RebuildList();
                txtDlcListPath.Text = "";
                btnSave.Enabled = false;

                lblStatus.Text = $"Restored {System.IO.Path.GetFileName(chosen)} as update.rpf. Click Auto-Detect to reload.";
                lblStatus.ForeColor = Theme.Success;
                _archiveStatus?.Refresh(gtaRoot);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Restore failed: {ex.Message}\n\n" +
                    "Check the mods\\update\\ folder directly — depending on where this failed, the current " +
                    "update.rpf may have already been renamed aside (look for a *.superseded_* file/folder) " +
                    "even if the backup wasn't moved into place yet.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Restore failed — see error message.";
                lblStatus.ForeColor = Theme.Danger;
            }
        }

        private void FinishConversionFromOpenIvExport()
        {
            string gtaRoot = _lastGtaRoot;
            if (string.IsNullOrEmpty(gtaRoot))
                gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;
            _lastGtaRoot = gtaRoot;

            string updateRpfPath = System.IO.Path.Combine(gtaRoot, "mods", "update", "update.rpf");
            if (!System.IO.File.Exists(updateRpfPath))
            {
                MessageBox.Show(
                    $"No packed update.rpf file found at:\n  {updateRpfPath}\n" +
                    "Either it's already a loose folder (use Auto-Detect instead), or this isn't the right GTA folder.",
                    "Nothing To Finish", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            MessageBox.Show(
                "In OpenIV: right-click update.rpf's root → Export → pick a folder to export everything into.\n\n" +
                "Once that's done, click OK here and pick that same folder — this tool will back up the current " +
                "update.rpf and swap your exported folder in as the new loose override. No decryption happens " +
                "here; OpenIV already did that part.",
                "Step 1: Export via OpenIV First", MessageBoxButtons.OK, MessageBoxIcon.Information);

            string exportedFolder;
            using (var fbd = new FolderBrowserDialog { Description = "Select the folder you exported update.rpf's contents into" })
            {
                if (fbd.ShowDialog(this.FindForm()) != DialogResult.OK) return;
                exportedFolder = fbd.SelectedPath;
            }

            string sanityCheckPath = System.IO.Path.Combine(exportedFolder, "common", "data", "dlclist.xml");
            if (!System.IO.File.Exists(sanityCheckPath))
            {
                var proceed = MessageBox.Show(
                    $"Didn't find common\\data\\dlclist.xml inside that folder — this doesn't look like a full " +
                    $"export of update.rpf's root (expected it at):\n  {sanityCheckPath}\n\n" +
                    "Continue anyway?",
                    "Doesn't Look Right", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (proceed != DialogResult.Yes) return;
            }

            try
            {
                string backup = $"{updateRpfPath}.bak_{DateTime.Now:yyyyMMdd_HHmmss}";
                lblStatus.Text = "Backing up original update.rpf …";
                lblStatus.ForeColor = Theme.Warning;
                Application.DoEvents();

                System.IO.File.Move(updateRpfPath, backup);
                System.IO.Directory.Move(exportedFolder, updateRpfPath);
                _archiveStatus?.Refresh(gtaRoot);

                lblStatus.Text = $"Done — update.rpf is now a loose folder from your OpenIV export. Original backed up to {System.IO.Path.GetFileName(backup)}.";
                lblStatus.ForeColor = Theme.Success;

                MessageBox.Show(
                    $"update.rpf is now a loose-file folder. Original archive backed up to:\n  {backup}\n\n" +
                    "Click Auto-Detect to load dlclist.xml — it'll be fully editable/saveable from here on.",
                    "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Something went wrong swapping the folder in: {ex.Message}\n\n" +
                    "If update.rpf got renamed to a .bak file but the exported folder wasn't moved into place yet, " +
                    "you can finish it manually: rename the .bak file back to update.rpf if anything looks wrong, " +
                    "or rename your exported folder to update.rpf yourself if the backup succeeded fine.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Swap failed — see error message.";
                lblStatus.ForeColor = Theme.Danger;
            }
        }

        private void AutoDetectDlcList()
        {
            string gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;
            _lastGtaRoot = gtaRoot;
            _archiveStatus?.Refresh(gtaRoot);

            string path = System.IO.Path.Combine(gtaRoot, "mods", "update", "update.rpf", "common", "data", "dlclist.xml");
            if (!System.IO.File.Exists(path))
                path = System.IO.Path.Combine(gtaRoot, "update", "update.rpf", "common", "data", "dlclist.xml");

            if (System.IO.File.Exists(path))
            {
                txtDlcListPath.Text = path;
                LoadDlcList(path);
                return;
            }

            // No loose override found — update.rpf is most likely a real
            // packed archive here (a common setup; see AddonInjector.cs's
            // Install() for the full story on why that blocks a loose
            // override). Fall back to reading dlclist.xml straight out of
            // the archive, read-only, rather than just giving up.
            string extractedXml = null;
            try { extractedXml = RpfBuilder.ExtractDlcListXml(gtaRoot); }
            catch { /* fall through to the Not Found message below */ }

            if (!string.IsNullOrEmpty(extractedXml))
            {
                LoadDlcListFromXml(extractedXml, sourcePath: "", readOnly: true,
                    statusLabel: "update.rpf (packed archive, read-only)");
                txtDlcListPath.Text = "(read-only — inside packed update.rpf, no loose override present)";
                return;
            }

            MessageBox.Show(
                "Could not find a loose dlclist.xml override, and couldn't read one out of update.rpf either.\n" +
                "Browse to it manually, or use the Addon Injector page to convert update.rpf to a loose-file " +
                "folder first (that also makes this page fully editable/saveable afterward).",
                "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void LoadDlcList(string path)
        {
            if (!System.IO.File.Exists(path)) { lblStatus.Text = "File not found."; lblStatus.ForeColor = Theme.Danger; return; }
            try
            {
                var xml = System.IO.File.ReadAllText(path);
                LoadDlcListFromXml(xml, sourcePath: path, readOnly: false,
                    statusLabel: System.IO.Path.GetFileName(path));
            }
            catch (Exception ex) { lblStatus.Text = "Load failed: " + ex.Message; lblStatus.ForeColor = Theme.Danger; }
        }

        // ── Shared parse path for both a real loose file (LoadDlcList) and
        //    content extracted read-only from a packed archive
        //    (AutoDetectDlcList's fallback). readOnly=true means there's no
        //    real file to save back to — see SaveDlcList(). ────────────────
        private void LoadDlcListFromXml(string xml, string sourcePath, bool readOnly, string statusLabel)
        {
            _loadedPath = sourcePath;
            _readOnlyPackedSource = readOnly;
            _entries.Clear();

            // Same line-scan approach as before — walks the raw text rather
            // than parsing as XML, so it tolerates the file's actual
            // formatting (tabs, comments) instead of normalizing it away.
            foreach (var line in xml.Split('\n'))
            {
                var trimmed = line.Trim().TrimEnd('\r');
                if (System.Text.RegularExpressions.Regex.IsMatch(trimmed, @"<Item>\s*dlcpacks:"))
                {
                    var m = System.Text.RegularExpressions.Regex.Match(trimmed, @"(dlcpacks:[^<]+)");
                    if (m.Success) _entries.Add((m.Groups[1].Value.Trim(), true));
                }
                else if (trimmed.StartsWith("<!--") && trimmed.Contains("dlcpacks:"))
                {
                    var m = System.Text.RegularExpressions.Regex.Match(trimmed, @"(dlcpacks:[^<\-]+)");
                    if (m.Success) _entries.Add((m.Groups[1].Value.Trim(), false));
                }
            }

            RebuildList();
            btnSave.Enabled = false;

            if (readOnly)
            {
                lblStatus.Text = $"Loaded {_entries.Count} entries from {statusLabel} — READ-ONLY, no loose override to save to. " +
                                  "Use Addon Injector's archive-to-loose-folder conversion to make this editable.";
                lblStatus.ForeColor = Theme.Warning;
            }
            else
            {
                lblStatus.Text = $"Loaded {_entries.Count} entries from {statusLabel}";
                lblStatus.ForeColor = Theme.Success;
            }
        }

        private void RebuildList()
        {
            list.BeginUpdate(); list.Items.Clear();
            int conflicts = 0, missing = 0;
            var seen = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            string gtaRoot = "";
            for (int i = 0; i < _entries.Count; i++)
            {
                var (entry, enabled) = _entries[i];
                var item = new ListViewItem((i + 1).ToString()) { Checked = enabled };
                item.SubItems.Add(entry);

                if (seen.ContainsKey(entry)) { item.SubItems.Add("⚠ DUPLICATE"); item.ForeColor = Theme.Danger; conflicts++; }
                else { item.SubItems.Add(enabled ? "✔ Active" : "✕ Disabled"); item.ForeColor = enabled ? Theme.Text : Theme.Muted; seen[entry] = i; }

                // Check physical folder existence
                string folderName = entry.TrimEnd('/').Split('/').LastOrDefault() ?? "";
                string folderPresent = "—";
                if (_readOnlyPackedSource && !string.IsNullOrEmpty(_lastGtaRoot))
                {
                    gtaRoot = _lastGtaRoot;
                    var fp = System.IO.Path.Combine(gtaRoot, "mods", "update", "x64", "dlcpacks", folderName);
                    folderPresent = System.IO.Directory.Exists(fp) ? "✔ Found" : "✕ Missing";
                    if (folderPresent.StartsWith("✕")) missing++;
                }
                else if (!string.IsNullOrEmpty(_loadedPath))
                {
                    // Walk up from dlclist.xml to find GTA root
                    try
                    {
                        var dir = System.IO.Path.GetDirectoryName(_loadedPath);
                        while (dir != null && !System.IO.Directory.Exists(System.IO.Path.Combine(dir, "mods"))) dir = System.IO.Path.GetDirectoryName(dir);
                        if (dir != null) { gtaRoot = dir; var fp = System.IO.Path.Combine(dir, "mods", "update", "x64", "dlcpacks", folderName); folderPresent = System.IO.Directory.Exists(fp) ? "✔ Found" : "✕ Missing"; if (folderPresent.StartsWith("✕")) missing++; }
                    }
                    catch { }
                }
                item.SubItems.Add(folderPresent);
                list.Items.Add(item);
            }
            list.EndUpdate();
            lblConflicts.Text = $"{_entries.Count} total  •  {_entries.Count(e => e.enabled)} active  •  {_entries.Count(e => !e.enabled)} disabled  •  {conflicts} duplicate(s)  •  {missing} missing folder(s)";
            lblConflicts.ForeColor = conflicts > 0 || missing > 0 ? Theme.Warning : Theme.Muted;
        }

        private void RefreshStatus() => RebuildList();

        private void SaveDlcList()
        {
            if (_readOnlyPackedSource)
            {
                var confirm = MessageBox.Show(
                    "These entries came from a packed update.rpf with no loose override yet.\n\n" +
                    "Saving will first try converting update.rpf to a loose-file folder — extracts every file it " +
                    "contains, keeps the original archive as a timestamped backup, and only swaps it in if " +
                    "EVERY file extracts cleanly (aborts with the original untouched otherwise). Same safe " +
                    "conversion the Addon Injector page uses. This can take a while for a large archive.\n\n" +
                    "Continue?",
                    "Convert & Save", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm != DialogResult.Yes) return;

                if (string.IsNullOrEmpty(_lastGtaRoot))
                {
                    MessageBox.Show("No GTA folder on record for this — try Auto-Detect again first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string updateRpfPath = System.IO.Path.Combine(_lastGtaRoot, "mods", "update", "update.rpf");
                if (!System.IO.File.Exists(updateRpfPath))
                {
                    MessageBox.Show("Couldn't find update.rpf at:\n  " + updateRpfPath, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                btnSave.Enabled = false; btnLoad.Enabled = false;
                lblStatus.Text = "Converting update.rpf to loose files — this can take a while …";
                lblStatus.ForeColor = Theme.Warning;
                Application.DoEvents(); // this panel has no async plumbing elsewhere — keep the status visible during a long synchronous operation

                var convert = RpfReader.ConvertArchiveToLooseFolder(updateRpfPath, msg =>
                {
                    lblStatus.Text = msg;
                    Application.DoEvents();
                });

                btnLoad.Enabled = true;

                if (!convert.Success)
                {
                    MessageBox.Show(
                        $"Automatic conversion failed: {convert.Error}\n\n" +
                        "This is a known limitation for archives with encrypted DLC content that this tool's " +
                        "RPF reader can't decrypt. Your update.rpf was left completely untouched.\n\n" +
                        "Alternatives: the Addon Injector page's \"Lenny's Mod Loader\" option (avoids " +
                        "dlclist.xml entirely), its .oiv installer option (disabled by default — known to have " +
                        "corrupted dlclist.xml on some archives; only enable it if you understand that risk), " +
                        "or editing dlclist.xml manually via OpenIV.",
                        "Conversion Failed — update.rpf Untouched", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    lblStatus.Text = "Conversion failed — update.rpf untouched. See message for alternatives.";
                    lblStatus.ForeColor = Theme.Danger;
                    btnSave.Enabled = true;
                    return;
                }

                lblStatus.Text = $"Converted — {convert.FilesExtracted} file(s) extracted, original backed up to " +
                                  $"{System.IO.Path.GetFileName(convert.BackupPath)}. Saving dlclist.xml …";
                Application.DoEvents();

                // update.rpf is now a loose folder — its dlclist.xml sits at
                // the same path a real loose override always would. Fall
                // through into the normal save logic below, which now has
                // a real _loadedPath to write to.
                _loadedPath = System.IO.Path.Combine(updateRpfPath, "common", "data", "dlclist.xml");
                _readOnlyPackedSource = false;
                txtDlcListPath.Text = _loadedPath;
            }

            if (string.IsNullOrEmpty(_loadedPath)) { MessageBox.Show("No file loaded.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            try
            {
                // Backup first
                string backup = _loadedPath + ".backup_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
                System.IO.File.Copy(_loadedPath, backup, false);
                var sb = new System.Text.StringBuilder();
                sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendLine("<SMandatoryPacksData>");
                sb.AppendLine("\t<Paths>");
                foreach (var (entry, enabled) in _entries)
                {
                    if (enabled) sb.AppendLine($"\t\t<Item>{entry}</Item>");
                    else sb.AppendLine($"\t\t<!-- <Item>{entry}</Item> -->");
                }
                sb.AppendLine("\t</Paths>");
                sb.AppendLine("</SMandatoryPacksData>");
                System.IO.File.WriteAllText(_loadedPath, sb.ToString(), System.Text.Encoding.UTF8);
                btnSave.Enabled = false;
                lblStatus.Text = $"✔ Saved — backup at {System.IO.Path.GetFileName(backup)}";
                lblStatus.ForeColor = Theme.Success;
            }
            catch (Exception ex) { MessageBox.Show("Save failed:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void BtnAddEntry_Click(object sender, EventArgs e)
        {
            string input = "";
            using (var dlg = new Form { Text = "Add DLC Entry", Size = new Size(420, 130), StartPosition = FormStartPosition.CenterParent, BackColor = Theme.Surface, ForeColor = Theme.Text, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false })
            {
                var txt = new TextBox { Text = "dlcpacks:/", Location = new Point(12, 12), Width = 374, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 9f) };
                var btnOk = new Button { Text = "OK", DialogResult = DialogResult.OK, Location = new Point(218, 44), Width = 80, Height = 26, BackColor = Theme.Accent, ForeColor = Color.White, FlatStyle = FlatStyle.Flat }; btnOk.FlatAppearance.BorderSize = 0;
                var btnCx = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Location = new Point(306, 44), Width = 80, Height = 26, BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat }; btnCx.FlatAppearance.BorderColor = Theme.Border;
                dlg.Controls.AddRange(new Control[] { txt, btnOk, btnCx }); dlg.AcceptButton = btnOk; dlg.CancelButton = btnCx;
                if (dlg.ShowDialog(this.FindForm()) == DialogResult.OK) input = txt.Text.Trim();
            }
            if (string.IsNullOrWhiteSpace(input)) return;
            if (!input.StartsWith("dlcpacks:")) input = "dlcpacks:/" + input.TrimStart('/');
            if (!input.EndsWith("/")) input += "/";
            _entries.Add((input, true));
            RebuildList(); btnSave.Enabled = true;
        }

        private void BtnRemoveEntry_Click(object sender, EventArgs e)
        {
            if (list.SelectedIndices.Count == 0) return;
            var idx = list.SelectedIndices[0];
            if (idx < _entries.Count) { _entries.RemoveAt(idx); RebuildList(); btnSave.Enabled = true; }
        }

        private void MoveSelected(int delta)
        {
            if (list.SelectedIndices.Count == 0) return;
            int idx = list.SelectedIndices[0];
            int newIdx = idx + delta;
            if (newIdx < 0 || newIdx >= _entries.Count) return;
            var tmp = _entries[idx]; _entries[idx] = _entries[newIdx]; _entries[newIdx] = tmp;
            RebuildList(); list.Items[newIdx].Selected = true; btnSave.Enabled = true;
        }
    }

    // =========================================================================
    //  Backup Manager Panel
    //
    //  Every backup-producing operation this conversation's worth of
    //  features has added — ConvertArchiveToLooseFolder, Finish Conversion
    //  via OpenIV export, the AddonInjector .oiv path, RestoreUpdateRpfBackup,
    //  RepackLooseFolderToRpf — writes to mods\update\ using one of a small
    //  set of naming conventions. This scans for all of them, in one place,
    //  so they can be reviewed, restored, or cleaned up without hunting
    //  through File Explorer or guessing which backup is which.
    //
    //  Deliberately read/delete/rename only — this never edits or repacks
    //  an .rpf archive itself; "Restore" here reuses the exact same plain
    //  file/folder move operations already established elsewhere (rename
    //  current aside, move the backup into place), never an in-place
    //  archive edit.
    // =========================================================================
    internal class BackupManagerPanel : UserControl
    {
        private ListView _list;
        private Label _lblSummary;
        private string _gtaRoot;

        private class BackupItem
        {
            public string Path;
            public bool IsDirectory;
            public string Kind;       // human label for what produced it
            public long SizeBytes;    // 0 for directories (not computed — can be slow/large)
            public DateTime Created;
        }

        private List<BackupItem> _items = new List<BackupItem>();

        public BackupManagerPanel()
        {
            BackColor = Theme.Background;
            Theme.ThemeChanged += () => BackColor = Theme.Background;
            Build();
            _gtaRoot = AppSettings.HasGtaDirectory ? AppSettings.GtaDirectory : null;
            RefreshList();
        }

        private Button Btn(string t, int w) { var b = new Button { Text = t, Width = w, Height = 26, BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 92, BackColor = Theme.Surface, Padding = new Padding(12, 10, 12, 10) };

            var lblTitle = new Label
            {
                Text = "Finds every backup this tool has created under mods\\update\\ — .bak_/.superseded_/.repacked_/.broken " +
                       "files and folders, plus dlclist.xml.backup_* inside a loose update.rpf — in one place.",
                Location = new Point(0, 0),
                Size = new Size(900, 32),
                ForeColor = Theme.Muted,
                Font = new Font("Segoe UI", 8f),
            };

            var btnRefresh = Btn("🔄 Refresh", 100); btnRefresh.Location = new Point(0, 40);
            btnRefresh.Click += (s, e) => RefreshList();

            var btnChangeRoot = Btn("📁 Change GTA Folder", 170); btnChangeRoot.Location = new Point(108, 40);
            btnChangeRoot.Click += (s, e) =>
            {
                var picked = GtaDirectoryPickerDialog.PickAndSave(this.FindForm());
                if (picked != null) { _gtaRoot = picked; RefreshList(); }
            };

            var btnOpenFolder = Btn("📂 Open Folder", 130); btnOpenFolder.Location = new Point(286, 40);
            btnOpenFolder.Click += (s, e) => OpenUpdateFolder();

            var btnRestore = Btn("↩ Restore Selected", 160); btnRestore.Location = new Point(424, 40);
            btnRestore.Click += (s, e) => RestoreSelected();

            var btnDelete = Btn("🗑 Delete Selected", 150); btnDelete.Location = new Point(592, 40);
            btnDelete.Click += (s, e) => DeleteSelected();

            var btnCleanTemp = Btn("🧹 Clean Updater Temp Files", 200); btnCleanTemp.Location = new Point(752, 40);
            btnCleanTemp.Click += (s, e) => CleanUpdaterTempFiles();

            top.Controls.AddRange(new Control[] { lblTitle, btnRefresh, btnChangeRoot, btnOpenFolder, btnRestore, btnDelete, btnCleanTemp });

            _list = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                CheckBoxes = true,
                BackColor = Theme.ListBg,
                ForeColor = Theme.Text,
                BorderStyle = BorderStyle.FixedSingle,
            };
            _list.Columns.Add("Name", 380);
            _list.Columns.Add("Type", 70);
            _list.Columns.Add("Size", 90);
            _list.Columns.Add("Created", 150);
            _list.Columns.Add("From", 260);

            _lblSummary = new Label { Dock = DockStyle.Bottom, Height = 28, ForeColor = Theme.Muted, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(10, 0, 0, 0), BackColor = Theme.Surface };

            Controls.Add(_list);
            Controls.Add(_lblSummary);
            Controls.Add(top);
        }

        private string UpdateDir => string.IsNullOrEmpty(_gtaRoot) ? null : Path.Combine(_gtaRoot, "mods", "update");

        private void RefreshList()
        {
            _items.Clear();
            _list.Items.Clear();

            if (string.IsNullOrEmpty(_gtaRoot))
            {
                _gtaRoot = AppSettings.HasGtaDirectory ? AppSettings.GtaDirectory : GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
                if (string.IsNullOrEmpty(_gtaRoot)) { _lblSummary.Text = " No GTA folder set."; return; }
            }

            string updateDir = UpdateDir;
            if (!Directory.Exists(updateDir))
            {
                _lblSummary.Text = $" {updateDir} not found.";
                return;
            }

            // update.rpf.* covers .bak_ (file), .superseded_ (folder),
            // .repacked_*.rpf (file), and anything manually renamed to a
            // similar pattern (e.g. the .broken this app has itself
            // suggested as a manual rename target in past guidance) —
            // deliberately broad rather than only the exact known patterns,
            // since a person may have renamed something themselves.
            foreach (var entry in Directory.GetFileSystemEntries(updateDir, "update.rpf.*"))
            {
                bool isDir = Directory.Exists(entry);
                var item = new BackupItem
                {
                    Path = entry,
                    IsDirectory = isDir,
                    Kind = ClassifyKind(Path.GetFileName(entry)),
                    Created = isDir ? Directory.GetCreationTime(entry) : File.GetCreationTime(entry),
                    SizeBytes = isDir ? 0 : new FileInfo(entry).Length,
                };
                _items.Add(item);
            }

            // dlclist.xml.backup_* only exists when update.rpf is currently
            // loose (they live inside it) — SaveDlcList() in DlcManagerPanel
            // creates these before every write.
            string dlcListDir = Path.Combine(updateDir, "update.rpf", "common", "data");
            if (Directory.Exists(dlcListDir))
            {
                foreach (var entry in Directory.GetFiles(dlcListDir, "dlclist.xml.backup_*"))
                {
                    _items.Add(new BackupItem
                    {
                        Path = entry,
                        IsDirectory = false,
                        Kind = "dlclist.xml edit backup (DLC Manager Save)",
                        Created = File.GetCreationTime(entry),
                        SizeBytes = new FileInfo(entry).Length,
                    });
                }
            }

            _items = _items.OrderByDescending(i => i.Created).ToList();

            foreach (var item in _items)
            {
                var lvi = new ListViewItem(Path.GetFileName(item.Path));
                lvi.SubItems.Add(item.IsDirectory ? "Folder" : "File");
                lvi.SubItems.Add(item.IsDirectory ? "—" : FormatSize(item.SizeBytes));
                lvi.SubItems.Add(item.Created.ToString("yyyy-MM-dd HH:mm:ss"));
                lvi.SubItems.Add(item.Kind);
                lvi.Tag = item;
                _list.Items.Add(lvi);
            }

            long totalBytes = _items.Where(i => !i.IsDirectory).Sum(i => i.SizeBytes);
            _lblSummary.Text = $" {_items.Count} backup item(s) found — {FormatSize(totalBytes)} in files (folder sizes not computed; check disk usage in Explorer if needed).";
        }

        private static string ClassifyKind(string fileName)
        {
            if (fileName.Contains(".bak_")) return "Archive backup (conversion / .oiv / repack activation)";
            if (fileName.Contains(".superseded_")) return "Superseded loose folder (repack / restore)";
            if (fileName.Contains(".repacked_")) return "Repack attempt output (not activated)";
            return "Unrecognized — manually renamed?";
        }

        private static string FormatSize(long bytes)
        {
            string[] units = { "B", "KB", "MB", "GB" };
            double size = bytes; int u = 0;
            while (size >= 1024 && u < units.Length - 1) { size /= 1024; u++; }
            return $"{size:0.#} {units[u]}";
        }

        // ── The self-updating bootstrapper creates GtaFileRenamerUpdate_*
        //    (download staging) and GtaFileRenamerUpdater_* (the self-
        //    copy that actually applies the update) folders in %TEMP%
        //    each time it runs, and doesn't clean them up itself —
        //    intentionally, since deleting its own running copy mid-
        //    execution would be its own hazard. Over repeated updates
        //    these accumulate; this gives a manual way to clear them out. ──
        private void CleanUpdaterTempFiles()
        {
            string tempPath = System.IO.Path.GetTempPath();
            var matches = new List<string>();
            try
            {
                matches.AddRange(System.IO.Directory.GetDirectories(tempPath, "GtaFileRenamerUpdate_*"));
                matches.AddRange(System.IO.Directory.GetDirectories(tempPath, "GtaFileRenamerUpdater_*"));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Couldn't scan the temp folder: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (matches.Count == 0)
            {
                MessageBox.Show("No leftover updater temp folders found.", "Nothing To Clean", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            long totalSize = 0;
            foreach (var dir in matches)
            {
                try { totalSize += new System.IO.DirectoryInfo(dir).EnumerateFiles("*", System.IO.SearchOption.AllDirectories).Sum(f => f.Length); }
                catch { /* size estimate only — a folder that can't be measured just contributes 0 */ }
            }
            string sizeLabel = FormatSize(totalSize);

            var confirm = MessageBox.Show(
                $"Found {matches.Count} leftover updater temp folder(s), roughly {sizeLabel} total.\n\n" +
                "These are safe to delete — they're only used during an update and aren't needed afterward. Delete them now?",
                "Clean Updater Temp Files", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes) return;

            int deleted = 0, failed = 0;
            foreach (var dir in matches)
            {
                try { System.IO.Directory.Delete(dir, recursive: true); deleted++; }
                catch { failed++; } // most likely one is mid-use by an update currently running — skip it, not fatal
            }

            string result = $"Deleted {deleted} folder(s).";
            if (failed > 0) result += $" {failed} couldn't be deleted (probably in use by an update in progress right now).";
            MessageBox.Show(result, "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void OpenUpdateFolder()
        {
            string dir = UpdateDir;
            if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir)) return;
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo { FileName = dir, UseShellExecute = true });
        }

        private List<BackupItem> GetChecked() =>
            _list.CheckedItems.Cast<ListViewItem>().Select(i => (BackupItem)i.Tag).ToList();

        // ── Restore only makes sense for a single, update.rpf-level backup
        //    (.bak_ file or .superseded_ folder) — reuses the exact same
        //    rename-current-aside-then-move-in pattern already established
        //    in DlcManagerPanel.RestoreUpdateRpfBackup, rather than a new
        //    mechanism. dlclist.xml.backup_* entries restore by copying
        //    over the current loose dlclist.xml (with its own fresh backup
        //    first, same as every other write to that file in this app). ──
        private void RestoreSelected()
        {
            var checkedItems = GetChecked();
            if (checkedItems.Count != 1)
            {
                MessageBox.Show("Check exactly one item to restore.", "Restore", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var item = checkedItems[0];
            string updateRpfPath = Path.Combine(UpdateDir, "update.rpf");

            if (Path.GetFileName(item.Path).StartsWith("dlclist.xml.backup_"))
            {
                string currentDlcList = Path.Combine(updateRpfPath, "common", "data", "dlclist.xml");
                if (!File.Exists(currentDlcList))
                {
                    MessageBox.Show(
                        "update.rpf isn't a loose folder right now, so there's no active dlclist.xml to restore this over.",
                        "Can't Restore", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var confirm = MessageBox.Show(
                    $"Restore {Path.GetFileName(item.Path)} over the current dlclist.xml?\n\n" +
                    "The current dlclist.xml will itself be backed up first, so this is reversible.",
                    "Restore dlclist.xml", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm != DialogResult.Yes) return;

                try
                {
                    string freshBackup = $"{currentDlcList}.backup_{DateTime.Now:yyyyMMdd_HHmmss}";
                    File.Copy(currentDlcList, freshBackup, overwrite: false);
                    File.Copy(item.Path, currentDlcList, overwrite: true);
                    MessageBox.Show("Restored. Reload it on the DLC Manager page to see the result.", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefreshList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Restore failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return;
            }

            // update.rpf-level restore
            var confirm2 = MessageBox.Show(
                $"Restore {Path.GetFileName(item.Path)} as update.rpf?\n\n" +
                "Whatever's currently at update.rpf will be renamed aside (kept, not deleted) rather than removed.",
                "Restore update.rpf", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm2 != DialogResult.Yes) return;

            try
            {
                bool currentIsFile = File.Exists(updateRpfPath);
                bool currentIsDir = Directory.Exists(updateRpfPath);
                if (currentIsFile || currentIsDir)
                {
                    string supersededPath = $"{updateRpfPath}.superseded_{DateTime.Now:yyyyMMdd_HHmmss}";
                    if (currentIsFile) File.Move(updateRpfPath, supersededPath);
                    else Directory.Move(updateRpfPath, supersededPath);
                }

                if (item.IsDirectory) Directory.Move(item.Path, updateRpfPath);
                else File.Move(item.Path, updateRpfPath);

                MessageBox.Show("Restored. Reload the DLC Manager page (Auto-Detect) to pick up the new state.", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Restore failed partway: {ex.Message}\n\nCheck {UpdateDir} directly — the current update.rpf " +
                    "may have already been renamed aside even if the selected backup wasn't moved into place yet.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeleteSelected()
        {
            var checkedItems = GetChecked();
            if (checkedItems.Count == 0)
            {
                MessageBox.Show("Check one or more items to delete.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            long totalBytes = checkedItems.Where(i => !i.IsDirectory).Sum(i => i.SizeBytes);
            string sizeNote = checkedItems.Any(i => i.IsDirectory)
                ? $"{FormatSize(totalBytes)}+ (some are folders — actual total is larger)"
                : FormatSize(totalBytes);

            var confirm = MessageBox.Show(
                $"Permanently delete {checkedItems.Count} item(s)? This frees roughly {sizeNote}.\n\n" +
                "This cannot be undone — make sure you don't need any of these first.",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;

            int failCount = 0;
            foreach (var item in checkedItems)
            {
                try
                {
                    if (item.IsDirectory) Directory.Delete(item.Path, recursive: true);
                    else File.Delete(item.Path);
                }
                catch { failCount++; }
            }

            RefreshList();
            if (failCount > 0)
                MessageBox.Show($"{failCount} item(s) couldn't be deleted (in use, or permissions).", "Partial Failure", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    // =========================================================================
    //  Meta Editor Panel
    //  Open any GTA meta / xml file, display it in a tab for each root section,
    //  allow editing common fields through a property-style grid, and save back.
    // =========================================================================

    internal class MetaEditorPanel : UserControl
    {
        private Button btnOpen, btnSave, btnReload, btnFormat, btnSearch;
        private TextBox txtPath, txtSearch;
        private RichTextBox txtEditor;
        private Panel toolbar;
        private Label lblStatus, lblLines;
        private ComboBox cboRecentFiles;
        private CheckBox chkWordWrap;
        private List<string> _recentFiles = new List<string>();
        private string _loadedPath = "";
        private bool _dirty = false;

        private static readonly System.Text.RegularExpressions.Regex XmlTag =
            new System.Text.RegularExpressions.Regex(@"<[^>]+>|""[^""]*""|'[^']*'|\b(true|false|null)\b|-?\d+\.?\d*");

        public MetaEditorPanel()
        {
            this.BackColor = Theme.Background;
            Theme.ThemeChanged += () => { this.BackColor = Theme.Background; ApplyEditorTheme(); };
            Build();
        }

        private Button Btn(string t, int w) { var b = new Button { Text = t, Width = w, Height = 26, BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }

        private void Build()
        {
            toolbar = new Panel { Dock = DockStyle.Top, Height = 88, BackColor = Theme.Surface };

            toolbar.Controls.Add(new Label { Text = "File:", AutoSize = true, Location = new Point(12, 12), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) });
            txtPath = new TextBox { Location = new Point(44, 9), Width = 560, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f), ReadOnly = true };
            toolbar.Controls.Add(txtPath);

            btnOpen = Btn("📂 Open", 80); btnOpen.Location = new Point(612, 8); btnOpen.Click += BtnOpen_Click;
            btnSave = Btn("💾 Save", 74); btnSave.Location = new Point(700, 8); btnSave.Click += BtnSave_Click; btnSave.Enabled = false;
            btnReload = Btn("↺ Reload", 76); btnReload.Location = new Point(782, 8); btnReload.Click += (s, e) => LoadFile(_loadedPath);
            toolbar.Controls.AddRange(new Control[] { btnOpen, btnSave, btnReload });

            // Second row
            toolbar.Controls.Add(new Label { Text = "Recent:", AutoSize = true, Location = new Point(12, 46), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) });
            cboRecentFiles = new ComboBox { Location = new Point(64, 43), Width = 340, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Theme.Background, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Consolas", 8f) };
            cboRecentFiles.SelectedIndexChanged += (s, e) => { if (cboRecentFiles.SelectedItem is string p && p != _loadedPath) LoadFile(p); };
            toolbar.Controls.Add(cboRecentFiles);

            btnFormat = Btn("{ } Format", 82); btnFormat.Location = new Point(412, 42); btnFormat.Click += BtnFormat_Click;

            toolbar.Controls.Add(new Label { Text = "Find:", AutoSize = true, Location = new Point(502, 46), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) });
            txtSearch = new TextBox { Location = new Point(538, 43), Width = 200, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f) };
            txtSearch.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) FindNext(txtSearch.Text); };
            btnSearch = Btn("Find", 50); btnSearch.Location = new Point(744, 42); btnSearch.Click += (s, e) => FindNext(txtSearch.Text);

            chkWordWrap = new CheckBox { Text = "Wrap", Location = new Point(802, 46), AutoSize = true, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            chkWordWrap.CheckedChanged += (s, e) => { txtEditor.WordWrap = chkWordWrap.Checked; };
            toolbar.Controls.AddRange(new Control[] { btnFormat, btnSearch, chkWordWrap });
            toolbar.Controls.Add(txtSearch);

            txtEditor = new RichTextBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(18, 18, 18), ForeColor = Color.FromArgb(212, 212, 212), Font = new Font("Consolas", 9.5f), BorderStyle = BorderStyle.None, WordWrap = false, AcceptsTab = true, HideSelection = false };
            txtEditor.TextChanged += (s, e) => { _dirty = true; btnSave.Enabled = !string.IsNullOrEmpty(_loadedPath); UpdateLineCount(); };
            txtEditor.KeyDown += TxtEditor_KeyDown;

            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = Theme.Surface };
            lblStatus = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            lblLines = new Label { AutoSize = true, Location = new Point(500, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            bottom.Controls.AddRange(new Control[] { lblStatus, lblLines });

            this.Controls.Add(txtEditor);
            this.Controls.Add(bottom);
            this.Controls.Add(toolbar);

            ShowWelcome();
        }

        private void ShowWelcome()
        {
            txtEditor.Text = "<!-- Open a .meta, .xml, .ymt.xml or any GTA data file to start editing. -->\r\n\r\n<!-- Supported file types:\r\n     vehicles.meta  handling.meta  carcols.meta  carvariations.meta\r\n     peds.meta  dlclist.xml  content.xml  setup2.xml\r\n     *.ymt.xml (decompiled with OpenIV's 'Export using OpenFormats') -->";
            lblStatus.Text = "Open a file to begin editing.";
        }

        private void ApplyEditorTheme() { if (txtEditor != null) { txtEditor.BackColor = Color.FromArgb(18, 18, 18); txtEditor.ForeColor = Color.FromArgb(212, 212, 212); } }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            if (_dirty && !string.IsNullOrEmpty(_loadedPath))
                if (MessageBox.Show("Unsaved changes. Discard?", "Unsaved", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            using var d = new OpenFileDialog { Title = "Open GTA Meta / XML File", Filter = "Meta/XML files|*.meta;*.xml;*.ymt.xml;*.ymt|All Files|*.*", Multiselect = false };
            if (d.ShowDialog() == DialogResult.OK) LoadFile(d.FileName);
        }

        private void LoadFile(string path)
        {
            if (!System.IO.File.Exists(path)) return;
            try
            {
                var text = System.IO.File.ReadAllText(path);
                txtEditor.Text = text;
                txtPath.Text = path; _loadedPath = path; _dirty = false; btnSave.Enabled = false;
                lblStatus.Text = $"Loaded: {System.IO.Path.GetFileName(path)}  ({text.Length:N0} chars)";
                lblStatus.ForeColor = Theme.Success;
                UpdateLineCount();
                if (!_recentFiles.Contains(path)) { _recentFiles.Insert(0, path); if (_recentFiles.Count > 12) _recentFiles.RemoveAt(12); cboRecentFiles.Items.Insert(0, path); }
            }
            catch (Exception ex) { lblStatus.Text = "Load failed: " + ex.Message; lblStatus.ForeColor = Theme.Danger; }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_loadedPath)) { using var d = new SaveFileDialog { Filter = "XML|*.xml|Meta|*.meta|All|*.*" }; if (d.ShowDialog() != DialogResult.OK) return; _loadedPath = d.FileName; }
            try { System.IO.File.WriteAllText(_loadedPath, txtEditor.Text, System.Text.Encoding.UTF8); _dirty = false; btnSave.Enabled = false; lblStatus.Text = "✔ Saved: " + System.IO.Path.GetFileName(_loadedPath); lblStatus.ForeColor = Theme.Success; }
            catch (Exception ex) { MessageBox.Show("Save failed:\n" + ex.Message); }
        }

        private void BtnFormat_Click(object sender, EventArgs e)
        {
            try
            {
                var doc = new System.Xml.XmlDocument(); doc.LoadXml(txtEditor.Text);
                var sw = new System.IO.StringWriter();
                using (var xw = System.Xml.XmlWriter.Create(sw, new System.Xml.XmlWriterSettings { Indent = true, IndentChars = "  ", NewLineChars = "\r\n", OmitXmlDeclaration = false }))
                    doc.Save(xw);
                txtEditor.Text = sw.ToString();
                lblStatus.Text = "✔ Formatted."; lblStatus.ForeColor = Theme.Success;
            }
            catch (Exception ex) { lblStatus.Text = "Format failed (invalid XML?): " + ex.Message; lblStatus.ForeColor = Theme.Warning; }
        }

        private void FindNext(string term)
        {
            if (string.IsNullOrEmpty(term)) return;
            int start = txtEditor.SelectionStart + txtEditor.SelectionLength;
            int idx = txtEditor.Text.IndexOf(term, start, StringComparison.OrdinalIgnoreCase);
            if (idx < 0) idx = txtEditor.Text.IndexOf(term, 0, StringComparison.OrdinalIgnoreCase);
            if (idx >= 0) { txtEditor.Select(idx, term.Length); txtEditor.ScrollToCaret(); }
            else lblStatus.Text = $"'{term}' not found.";
        }

        private void TxtEditor_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.S) { BtnSave_Click(sender, e); e.Handled = true; }
            if (e.Control && e.KeyCode == Keys.F) { txtSearch.Focus(); e.Handled = true; }
        }

        private void UpdateLineCount() { if (txtEditor != null) lblLines.Text = $"Lines: {txtEditor.Lines.Length:N0}  •  Chars: {txtEditor.TextLength:N0}"; }
    }

    // =========================================================================
    //  Mod Organizer Panel
    //  Scans the mods/update/x64/dlcpacks folder, lists every installed mod
    //  with its size and status, lets you enable / disable mods by toggling a
    //  prefix underscore convention, and detects name conflicts.
    // =========================================================================

    internal class ModOrganizerPanel : UserControl
    {
        private Button btnScan, btnEnableSelected, btnDisableSelected, btnOpenFolder, btnDeleteSelected, btnRefresh;
        private TextBox txtModsRoot, _txtFilter;
        private ListView list;
        private Label lblStatus, lblSummary;
        private CheckBox chkShowDisabled;
        private List<ModEntry> _mods = new List<ModEntry>();

        private class ModEntry
        {
            public string FolderPath;
            public string FolderName;
            public string DlcName;
            public bool Enabled;
            public long SizeBytes;
            public bool HasDlcRpf;
            public string Conflict = "";
            public bool? InDlcList; // null = couldn't check (no GTA root / no dlclist.xml found)
        }

        private string _gtaRootForDlcCheck;

        public ModOrganizerPanel()
        {
            this.BackColor = Theme.Background;
            Theme.ThemeChanged += () => { this.BackColor = Theme.Background; if (list != null) { list.BackColor = Theme.ListBg; list.ForeColor = Theme.Text; } };
            Build();
            _gtaRootForDlcCheck = AppSettings.HasGtaDirectory ? AppSettings.GtaDirectory : null;
        }

        private Button Btn(string t, int w) { var b = new Button { Text = t, Width = w, Height = 26, BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 88, BackColor = Theme.Surface };
            top.Controls.Add(new Label { Text = "Mods dlcpacks folder:", AutoSize = true, Location = new Point(12, 12), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) });
            txtModsRoot = new TextBox { Location = new Point(162, 9), Width = 550, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f) };
            top.Controls.Add(txtModsRoot);
            var btnBrowse = Btn("Browse…", 74); btnBrowse.Location = new Point(720, 8);
            btnBrowse.Click += (s, e) => { using var d = new FolderBrowserDialog { Description = "Select mods/update/x64/dlcpacks folder" }; if (d.ShowDialog() == DialogResult.OK) { txtModsRoot.Text = d.SelectedPath; Scan(); } };
            top.Controls.Add(btnBrowse);

            var btnAutoDetect = Btn("🔍 Auto-Detect", 110); btnAutoDetect.Location = new Point(800, 8);
            btnAutoDetect.Click += (s, e) => {
                string gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
                if (string.IsNullOrEmpty(gtaRoot)) return;
                _gtaRootForDlcCheck = gtaRoot;
                var path = System.IO.Path.Combine(gtaRoot, "mods", "update", "x64", "dlcpacks");
                if (System.IO.Directory.Exists(path)) { txtModsRoot.Text = path; Scan(); }
                else MessageBox.Show("dlcpacks folder not found.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            top.Controls.Add(btnAutoDetect);

            btnScan = Btn("🔍 Scan", 72); btnScan.Location = new Point(12, 46); btnScan.Click += (s, e) => Scan();
            btnEnableSelected = Btn("✔ Enable", 76); btnEnableSelected.Location = new Point(90, 46); btnEnableSelected.Click += (s, e) => ToggleSelected(true);
            btnDisableSelected = Btn("✕ Disable", 80); btnDisableSelected.Location = new Point(172, 46); btnDisableSelected.Click += (s, e) => ToggleSelected(false);
            btnOpenFolder = Btn("📂 Open", 68); btnOpenFolder.Location = new Point(258, 46); btnOpenFolder.Click += (s, e) => OpenSelected();
            btnDeleteSelected = Btn("🗑 Delete", 78); btnDeleteSelected.Location = new Point(332, 46); btnDeleteSelected.BackColor = Color.FromArgb(70, 40, 40); btnDeleteSelected.Click += (s, e) => DeleteSelected();
            btnRefresh = Btn("↺ Refresh", 76); btnRefresh.Location = new Point(416, 46); btnRefresh.Click += (s, e) => Scan();
            chkShowDisabled = new CheckBox { Text = "Show disabled", Location = new Point(500, 50), AutoSize = true, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f), Checked = true };
            chkShowDisabled.CheckedChanged += (s, e) => RebuildList();
            _txtFilter = new TextBox { Location = new Point(620, 47), Width = 200, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, PlaceholderText = "🔎 Filter by name…", Font = new Font("Segoe UI", 8.5f) };
            _txtFilter.TextChanged += (s, e) => RebuildList();
            top.Controls.AddRange(new Control[] { btnScan, btnEnableSelected, btnDisableSelected, btnOpenFolder, btnDeleteSelected, btnRefresh, chkShowDisabled, _txtFilter });

            var infoBar = new Panel { Dock = DockStyle.Top, Height = 28, BackColor = Color.FromArgb(22, 22, 22) };
            lblSummary = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f) };
            infoBar.Controls.Add(lblSummary);

            list = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, CheckBoxes = false, Font = new Font("Consolas", 8.5f), BackColor = Theme.ListBg, ForeColor = Theme.Text, BorderStyle = BorderStyle.None };
            list.Columns.Add("DLC Name", 200);
            list.Columns.Add("Status", 80);
            list.Columns.Add("Size", 80);
            list.Columns.Add("dlc.rpf", 70);
            list.Columns.Add("In dlclist.xml", 100);
            list.Columns.Add("Conflict", 200);
            list.DoubleClick += (s, e) => OpenSelected();
            list.ColumnClick += (s, e) => SortBy(e.Column);
            list.MouseUp += (s, e) =>
            {
                if (e.Button != MouseButtons.Right) return;
                var hit = list.HitTest(e.Location);
                if (hit.Item == null) return;
                if (!hit.Item.Selected) { list.SelectedItems.Clear(); hit.Item.Selected = true; }

                var menu = new ContextMenuStrip();
                int selCount = list.SelectedItems.Count;
                menu.Items.Add(selCount > 1 ? $"✔ Enable {selCount} selected" : "✔ Enable", null, (s2, e2) => ToggleSelected(true));
                menu.Items.Add(selCount > 1 ? $"✕ Disable {selCount} selected" : "✕ Disable", null, (s2, e2) => ToggleSelected(false));
                menu.Items.Add(new ToolStripSeparator());
                menu.Items.Add("📂 Open Folder", null, (s2, e2) => OpenSelected());
                menu.Items.Add("✏ Rename…", null, (s2, e2) => RenameSelected());
                menu.Items.Add("📋 Copy Folder Path", null, (s2, e2) =>
                {
                    if (list.SelectedItems.Count > 0 && list.SelectedItems[0].Tag is ModEntry m)
                        Clipboard.SetText(m.FolderPath);
                });
                menu.Items.Add(new ToolStripSeparator());
                menu.Items.Add(selCount > 1 ? $"🗑 Delete {selCount} selected" : "🗑 Delete", null, (s2, e2) => DeleteSelected());
                menu.Show(list, e.Location);
            };

            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = Theme.Surface };
            lblStatus = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            bottom.Controls.Add(lblStatus);

            this.Controls.Add(list);
            this.Controls.Add(bottom);
            this.Controls.Add(infoBar);
            this.Controls.Add(top);
        }

        private static string FriendlySize(long bytes)
        {
            if (bytes >= 1_073_741_824) return (bytes / 1_073_741_824.0).ToString("F1") + " GB";
            if (bytes >= 1_048_576) return (bytes / 1_048_576.0).ToString("F1") + " MB";
            if (bytes >= 1024) return (bytes / 1024.0).ToString("F1") + " KB";
            return bytes + " B";
        }

        private static long DirSize(string path) { try { return new System.IO.DirectoryInfo(path).GetFiles("*", System.IO.SearchOption.AllDirectories).Sum(f => f.Length); } catch { return 0; } }

        private void Scan()
        {
            string root = txtModsRoot.Text.Trim();
            if (!System.IO.Directory.Exists(root)) { lblStatus.Text = "Folder not found."; lblStatus.ForeColor = Theme.Danger; return; }
            _mods.Clear();

            // Cross-reference against dlclist.xml so it's visible when a
            // folder exists but was never actually registered — that mod
            // silently does nothing in-game even though it "looks" installed.
            string dlcListXml = null;
            if (!string.IsNullOrEmpty(_gtaRootForDlcCheck))
            {
                string loosePath = System.IO.Path.Combine(_gtaRootForDlcCheck, "mods", "update", "update.rpf", "common", "data", "dlclist.xml");
                if (System.IO.File.Exists(loosePath))
                {
                    try { dlcListXml = System.IO.File.ReadAllText(loosePath); } catch { }
                }
                else
                {
                    try { dlcListXml = RpfBuilder.ExtractDlcListXml(_gtaRootForDlcCheck); } catch { }
                }
            }

            var seen = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var dir in System.IO.Directory.GetDirectories(root).OrderBy(d => d))
            {
                var name = System.IO.Path.GetFileName(dir);
                bool enabled = !name.StartsWith("_");
                string dlcName = enabled ? name : name.TrimStart('_');
                bool hasRpf = System.IO.File.Exists(System.IO.Path.Combine(dir, "dlc.rpf"));
                string conflict = "";
                if (seen.ContainsKey(dlcName)) { conflict = "⚠ Conflicts with " + seen[dlcName]; }
                else seen[dlcName] = name;

                bool? inDlcList = dlcListXml == null ? (bool?)null : dlcListXml.Contains($"dlcpacks:/{dlcName}/", StringComparison.OrdinalIgnoreCase);

                _mods.Add(new ModEntry { FolderPath = dir, FolderName = name, DlcName = dlcName, Enabled = enabled, SizeBytes = DirSize(dir), HasDlcRpf = hasRpf, Conflict = conflict, InDlcList = inDlcList });
            }
            RebuildList();
        }

        private void RebuildList()
        {
            list.BeginUpdate(); list.Items.Clear();
            var filtered = chkShowDisabled.Checked ? _mods : _mods.Where(m => m.Enabled).ToList();
            string term = _txtFilter?.Text.Trim() ?? "";
            if (!string.IsNullOrEmpty(term))
                filtered = filtered.Where(m => m.DlcName.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0).ToList();

            foreach (var m in filtered)
            {
                var item = new ListViewItem(m.DlcName);
                item.SubItems.Add(m.Enabled ? "✔ Enabled" : "✕ Disabled");
                item.SubItems.Add(FriendlySize(m.SizeBytes));
                item.SubItems.Add(m.HasDlcRpf ? "✔" : "✕");
                item.SubItems.Add(m.InDlcList == null ? "?" : (m.InDlcList.Value ? "✔ Yes" : "✕ NOT LISTED"));
                item.SubItems.Add(m.Conflict);
                item.ForeColor = !m.Enabled ? Theme.Muted
                    : m.InDlcList == false ? Theme.Danger
                    : !string.IsNullOrEmpty(m.Conflict) ? Theme.Warning
                    : Theme.Text;
                item.Tag = m;
                list.Items.Add(item);
            }
            list.EndUpdate();
            int conflicts = _mods.Count(m => !string.IsNullOrEmpty(m.Conflict));
            int notListed = _mods.Count(m => m.Enabled && m.InDlcList == false);
            lblSummary.Text = $"{_mods.Count} mods  •  {_mods.Count(m => m.Enabled)} enabled  •  {_mods.Count(m => !m.Enabled)} disabled  •  {conflicts} conflict(s)" +
                               (notListed > 0 ? $"  •  ⚠ {notListed} enabled but NOT in dlclist.xml" : "") +
                               $"  •  Total: {FriendlySize(_mods.Sum(m => m.SizeBytes))}";
            lblSummary.ForeColor = notListed > 0 || conflicts > 0 ? Theme.Warning : Theme.Muted;
            lblStatus.Text = $"Scanned {_mods.Count} mods in {txtModsRoot.Text}";
            lblStatus.ForeColor = Theme.Success;
        }

        private void ToggleSelected(bool enable)
        {
            if (list.SelectedItems.Count == 0) return;
            foreach (ListViewItem item in list.SelectedItems)
            {
                if (item.Tag is ModEntry m)
                {
                    string newName = enable ? m.DlcName : "_" + m.DlcName;
                    string newPath = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(m.FolderPath), newName);
                    try { System.IO.Directory.Move(m.FolderPath, newPath); }
                    catch (Exception ex) { MessageBox.Show("Could not rename folder:\n" + ex.Message); return; }
                }
            }
            Scan();
        }

        private void OpenSelected()
        {
            if (list.SelectedItems.Count == 0) return;
            if (list.SelectedItems[0].Tag is ModEntry m && System.IO.Directory.Exists(m.FolderPath))
                System.Diagnostics.Process.Start("explorer.exe", m.FolderPath);
        }

        private void DeleteSelected()
        {
            if (list.SelectedItems.Count == 0) return;
            var entries = list.SelectedItems.Cast<ListViewItem>().Select(i => i.Tag as ModEntry).Where(m => m != null).ToList();
            if (entries.Count == 0) return;

            long totalSize = entries.Sum(m => m.SizeBytes);
            string message = entries.Count == 1
                ? $"Permanently delete '{entries[0].DlcName}' ({FriendlySize(entries[0].SizeBytes)})?\n\nThis cannot be undone."
                : $"Permanently delete {entries.Count} mods ({FriendlySize(totalSize)} total)?\n\n" +
                  string.Join("\n", entries.Take(8).Select(m => "  • " + m.DlcName)) +
                  (entries.Count > 8 ? $"\n  …and {entries.Count - 8} more" : "") +
                  "\n\nThis cannot be undone.";

            if (MessageBox.Show(message, "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

            int failCount = 0;
            foreach (var m in entries)
            {
                try { System.IO.Directory.Delete(m.FolderPath, true); }
                catch { failCount++; }
            }
            Scan();
            if (failCount > 0)
                MessageBox.Show($"{failCount} folder(s) couldn't be deleted (in use, or permissions).", "Partial Failure", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void RenameSelected()
        {
            if (list.SelectedItems.Count != 1) { MessageBox.Show("Select exactly one mod to rename.", "Rename", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            if (list.SelectedItems[0].Tag is not ModEntry m) return;

            string newName = Microsoft.VisualBasic.Interaction.InputBox(
                "New DLC folder name (this is also the dlcpacks: name used in dlclist.xml — renaming here will NOT update dlclist.xml automatically):",
                "Rename Mod", m.DlcName);
            if (string.IsNullOrWhiteSpace(newName) || newName == m.DlcName) return;

            string prefix = m.Enabled ? "" : "_";
            string newPath = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(m.FolderPath), prefix + newName);
            if (System.IO.Directory.Exists(newPath)) { MessageBox.Show("A folder with that name already exists.", "Rename Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            try
            {
                System.IO.Directory.Move(m.FolderPath, newPath);
                MessageBox.Show(
                    $"Renamed. Remember: if this mod was already listed in dlclist.xml as '{m.DlcName}', you'll need to update that entry to '{newName}' too (DLC Manager or Load Order Manager page) — this rename doesn't touch dlclist.xml.",
                    "Renamed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Scan();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Rename failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int _sortColumn = -1; private bool _sortAsc = true;
        private void SortBy(int col) { if (_sortColumn == col) _sortAsc = !_sortAsc; else { _sortColumn = col; _sortAsc = true; } _mods.Sort((a, b) => { int r = col == 0 ? string.Compare(a.DlcName, b.DlcName) : col == 1 ? a.Enabled.CompareTo(b.Enabled) : col == 2 ? a.SizeBytes.CompareTo(b.SizeBytes) : 0; return _sortAsc ? r : -r; }); RebuildList(); }
    }

    // =========================================================================
    //  Batch Processor Panel
    //  Queue up multiple FiveM resource folders and convert them all to SP
    //  addon DLC packs in one click, with per-job status and a combined log.
    // =========================================================================

    internal class BatchProcessorPanel : UserControl
    {
        private Button btnAddFolders, btnRemoveJob, btnClearAll, btnRunAll, btnStopAll, btnOpenOutput, _btnRetryFailed;
        private ListView jobList;
        private RichTextBox log;
        private TextBox txtOutputRoot;
        private Label lblStatus;
        private ProgressBar progressBar;
        private bool _running = false, _stop = false;

        private class BatchJob
        {
            public string SourceFolder;
            public string JobName;
            public string Status = "Queued";
            public string Error = "";
        }
        private List<BatchJob> _jobs = new List<BatchJob>();

        public BatchProcessorPanel()
        {
            this.BackColor = Theme.Background;
            Theme.ThemeChanged += () => { this.BackColor = Theme.Background; };
            Build();
        }

        private Button Btn(string t, int w, Color? bg = null) { var b = new Button { Text = t, Width = w, Height = 26, BackColor = bg ?? Theme.Surface, ForeColor = bg.HasValue ? Color.White : Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 88, BackColor = Theme.Surface };
            top.Controls.Add(new Label { Text = "Output root:", AutoSize = true, Location = new Point(12, 12), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) });
            txtOutputRoot = new TextBox { Location = new Point(90, 9), Width = 620, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f) };
            top.Controls.Add(txtOutputRoot);
            var btnBrowseOut = Btn("Browse…", 74); btnBrowseOut.Location = new Point(718, 8); btnBrowseOut.Click += (s, e) => { using var d = new FolderBrowserDialog { Description = "Select output folder for converted SP packs" }; if (d.ShowDialog() == DialogResult.OK) txtOutputRoot.Text = d.SelectedPath; };
            top.Controls.Add(btnBrowseOut);

            btnAddFolders = Btn("＋ Add Resource Folders", 160); btnAddFolders.Location = new Point(12, 46); btnAddFolders.Click += BtnAddFolders_Click;
            btnRemoveJob = Btn("✕ Remove", 80); btnRemoveJob.Location = new Point(178, 46); btnRemoveJob.Click += (s, e) => RemoveSelected();
            btnClearAll = Btn("✕ Clear All", 84); btnClearAll.Location = new Point(264, 46); btnClearAll.Click += (s, e) => { _jobs.Clear(); RebuildJobList(); };
            btnRunAll = Btn("▶ Run All", 80, Theme.Accent); btnRunAll.Location = new Point(356, 46); btnRunAll.Click += async (s, e) => await RunAll();
            btnStopAll = Btn("■ Stop", 60); btnStopAll.Location = new Point(442, 46); btnStopAll.Click += (s, e) => _stop = true; btnStopAll.Enabled = false;
            btnOpenOutput = Btn("📂 Open Output", 110); btnOpenOutput.Location = new Point(508, 46); btnOpenOutput.Click += (s, e) => { if (System.IO.Directory.Exists(txtOutputRoot.Text)) System.Diagnostics.Process.Start("explorer.exe", txtOutputRoot.Text); };
            _btnRetryFailed = Btn("🔁 Retry Failed", 110); _btnRetryFailed.Location = new Point(624, 46); _btnRetryFailed.Click += async (s, e) => await RunAll(failedOnly: true);
            top.Controls.AddRange(new Control[] { btnAddFolders, btnRemoveJob, btnClearAll, btnRunAll, btnStopAll, btnOpenOutput, _btnRetryFailed });

            // Split left (job list) and right (log)
            var splitter = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterDistance = 380, BackColor = Theme.Background };

            jobList = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, Font = new Font("Consolas", 8f), BackColor = Theme.ListBg, ForeColor = Theme.Text, BorderStyle = BorderStyle.None };
            jobList.Columns.Add("Resource Folder", 240); jobList.Columns.Add("Status", 120);
            jobList.AllowDrop = true;
            jobList.DragEnter += (s, e) => e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
            jobList.DragDrop += (s, e) => { var paths = (string[])e.Data.GetData(DataFormats.FileDrop); if (paths != null) AddFolders(paths); };
            jobList.DoubleClick += (s, e) =>
            {
                if (jobList.SelectedItems.Count == 0 || jobList.SelectedItems[0].Tag is not BatchJob j) return;
                if (j.Status == "Failed") MessageBox.Show(string.IsNullOrEmpty(j.Error) ? "(no error details captured)" : j.Error, $"Error — {j.JobName}", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else if (System.IO.Directory.Exists(j.SourceFolder)) System.Diagnostics.Process.Start("explorer.exe", j.SourceFolder);
            };
            jobList.MouseUp += (s, e) =>
            {
                if (e.Button != MouseButtons.Right) return;
                var hit = jobList.HitTest(e.Location);
                if (hit.Item == null) return;
                if (!hit.Item.Selected) { jobList.SelectedItems.Clear(); hit.Item.Selected = true; }
                if (hit.Item.Tag is not BatchJob j) return;

                var menu = new ContextMenuStrip();
                menu.Items.Add("📂 Open Source Folder", null, (s2, e2) => { if (System.IO.Directory.Exists(j.SourceFolder)) System.Diagnostics.Process.Start("explorer.exe", j.SourceFolder); });
                if (j.Status == "Failed")
                    menu.Items.Add("📋 Copy Error", null, (s2, e2) => Clipboard.SetText(j.Error ?? ""));
                menu.Items.Add(new ToolStripSeparator());
                menu.Items.Add("✕ Remove", null, (s2, e2) => RemoveSelected());
                menu.Show(jobList, e.Location);
            };
            splitter.Panel1.Controls.Add(jobList);

            log = new RichTextBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(18, 18, 18), ForeColor = Color.FromArgb(200, 200, 200), Font = new Font("Consolas", 8.5f), ReadOnly = true, BorderStyle = BorderStyle.None, WordWrap = false };
            splitter.Panel2.Controls.Add(log);

            progressBar = new ProgressBar { Dock = DockStyle.Bottom, Height = 6, Style = ProgressBarStyle.Continuous, BackColor = Theme.Background, ForeColor = Theme.Accent };
            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = Theme.Surface };
            lblStatus = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            bottom.Controls.Add(lblStatus);

            this.Controls.Add(splitter);
            this.Controls.Add(progressBar);
            this.Controls.Add(bottom);
            this.Controls.Add(top);

            lblStatus.Text = "Add FiveM resource folders, set an output folder, and click Run All.";
        }

        private void BtnAddFolders_Click(object sender, EventArgs e)
        {
            using var d = new FolderBrowserDialog { Description = "Select a FiveM resource folder to add to the queue" };
            if (d.ShowDialog() == DialogResult.OK) AddFolders(new[] { d.SelectedPath });
        }

        private void AddFolders(string[] paths)
        {
            foreach (var p in paths)
            {
                if (!System.IO.Directory.Exists(p)) continue;
                if (_jobs.Any(j => j.SourceFolder.Equals(p, StringComparison.OrdinalIgnoreCase))) continue;
                _jobs.Add(new BatchJob { SourceFolder = p, JobName = System.IO.Path.GetFileName(p) });
            }
            RebuildJobList();
        }

        private void RemoveSelected() { if (jobList.SelectedIndices.Count == 0) return; foreach (int i in jobList.SelectedIndices.Cast<int>().OrderByDescending(x => x)) if (i < _jobs.Count) _jobs.RemoveAt(i); RebuildJobList(); }

        private void RebuildJobList()
        {
            jobList.BeginUpdate(); jobList.Items.Clear();
            foreach (var j in _jobs)
            {
                var item = new ListViewItem(j.JobName);
                item.SubItems.Add(j.Status);
                item.ForeColor = j.Status == "Done" ? Theme.Success : j.Status == "Failed" ? Theme.Danger : j.Status == "Running" ? Theme.Warning : Theme.Muted;
                item.Tag = j;
                jobList.Items.Add(item);
            }
            jobList.EndUpdate();
            lblStatus.Text = $"{_jobs.Count} job(s) queued.";
        }

        private void Log(string msg, Color? col = null)
        {
            if (InvokeRequired) { Invoke((Action)(() => Log(msg, col))); return; }
            log.SelectionColor = col ?? Color.FromArgb(200, 200, 200);
            log.AppendText(msg + "\r\n");
            log.ScrollToCaret();
        }

        private async System.Threading.Tasks.Task RunAll(bool failedOnly = false)
        {
            if (_running) return;
            string outRoot = txtOutputRoot.Text.Trim();
            if (string.IsNullOrEmpty(outRoot)) { MessageBox.Show("Set an output root folder first.", "Missing", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            var indicesToRun = failedOnly
                ? Enumerable.Range(0, _jobs.Count).Where(i => _jobs[i].Status == "Failed").ToList()
                : Enumerable.Range(0, _jobs.Count).ToList();

            if (failedOnly && indicesToRun.Count == 0)
            {
                MessageBox.Show("No failed jobs to retry.", "Nothing To Retry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            _running = true; _stop = false; btnRunAll.Enabled = false; btnStopAll.Enabled = true; _btnRetryFailed.Enabled = false;
            progressBar.Value = 0; progressBar.Maximum = Math.Max(1, indicesToRun.Count);
            log.Clear();
            Log($"=== Batch started: {indicesToRun.Count} job(s){(failedOnly ? " (retrying failed only)" : "")} ===", Color.FromArgb(100, 200, 100));

            int ok = 0, fail = 0, completedCount = 0;
            foreach (int i in indicesToRun)
            {
                if (_stop) { Log("⚠ Stopped by user.", Theme.Warning); break; }
                var job = _jobs[i]; job.Status = "Running"; job.Error = ""; UpdateJobRow(i);
                Log($"\n[{completedCount + 1}/{indicesToRun.Count}] {job.JobName}", Color.FromArgb(80, 180, 255));
                try
                {
                    await System.Threading.Tasks.Task.Run(() => {
                        var entries = EupConverter.Scan(job.SourceFolder);
                        string jobOut = System.IO.Path.Combine(outRoot, job.JobName + "_SP");
                        bool cancel = false;
                        EupConverter.Execute(entries, jobOut, true, (done, name) => { }, ref cancel);
                        // Detect and build DLC
                        var kind = DetectKind(jobOut);
                        if (kind == "vehicle")
                        {
                            var (vehicles, meta) = VehicleDlcBuilder.Scan(jobOut);
                            if (vehicles.Count > 0)
                            {
                                var settings = new VehicleDlcBuildSettings { DlcName = job.JobName.ToLowerInvariant().Replace(" ", "_"), OutputRoot = outRoot, Vehicles = vehicles, MetaFiles = meta };
                                VehicleDlcBuilder.Build(settings, jobOut);
                            }
                        }
                        Log($"  ✔ {job.JobName} → {jobOut}", Color.FromArgb(100, 200, 100));
                    });
                    job.Status = "Done"; ok++;
                }
                catch (Exception ex) { job.Status = "Failed"; job.Error = ex.Message; fail++; Log($"  ✕ {job.JobName}: {ex.Message}", Theme.Danger); }
                UpdateJobRow(i);
                completedCount++;
                progressBar.Value = completedCount;
            }

            Log($"\n=== Done — {ok} succeeded, {fail} failed ===", Color.FromArgb(100, 200, 100));
            _running = false; btnRunAll.Enabled = true; btnStopAll.Enabled = false; _btnRetryFailed.Enabled = true;
            lblStatus.Text = $"Batch complete — {ok} OK, {fail} failed."; lblStatus.ForeColor = fail > 0 ? Theme.Danger : Theme.Success;
        }

        private static string DetectKind(string dir)
        {
            if (!System.IO.Directory.Exists(dir)) return "unknown";
            return System.IO.Directory.GetFiles(dir, "*.yft", System.IO.SearchOption.TopDirectoryOnly).Any() ? "vehicle"
                 : System.IO.Directory.GetFiles(dir, "*.ydd", System.IO.SearchOption.TopDirectoryOnly).Any() ? "clothing"
                 : "unknown";
        }

        private void UpdateJobRow(int idx)
        {
            if (InvokeRequired) { Invoke((Action)(() => UpdateJobRow(idx))); return; }
            if (idx >= jobList.Items.Count) return;
            var job = _jobs[idx]; var item = jobList.Items[idx];
            item.SubItems[1].Text = job.Status;
            item.ForeColor = job.Status == "Done" ? Theme.Success : job.Status == "Failed" ? Theme.Danger : job.Status == "Running" ? Theme.Warning : Theme.Muted;
        }
    }

    // =========================================================================
    //  Toolbox Panel
    //  15 utility cards — all support drag and drop where a file or folder
    //  input makes sense. Drag a file onto any card to auto-populate its
    //  input field and run the tool immediately.
    // =========================================================================

    internal class ToolboxPanel : UserControl
    {
        public ToolboxPanel()
        {
            this.BackColor = Theme.Background;
            Theme.ThemeChanged += () => { this.BackColor = Theme.Background; };
            Build();
        }

        private void Build()
        {
            var flow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                AutoScroll = true,
                Padding = new Padding(10),
            };
            this.Controls.Add(flow);

            // ── Row 1 — Hashing ───────────────────────────────────────────────
            flow.Controls.Add(MakeCard("🔢  Jenkins Hash",
                "Calculates the GTA V Jenkins one-at-a-time hash. Used for model names, audio bank names, texture names.",
                "String to hash:", "e.g. adder", false, (inp, out_) => {
                    if (string.IsNullOrWhiteSpace(inp)) { out_.Text = "Enter a string."; return; }
                    uint h = 0;
                    foreach (char c in inp.ToLowerInvariant()) { h += c; h += h << 10; h ^= h >> 6; }
                    h += h << 3; h ^= h >> 11; h += h << 15;
                    out_.Text = $"0x{h:X8}\n{h} (decimal)\n\nLower: {inp.ToLowerInvariant()}";
                    out_.ForeColor = Theme.Success;
                }));

            flow.Controls.Add(MakeCard("🔣  FNV-1a Hash",
                "FNV-1a 32-bit hash — used in some GTA V internals and audio rel files.",
                "String to hash:", "e.g. VEHICLE_METADATA_FILE", false, (inp, out_) => {
                    if (string.IsNullOrWhiteSpace(inp)) { out_.Text = "Enter a string."; return; }
                    uint h = 2166136261u;
                    foreach (char c in inp) { h ^= c; h *= 16777619u; }
                    out_.Text = $"0x{h:X8}\n{h} (decimal)";
                    out_.ForeColor = Theme.Success;
                }));

            flow.Controls.Add(MakeCard("🔤  Multi-Hash",
                "Calculates Jenkins, FNV-1a and DJB2 hashes together — useful when you're not sure which hash GTA uses.",
                "String:", "e.g. weapons.meta", false, (inp, out_) => {
                    if (string.IsNullOrWhiteSpace(inp)) { out_.Text = "Enter a string."; return; }
                    // Jenkins
                    uint j = 0; foreach (char c in inp.ToLowerInvariant()) { j += c; j += j << 10; j ^= j >> 6; }
                    j += j << 3; j ^= j >> 11; j += j << 15;
                    // FNV-1a
                    uint f = 2166136261u; foreach (char c in inp) { f ^= c; f *= 16777619u; }
                    // DJB2
                    uint d = 5381u; foreach (char c in inp) { d = ((d << 5) + d) ^ c; }
                    out_.Text = $"Jenkins: 0x{j:X8} ({j})\nFNV-1a:  0x{f:X8} ({f})\nDJB2:    0x{d:X8} ({d})";
                    out_.ForeColor = Theme.Success;
                }));

            // ── Row 2 — Validators ────────────────────────────────────────────
            flow.Controls.Add(MakeCard("✅  DLC Name Validator",
                "Validates a DLC name: lowercase, no spaces, no special chars, no Rockstar prefix conflicts.",
                "DLC name:", "e.g. lspd_pack_v2", false, (inp, out_) => {
                    var name = inp.Trim();
                    if (string.IsNullOrWhiteSpace(name)) { out_.Text = "Enter a name."; return; }
                    var issues = new List<string>();
                    if (name != name.ToLowerInvariant()) issues.Add("Must be lowercase");
                    if (name.Contains(' ')) issues.Add("No spaces allowed (use underscore)");
                    if (!System.Text.RegularExpressions.Regex.IsMatch(name, @"^[a-z0-9_]+$")) issues.Add("Only a-z, 0-9, _ allowed");
                    if (name.Length < 3) issues.Add("Too short (min 3 chars)");
                    if (name.Length > 32) issues.Add("Too long (max 32 chars)");
                    string[] rsv = { "mp", "dlc_patch", "core", "common", "update", "mpchristmas", "mphalloween", "mpluxe", "mpbusiness", "mpheist", "mpbeach", "mpbiker", "mpgunrunning", "mpsmuggler", "mpassault", "mpbattle", "mpvinewood", "mpchristmas2", "mpapartment", "mpadversary", "mpspecialraces", "mpstunt", "mpimportexport", "mplowrider", "mpchinese", "mpreplay", "mpcheats" };
                    foreach (var r in rsv) if (name == r || name.StartsWith(r + "_")) { issues.Add($"Conflicts with Rockstar prefix '{r}'"); break; }
                    out_.Text = issues.Count == 0
                        ? $"✔ '{name}' is a valid DLC name\ndlclist.xml entry:\n  <Item>dlcpacks:/{name}/</Item>"
                        : "✕ Issues found:\n• " + string.Join("\n• ", issues);
                    out_.ForeColor = issues.Count == 0 ? Theme.Success : Theme.Danger;
                }));

            flow.Controls.Add(MakeCard("🚗  Spawn Name Checker",
                "Checks a vehicle spawn name against 100+ vanilla GTA V vehicles to catch conflicts before you install.",
                "Spawn name:", "e.g. sheriff3", false, (inp, out_) => {
                    var name = inp.Trim().ToLowerInvariant();
                    if (string.IsNullOrWhiteSpace(name)) { out_.Text = "Enter a spawn name."; return; }
                    string[] vanilla = { "adder", "akula", "alkonost", "ardent", "baller", "banshee", "bati", "bifta", "blazer", "brickade", "buffalo", "buffalo2", "buffalo3", "bullet", "burrito", "buzzard", "caracara", "cheetah", "comet", "coquette", "crusader", "daemon", "dilettante", "dominator", "dubsta", "dukes", "elegy", "emperor", "entity", "fbi", "fbi2", "feltzer", "fugitive", "fusillade", "gauntlet", "granger", "gresley", "hauler", "hydra", "insurgent", "issi", "jackal", "jb700", "khanjali", "kuruma", "lazer", "mamba", "manana", "mesa", "minivan", "moonbeam", "mule", "nightshark", "oracle", "packer", "patriot", "phantom", "phoenix", "police", "police2", "police3", "police4", "policeb", "policeold1", "policeold2", "premier", "primo", "pranger", "rancherxl", "rapidgt", "reaper", "rhino", "riot", "riot2", "romero", "ruiner", "rumpo", "sabre", "sanchez", "schafter2", "sentinel", "sheriff", "sheriff2", "speedo", "stanier", "stratum", "sultan", "sultanrs", "super", "surfer", "swift", "t20", "taxi", "tempesta", "thruster", "towtruck", "trash", "turismo", "vagner", "vigero", "voodoo", "washington", "windsor", "zentorno" };
                    bool exact = vanilla.Contains(name);
                    bool partial = !exact && vanilla.Any(v => name.StartsWith(v) || v.StartsWith(name));
                    bool valid = System.Text.RegularExpressions.Regex.IsMatch(name, @"^[a-z][a-z0-9_]{1,29}$");
                    if (!valid) { out_.Text = "✕ Invalid format — use lowercase letters, digits, underscores only."; out_.ForeColor = Theme.Danger; }
                    else if (exact) { out_.Text = $"✕ '{name}' IS a vanilla GTA V vehicle.\nUse a prefix: mymod_{name}"; out_.ForeColor = Theme.Danger; }
                    else if (partial) { out_.Text = $"⚠ '{name}' is very similar to a vanilla name.\nConsider a more unique name."; out_.ForeColor = Theme.Warning; }
                    else { out_.Text = $"✔ '{name}' — no vanilla conflict found.\nSpawn: /car {name}"; out_.ForeColor = Theme.Success; }
                }));

            flow.Controls.Add(MakeCard("📋  dlclist.xml Entry Formatter",
                "Converts any DLC name into the correct dlclist.xml line — handles capitalisation and trailing slash automatically.",
                "DLC name or folder path:", "e.g. MyPoliceVehicle or C:\\mods\\...\\mymod", false, (inp, out_) => {
                    if (string.IsNullOrWhiteSpace(inp)) { out_.Text = "Enter a name or path."; return; }
                    string name = System.IO.Path.GetFileName(inp.Trim().TrimEnd('\\', '/'));
                    name = name.ToLowerInvariant();
                    name = System.Text.RegularExpressions.Regex.Replace(name, @"[^a-z0-9_]", "_");
                    out_.Text = $"Add to dlclist.xml:\n\n  <Item>dlcpacks:/{name}/</Item>\n\nNormalised name: {name}";
                    out_.ForeColor = Theme.Success;
                    Clipboard.SetText($"<Item>dlcpacks:/{name}/</Item>");
                }));

            // ── Row 3 — File tools (drag and drop) ───────────────────────────
            flow.Controls.Add(MakeCard("📐  File Size & VRAM Estimator",
                "Drag a .yft or .ytd file to estimate disk size and approximate VRAM usage at runtime.",
                "File path:", "drag .yft / .ytd here", true, (inp, out_) => {
                    var path = inp.Trim().Trim('"');
                    if (!System.IO.File.Exists(path)) { out_.Text = "File not found.\nDrop a .yft or .ytd file."; return; }
                    var info = new System.IO.FileInfo(path);
                    double diskMb = info.Length / 1_048_576.0;
                    double estVram = diskMb * 2.5;
                    string ext = info.Extension.ToLowerInvariant();
                    string budget = diskMb < 4 ? "✔ Good" : diskMb < 10 ? "⚠ Large" : "✕ Very large — may cause streaming issues";
                    out_.Text = $"File:     {info.Name}\nDisk:     {diskMb:F2} MB ({info.Length:N0} bytes)\nEst VRAM: ~{estVram:F2} MB\nBudget:   {budget}\nModified: {info.LastWriteTime:yyyy-MM-dd HH:mm}";
                    out_.ForeColor = diskMb < 4 ? Theme.Success : diskMb < 10 ? Theme.Warning : Theme.Danger;
                }));

            flow.Controls.Add(MakeCard("🗂  Folder File Counter",
                "Drag a mod folder to count files by extension — useful for checking a DLC pack is complete.",
                "Folder path:", "drag folder here", true, (inp, out_) => {
                    var path = inp.Trim().Trim('"');
                    if (!System.IO.Directory.Exists(path)) { out_.Text = "Folder not found.\nDrop a folder."; return; }
                    var files = System.IO.Directory.GetFiles(path, "*.*", System.IO.SearchOption.AllDirectories);
                    var byExt = files.GroupBy(f => System.IO.Path.GetExtension(f).ToLowerInvariant()).OrderByDescending(g => g.Count()).ToDictionary(g => g.Key, g => g.Count());
                    long total = files.Sum(f => { try { return new System.IO.FileInfo(f).Length; } catch { return 0; } });
                    var sb = new System.Text.StringBuilder();
                    sb.AppendLine($"Total files: {files.Length}   Size: {total / 1_048_576.0:F1} MB");
                    sb.AppendLine();
                    foreach (var kvp in byExt.Take(12)) sb.AppendLine($"  {kvp.Key,-12} {kvp.Value,4} file(s)");
                    if (byExt.Count > 12) sb.AppendLine($"  ... and {byExt.Count - 12} more extension(s)");
                    out_.Text = sb.ToString().TrimEnd();
                    out_.ForeColor = Theme.Text;
                }));

            flow.Controls.Add(MakeCard("🔍  Duplicate File Finder",
                "Drag a folder to find files with the same name appearing in multiple subfolders — catches texture/meta conflicts.",
                "Folder path:", "drag folder here", true, (inp, out_) => {
                    var path = inp.Trim().Trim('"');
                    if (!System.IO.Directory.Exists(path)) { out_.Text = "Folder not found."; return; }
                    var files = System.IO.Directory.GetFiles(path, "*.*", System.IO.SearchOption.AllDirectories);
                    var dups = files.GroupBy(f => System.IO.Path.GetFileName(f), StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1).OrderByDescending(g => g.Count()).ToList();
                    if (dups.Count == 0) { out_.Text = "✔ No duplicate filenames found."; out_.ForeColor = Theme.Success; return; }
                    var sb = new System.Text.StringBuilder();
                    sb.AppendLine($"⚠ {dups.Count} duplicate filename(s):\n");
                    foreach (var g in dups.Take(8)) { sb.AppendLine($"  {g.Key} ({g.Count()}×)"); foreach (var f in g) sb.AppendLine($"    {f.Replace(path, "").TrimStart('\\', ' ')}"); }
                    if (dups.Count > 8) sb.AppendLine($"\n  ...and {dups.Count - 8} more.");
                    out_.Text = sb.ToString().TrimEnd();
                    out_.ForeColor = Theme.Warning;
                }));

            // ── Row 4 — Converters ────────────────────────────────────────────
            flow.Controls.Add(MakeCard("🎨  Colour Converter",
                "Convert between RGB, hex, and GTA carcols.meta RGBA format (0–255 integers). Drag a hex colour from any app.",
                "Colour (hex or R,G,B):", "#FF5500 or 255,85,0", false, (inp, out_) => {
                    inp = inp.Trim();
                    int r = 0, g = 0, b = 0;
                    bool ok = false;
                    if (inp.StartsWith("#")) { try { var c = System.Drawing.ColorTranslator.FromHtml(inp); r = c.R; g = c.G; b = c.B; ok = true; } catch { } }
                    else { var parts = inp.Split(','); if (parts.Length >= 3 && int.TryParse(parts[0].Trim(), out r) && int.TryParse(parts[1].Trim(), out g) && int.TryParse(parts[2].Trim(), out b)) ok = true; }
                    if (!ok) { out_.Text = "Enter #RRGGBB or R,G,B"; out_.ForeColor = Theme.Danger; return; }
                    r = Math.Max(0, Math.Min(255, r)); g = Math.Max(0, Math.Min(255, g)); b = Math.Max(0, Math.Min(255, b));
                    out_.Text = $"Hex:       #{r:X2}{g:X2}{b:X2}\nRGB:       {r}, {g}, {b}\ncarcols:   <r value=\"{r}\" /> <g value=\"{g}\" /> <b value=\"{b}\" />\nFloat:     {r / 255f:F3}, {g / 255f:F3}, {b / 255f:F3}";
                    out_.ForeColor = Theme.Success;
                }));

            flow.Controls.Add(MakeCard("🔢  Hex ↔ Decimal",
                "Convert between hexadecimal and decimal — handy for GTA hash values, flags, and model IDs.",
                "Value:", "0x1A2B3C or 1715004", false, (inp, out_) => {
                    inp = inp.Trim();
                    if (string.IsNullOrWhiteSpace(inp)) { out_.Text = "Enter a value."; return; }
                    try
                    {
                        long val;
                        if (inp.StartsWith("0x", StringComparison.OrdinalIgnoreCase) || inp.StartsWith("&H", StringComparison.OrdinalIgnoreCase))
                            val = Convert.ToInt64(inp.Substring(2), 16);
                        else if (inp.All(c => "0123456789abcdefABCDEF".Contains(c)) && inp.Length > 6)
                            val = Convert.ToInt64(inp, 16);
                        else
                            val = long.Parse(inp);
                        out_.Text = $"Decimal:  {val}\nHex:      0x{val:X8}\nBinary:   {Convert.ToString(val, 2).PadLeft(32, '0')}\nUInt32:   {(uint)val}";
                        out_.ForeColor = Theme.Success;
                    }
                    catch { out_.Text = "Invalid value."; out_.ForeColor = Theme.Danger; }
                }));

            flow.Controls.Add(MakeCard("🏷️  Vehicle Class Reference",
                "Look up what GTA V vehicle class number maps to — essential for handling.meta and content.xml.",
                "Class number (0-23):", "e.g. 18", false, (inp, out_) => {
                    string[] classes = { "Compact", "Sedan", "SUV", "Coupe", "Muscle", "Sports Classic", "Sports", "Super", "Motorcycle", "Off-road", "Industrial", "Utility", "Van", "Cycles", "Boats", "Helicopters", "Planes", "Service", "Emergency", "Military", "Commercial", "Trains", "Open Wheel", "Sedans (alt)" };
                    if (string.IsNullOrWhiteSpace(inp))
                    {
                        var sb2 = new System.Text.StringBuilder();
                        for (int i = 0; i < classes.Length; i++) sb2.AppendLine($"  {i,2} — {classes[i]}");
                        out_.Text = sb2.ToString().TrimEnd(); out_.ForeColor = Theme.Text; return;
                    }
                    if (int.TryParse(inp.Trim(), out int idx) && idx >= 0 && idx < classes.Length)
                        out_.Text = $"Class {idx}: {classes[idx]}\n\nUse in handling.meta:\n  <vehicleClass>VC_{classes[idx].ToUpperInvariant().Replace(' ', '_').Replace('-', '_')}</vehicleClass>";
                    else out_.Text = $"Enter a number 0–{classes.Length - 1}, or leave blank for full list.";
                    out_.ForeColor = Theme.Success;
                }));

            // ── Row 5 — Generators ────────────────────────────────────────────
            flow.Controls.Add(MakeCard("🎲  DLC Name Generator",
                "Generates safe, unique DLC names combining a theme, a role word and a random suffix.",
                "Theme (optional):", "e.g. police, fire, swat", false, (inp, out_) => {
                    string[] words = { "unit", "squad", "pack", "fleet", "division", "force", "corps", "task", "group", "patrol", "response", "special", "elite", "tactical", "rapid", "heavy", "armoured", "swift", "covert", "pursuit" };
                    string[] prefixes = { "lspd", "bcso", "sahp", "lasd", "sfpd", "ems", "fire", "swat", "fib", "cia", "doj", "mors", "lsfd", "usmc", "army", "navy", "noose" };
                    var rng = new Random(DateTime.Now.Millisecond);
                    string theme = string.IsNullOrWhiteSpace(inp) ? prefixes[rng.Next(prefixes.Length)] : inp.Trim().ToLowerInvariant().Replace(" ", "_");
                    var names = Enumerable.Range(0, 4).Select(_ => $"{theme}_{words[rng.Next(words.Length)]}_{rng.Next(10, 999):D3}").ToList();
                    out_.Text = "Suggestions:\n\n" + string.Join("\n", names.Select(n => "  " + n)) + "\n\nClick Run for more.";
                    out_.ForeColor = Theme.Success;
                    Clipboard.SetText(names[0]);
                }));

            flow.Controls.Add(MakeCard("🚘  Random Plate Generator",
                "Generates GTA-style number plates. Optionally specify a 2-letter state prefix.",
                "State prefix (optional):", "e.g. LS or LV or SF", false, (inp, out_) => {
                    var rng = new Random(DateTime.Now.Millisecond);
                    string state = (string.IsNullOrWhiteSpace(inp) ? new[] { "LS", "LV", "SF", "BC" }[rng.Next(4)] : inp.Trim().ToUpper().Substring(0, Math.Min(2, inp.Trim().Length)));
                    const string digits = "0123456789"; const string letters = "ABCDEFGHJKLMNPRSTUVWXYZ";
                    var plates = Enumerable.Range(0, 5).Select(_ => $"{state}{new string(Enumerable.Range(0, 3).Select(__ => digits[rng.Next(digits.Length)]).ToArray())}{new string(Enumerable.Range(0, 3).Select(__ => letters[rng.Next(letters.Length)]).ToArray())}").ToList();
                    out_.Text = "Generated plates:\n\n" + string.Join("\n", plates.Select(p => "  " + p));
                    out_.ForeColor = Theme.Success;
                }));

            flow.Controls.Add(MakeCard("📋  Clipboard XML Formatter",
                "Paste XML from clipboard, re-indent it cleanly, and copy it back — works on meta files, content.xml, etc.",
                "(no input needed)", "click Run to format clipboard contents", false, (inp, out_) => {
                    try
                    {
                        var xml = Clipboard.GetText();
                        if (string.IsNullOrWhiteSpace(xml)) { out_.Text = "Clipboard is empty."; return; }
                        var doc = new System.Xml.XmlDocument(); doc.LoadXml(xml);
                        var sw = new System.IO.StringWriter();
                        using (var xw = System.Xml.XmlWriter.Create(sw, new System.Xml.XmlWriterSettings { Indent = true, IndentChars = "  ", NewLineChars = "\r\n" })) doc.Save(xw);
                        Clipboard.SetText(sw.ToString());
                        out_.Text = $"✔ Formatted and copied to clipboard.\n{sw.ToString().Split('\n').Length} lines.";
                        out_.ForeColor = Theme.Success;
                    }
                    catch (Exception ex) { out_.Text = "Failed (invalid XML?):\n" + ex.Message; out_.ForeColor = Theme.Danger; }
                }));

            flow.Controls.Add(MakeCard("⏰  Timestamp Generator",
                "Generates timestamps in GTA DLC formats: setup2.xml, backup suffixes, and ISO-8601.",
                "(no input needed)", "click Run for current time", false, (inp, out_) => {
                    var now = DateTime.Now;
                    out_.Text =
                        $"setup2.xml:   {now:MM/dd/yyyy HH:mm:ss}\n" +
                        $"Backup suffix: {now:yyyyMMdd_HHmmss}\n" +
                        $"ISO-8601:      {now:yyyy-MM-ddTHH:mm:ss}\n" +
                        $"Unix epoch:    {DateTimeOffset.UtcNow.ToUnixTimeSeconds()}\n" +
                        $"Short date:    {now:yyyyMMdd}";
                    out_.ForeColor = Theme.Success;
                    Clipboard.SetText(now.ToString("MM/dd/yyyy HH:mm:ss"));
                }));

            // ── Row 6 — Grounded in this project's own history ──────────────────
            flow.Controls.Add(MakeCard("🧪  dlclist.xml Validator",
                "Drag a dlclist.xml file to check it's well-formed and count entries — catches the exact " +
                "truncated-tail corruption pattern this project's Backup/Restore tooling exists to recover from.",
                "File path:", "drag dlclist.xml here", true, (inp, out_) => {
                    var path = inp.Trim().Trim('"');
                    if (!System.IO.File.Exists(path)) { out_.Text = "File not found.\nDrop a dlclist.xml file."; return; }
                    string xml;
                    try { xml = System.IO.File.ReadAllText(path); }
                    catch (Exception ex) { out_.Text = "Couldn't read file:\n" + ex.Message; out_.ForeColor = Theme.Danger; return; }

                    bool hasRoot = xml.Contains("<SMandatoryPacksData>") && xml.Contains("</SMandatoryPacksData>");
                    bool hasPaths = xml.Contains("<Paths>") && xml.Contains("</Paths>");
                    int entryCount = System.Text.RegularExpressions.Regex.Matches(xml, "<Item>").Count;
                    int closedCount = System.Text.RegularExpressions.Regex.Matches(xml, "</Item>").Count;

                    if (hasRoot && hasPaths && entryCount == closedCount && entryCount > 0)
                    {
                        out_.Text = $"✔ Well-formed.\n{entryCount} entries.\nSafe to use.";
                        out_.ForeColor = Theme.Success;
                    }
                    else
                    {
                        var issues = new List<string>();
                        if (!hasRoot) issues.Add("Missing/unclosed <SMandatoryPacksData>");
                        if (!hasPaths) issues.Add("Missing/unclosed <Paths>");
                        if (entryCount != closedCount) issues.Add($"{entryCount} <Item> tags but only {closedCount} </Item> — looks truncated");
                        if (entryCount == 0) issues.Add("No <Item> entries found at all");
                        out_.Text = "✕ Problem(s) found:\n• " + string.Join("\n• ", issues) +
                                     "\n\nSee this project's Backup Manager page to restore a known-good copy.";
                        out_.ForeColor = Theme.Danger;
                    }
                }));

            flow.Controls.Add(MakeCard("🚗  vehicles.meta Spawn Names",
                "Drag a vehicles.meta file (or an addon folder containing one) to list every spawn name it defines.",
                "Path:", "drag vehicles.meta or a folder", true, (inp, out_) => {
                    var path = inp.Trim().Trim('"');
                    string metaPath = path;
                    if (System.IO.Directory.Exists(path))
                    {
                        var found = System.IO.Directory.GetFiles(path, "vehicles.meta", System.IO.SearchOption.AllDirectories).FirstOrDefault();
                        if (found == null) { out_.Text = "No vehicles.meta found under that folder."; out_.ForeColor = Theme.Danger; return; }
                        metaPath = found;
                    }
                    else if (!System.IO.File.Exists(metaPath))
                    {
                        out_.Text = "File/folder not found."; out_.ForeColor = Theme.Danger; return;
                    }

                    string xml;
                    try { xml = System.IO.File.ReadAllText(metaPath); }
                    catch (Exception ex) { out_.Text = "Couldn't read file:\n" + ex.Message; out_.ForeColor = Theme.Danger; return; }

                    var names = System.Text.RegularExpressions.Regex.Matches(xml, @"<modelName>\s*([A-Za-z0-9_]+)\s*</modelName>")
                        .Select(m => m.Groups[1].Value).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

                    if (names.Count == 0) { out_.Text = "No <modelName> entries found."; out_.ForeColor = Theme.Warning; return; }
                    out_.Text = $"{names.Count} spawn name(s):\n\n" + string.Join("\n", names.Select(n => "  " + n));
                    out_.ForeColor = Theme.Success;
                    Clipboard.SetText(string.Join(", ", names));
                }));

            flow.Controls.Add(MakeCard("🩹  Unclosed XML Tag Repair",
                "Paste or drag XML with missing closing tags (e.g. a truncated dlclist.xml) — appends whatever's " +
                "needed to close every still-open tag, in the correct nested order. Best-effort: verify the result.",
                "File path (or leave blank to use clipboard):", "drag a file, or paste text into clipboard first", true, (inp, out_) => {
                    string xml;
                    var path = inp.Trim().Trim('"');
                    if (System.IO.File.Exists(path)) { try { xml = System.IO.File.ReadAllText(path); } catch (Exception ex) { out_.Text = "Couldn't read file:\n" + ex.Message; out_.ForeColor = Theme.Danger; return; } }
                    else { xml = Clipboard.GetText(); }

                    if (string.IsNullOrWhiteSpace(xml)) { out_.Text = "Nothing to repair — drop a file or copy XML to clipboard first."; return; }

                    // Simple stack-based tag tracker — ignores self-closing
                    // tags (<x/>) and the XML declaration, pushes on open
                    // tags, pops on matching close tags, then emits closing
                    // tags for whatever's left open, innermost first.
                    var stack = new List<string>();
                    foreach (System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(xml, @"<(/?)([A-Za-z0-9_:.-]+)([^>]*?)(/?)>"))
                    {
                        bool isClose = m.Groups[1].Value == "/";
                        bool isSelfClose = m.Groups[4].Value == "/";
                        string tag = m.Groups[2].Value;
                        if (tag.StartsWith("?") || tag.StartsWith("!")) continue;
                        if (isSelfClose) continue;
                        if (isClose) { if (stack.Count > 0 && stack[^1] == tag) stack.RemoveAt(stack.Count - 1); }
                        else stack.Add(tag);
                    }

                    if (stack.Count == 0) { out_.Text = "✔ No unclosed tags found — nothing to repair."; out_.ForeColor = Theme.Success; return; }

                    var closer = new System.Text.StringBuilder();
                    for (int i = stack.Count - 1; i >= 0; i--) closer.Append($"</{stack[i]}>");
                    string repaired = xml.TrimEnd() + "\n" + closer;

                    Clipboard.SetText(repaired);
                    out_.Text = $"Found {stack.Count} unclosed tag(s): {string.Join(", ", stack)}\n\n" +
                                 "Repaired version copied to clipboard — review it before saving over anything.";
                    out_.ForeColor = Theme.Warning;
                }));
        }

        // ──────────────────────────────────────────────────────────────────────
        // Card factory — acceptsDrop wires up full drag-and-drop support so
        // dropping a file onto any part of the card populates the input and
        // runs the action automatically.
        // ──────────────────────────────────────────────────────────────────────
        private Panel MakeCard(string title, string description, string inputLabel,
            string placeholder, bool acceptsDrop, Action<string, RichTextBox> action)
        {
            var card = new Panel
            {
                Width = 315,
                Height = 225,
                BackColor = Theme.Surface,
                Margin = new Padding(7),
                Padding = new Padding(0),
                AllowDrop = acceptsDrop,
            };
            card.Paint += (s, e) =>
            {
                using var pen = new Pen(Theme.Border);
                e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
            };

            var lblTitle = new Label
            {
                Text = title,
                AutoSize = false,
                Width = 291,
                Height = 22,
                Location = new Point(12, 10),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Theme.Accent,
            };
            var lblDesc = new Label
            {
                Text = description,
                AutoSize = false,
                Width = 291,
                Height = 40,
                Location = new Point(12, 34),
                Font = new Font("Segoe UI", 7.5f),
                ForeColor = Theme.Muted,
            };
            var lblInp = new Label
            {
                Text = inputLabel,
                AutoSize = true,
                Location = new Point(12, 80),
                Font = new Font("Segoe UI", 7.5f),
                ForeColor = Theme.Muted,
            };
            var txtInput = new TextBox
            {
                Location = new Point(12, 96),
                Width = 215,
                BackColor = Theme.Background,
                ForeColor = Theme.Text,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 8.5f),
                PlaceholderText = placeholder,
                AllowDrop = acceptsDrop,
            };
            var btnRun = new Button
            {
                Text = "▶ Run",
                Location = new Point(233, 95),
                Width = 70,
                Height = 24,
                BackColor = Theme.Accent,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8.5f),
            };
            btnRun.FlatAppearance.BorderSize = 0;

            var output = new RichTextBox
            {
                Location = new Point(12, 126),
                Width = 291,
                Height = 85,
                BackColor = Color.FromArgb(20, 20, 20),
                ForeColor = Color.FromArgb(210, 210, 210),
                Font = new Font("Consolas", 8f),
                BorderStyle = BorderStyle.None,
                ReadOnly = true,
                AllowDrop = acceptsDrop,
            };

            // Drop indicator strip at bottom of card (shown while dragging over it)
            var dropStrip = new Panel
            {
                Location = new Point(0, card.Height - 4),
                Width = card.Width,
                Height = 4,
                BackColor = Theme.Accent,
                Visible = false,
            };

            card.Controls.AddRange(new Control[] { lblTitle, lblDesc, lblInp, txtInput, btnRun, output, dropStrip });

            // ── Event wiring ─────────────────────────────────────────────────
            btnRun.Click += (s, e) => action(txtInput.Text, output);
            txtInput.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; action(txtInput.Text, output); } };

            if (acceptsDrop)
            {
                DragEventHandler onEnter = (s, e) =>
                {
                    if (e.Data.GetDataPresent(DataFormats.FileDrop))
                    { e.Effect = DragDropEffects.Copy; dropStrip.Visible = true; card.BackColor = Color.FromArgb(50, 55, 65); }
                };
                DragEventHandler onDrop = (s, e) =>
                {
                    dropStrip.Visible = false; card.BackColor = Theme.Surface;
                    if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;
                    var paths = (string[])e.Data.GetData(DataFormats.FileDrop);
                    if (paths == null || paths.Length == 0) return;
                    txtInput.Text = paths[0];
                    action(txtInput.Text, output);
                };
                DragEventHandler onOver = (s, e) =>
                {
                    if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;
                };
                EventHandler onLeave = (s, e) => { dropStrip.Visible = false; card.BackColor = Theme.Surface; };

                foreach (Control c in new Control[] { card, txtInput, output })
                {
                    c.DragEnter += onEnter;
                    c.DragDrop += onDrop;
                    c.DragOver += onOver;
                    c.DragLeave += onLeave;
                }
            }

            return card;
        }
    }



    // =========================================================================
    //  Stream Budget Analyzer
    //  Scans a DLC pack folder tree, estimates streaming memory per file,
    //  totals by category and flags files that exceed recommended budgets.
    // =========================================================================
    internal class StreamBudgetPanel : UserControl
    {
        private Button btnScan, btnExport, btnOpenFolder;
        private TextBox txtRoot, txtTotalBudget;
        private ListView list;
        private Label lblTotal, lblStatus, lblBudgetResult;
        private Panel summaryBar, _budgetBar, _budgetBarFill;

        // Approximate decompression multipliers by extension
        private static readonly Dictionary<string, double> Multipliers = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
        {
            {".yft",3.2},{".ytd",2.8},{".ydd",3.0},{".ycd",2.5},{".ybn",1.8},
            {".ymap",1.5},{".ytyp",1.5},{".ymf",1.2},{".awc",1.1},{".rel",1.1},
        };
        private static readonly Dictionary<string, long> Budgets = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase)
        {
            {".yft",15_000_000},{".ytd",20_000_000},{".ydd",12_000_000},
            {".ycd",8_000_000},{".ybn",5_000_000},
        };

        public StreamBudgetPanel()
        {
            this.BackColor = Theme.Background;
            this.AllowDrop = true;
            this.DragEnter += (s, e) => e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
            this.DragDrop += (s, e) => { var p = ((string[])e.Data.GetData(DataFormats.FileDrop))[0]; txtRoot.Text = p; Scan(p); };
            Theme.ThemeChanged += () => { this.BackColor = Theme.Background; if (list != null) { list.BackColor = Theme.ListBg; list.ForeColor = Theme.Text; } };
            Build();
        }

        private Button Btn(string t, int w, Color? bg = null) { var b = new Button { Text = t, Width = w, Height = 26, BackColor = bg ?? Theme.Surface, ForeColor = bg.HasValue ? Color.White : Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 56, BackColor = Theme.Surface };
            top.Controls.Add(new Label { Text = "DLC folder or pack root:", AutoSize = true, Location = new Point(12, 14), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) });
            txtRoot = new TextBox { Location = new Point(170, 11), Width = 460, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f), PlaceholderText = "Drag a DLC folder here or browse…" };
            top.Controls.Add(txtRoot);
            var btnBrowse = Btn("Browse…", 74); btnBrowse.Location = new Point(638, 10); btnBrowse.Click += (s, e) => { using var d = new FolderBrowserDialog { Description = "Select DLC or mod folder" }; if (d.ShowDialog() == DialogResult.OK) { txtRoot.Text = d.SelectedPath; Scan(d.SelectedPath); } };
            btnScan = Btn("🔍 Scan", 80, Theme.Accent); btnScan.Location = new Point(720, 10); btnScan.Click += (s, e) => Scan(txtRoot.Text.Trim());
            btnExport = Btn("📋 Export CSV", 100); btnExport.Location = new Point(808, 10); btnExport.Enabled = false; btnExport.Click += ExportCsv;
            top.Controls.Add(new Label { Text = "Total budget (MB):", AutoSize = true, Location = new Point(918, 14), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) });
            txtTotalBudget = new TextBox { Location = new Point(1040, 11), Width = 60, Text = "1536", BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f) };
            txtTotalBudget.TextChanged += (s, e) => UpdateBudgetBar();
            top.Controls.AddRange(new Control[] { btnBrowse, btnScan, btnExport, txtTotalBudget });

            summaryBar = new Panel { Dock = DockStyle.Top, Height = 30, BackColor = Color.FromArgb(22, 22, 22) };
            lblTotal = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f), Text = "Drop a DLC folder to analyse streaming memory usage." };
            summaryBar.Controls.Add(lblTotal);

            // ── Total-budget visual bar — the aggregate estimated VRAM
            //    across the whole scan against a configurable target, since
            //    a pack can pass every individual per-file budget check and
            //    still be far too large in total for a reasonable mod list. ──
            var budgetRow = new Panel { Dock = DockStyle.Top, Height = 26, BackColor = Theme.Surface, Padding = new Padding(12, 4, 12, 4) };
            _budgetBar = new Panel { Location = new Point(0, 4), Width = 400, Height = 14, BackColor = Theme.Background };
            _budgetBarFill = new Panel { Location = new Point(0, 0), Width = 0, Height = 14, BackColor = Theme.Success };
            _budgetBar.Controls.Add(_budgetBarFill);
            lblBudgetResult = new Label { Location = new Point(410, 3), AutoSize = true, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            budgetRow.Controls.Add(_budgetBar);
            budgetRow.Controls.Add(lblBudgetResult);

            list = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, Font = new Font("Consolas", 8f), BackColor = Theme.ListBg, ForeColor = Theme.Text, BorderStyle = BorderStyle.None };
            list.Columns.Add("File", 340); list.Columns.Add("Ext", 55); list.Columns.Add("Disk Size", 90); list.Columns.Add("Est. VRAM", 90); list.Columns.Add("Budget", 80); list.Columns.Add("Subfolder", 260);
            list.ColumnClick += (s, e) => SortList(e.Column);
            list.DoubleClick += (s, e) => OpenSelectedFolder();
            list.MouseUp += (s, e) =>
            {
                if (e.Button != MouseButtons.Right || list.SelectedItems.Count == 0) return;
                var menu = new ContextMenuStrip();
                menu.Items.Add("📂 Open Containing Folder", null, (s2, e2) => OpenSelectedFolder());
                menu.Items.Add("📋 Copy Path", null, (s2, e2) =>
                {
                    if (list.SelectedItems[0].Tag is ValueTuple<string, string, long, long, bool, string> r) Clipboard.SetText(r.Item1);
                });
                menu.Show(list, e.Location);
            };

            var btm = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = Theme.Surface };
            lblStatus = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            btm.Controls.Add(lblStatus);
            btnOpenFolder = Btn("📂 Open", 70); btnOpenFolder.Dock = DockStyle.Right; btnOpenFolder.Click += (s, e) => { if (System.IO.Directory.Exists(txtRoot.Text)) System.Diagnostics.Process.Start("explorer.exe", txtRoot.Text); };
            btm.Controls.Add(btnOpenFolder);

            this.Controls.Add(list); this.Controls.Add(budgetRow); this.Controls.Add(summaryBar); this.Controls.Add(btm); this.Controls.Add(top);
        }

        private void OpenSelectedFolder()
        {
            if (list.SelectedItems.Count == 0) return;
            if (list.SelectedItems[0].Tag is ValueTuple<string, string, long, long, bool, string> r && System.IO.File.Exists(r.Item1))
                System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{r.Item1}\"");
        }

        private void UpdateBudgetBar()
        {
            if (!int.TryParse(txtTotalBudget.Text.Trim(), out int budgetMb) || budgetMb <= 0) { lblBudgetResult.Text = "Enter a valid MB target."; return; }
            long totalVram = _rows.Sum(r => r.vram);
            double totalMb = totalVram / 1_048_576.0;
            double pct = Math.Min(1.5, totalMb / budgetMb); // cap fill at 150% so it doesn't overflow the bar wildly

            _budgetBarFill.Width = (int)(_budgetBar.Width * Math.Min(1.0, pct));
            _budgetBarFill.BackColor = totalMb > budgetMb ? Theme.Danger : totalMb > budgetMb * 0.8 ? Theme.Warning : Theme.Success;

            lblBudgetResult.Text = totalMb > budgetMb
                ? $"{totalMb:F0} MB / {budgetMb} MB  —  ⚠ OVER by {totalMb - budgetMb:F0} MB"
                : $"{totalMb:F0} MB / {budgetMb} MB  —  {budgetMb - totalMb:F0} MB headroom";
            lblBudgetResult.ForeColor = totalMb > budgetMb ? Theme.Danger : Theme.Success;
        }

        private List<(string path, string ext, long disk, long vram, bool overBudget, string sub)> _rows = new();

        private void Scan(string root)
        {
            if (!System.IO.Directory.Exists(root)) { lblStatus.Text = "Folder not found."; lblStatus.ForeColor = Theme.Danger; return; }
            _rows.Clear(); list.BeginUpdate(); list.Items.Clear();
            var files = System.IO.Directory.GetFiles(root, "*.*", System.IO.SearchOption.AllDirectories)
                .Where(f => Multipliers.ContainsKey(System.IO.Path.GetExtension(f))).OrderBy(f => f).ToList();
            long totalDisk = 0, totalVram = 0; int over = 0;
            foreach (var f in files)
            {
                var ext = System.IO.Path.GetExtension(f);
                long disk = new System.IO.FileInfo(f).Length;
                long vram = (long)(disk * Multipliers[ext]);
                bool overBudget = Budgets.TryGetValue(ext, out long bud) && vram > bud;
                string sub = f.Replace(root, "").TrimStart('\\', '/'); sub = System.IO.Path.GetDirectoryName(sub) ?? "";
                _rows.Add((f, ext, disk, vram, overBudget, sub));
                totalDisk += disk; totalVram += vram; if (overBudget) over++;
            }
            foreach (var r in _rows)
            {
                var item = new ListViewItem(System.IO.Path.GetFileName(r.path));
                item.SubItems.Add(r.ext);
                item.SubItems.Add(Mb(r.disk));
                item.SubItems.Add(Mb(r.vram));
                item.SubItems.Add(r.overBudget ? "⚠ OVER" : "✔ OK");
                item.SubItems.Add(r.sub);
                item.ForeColor = r.overBudget ? Theme.Danger : r.vram > 5_000_000 ? Theme.Warning : Theme.Text;
                item.Tag = r;
                list.Items.Add(item);
            }
            list.EndUpdate();
            string warn = over > 0 ? $"  ⚠ {over} file(s) over individual budget" : "";
            lblTotal.Text = $"Files: {_rows.Count}   Disk: {Mb(totalDisk)}   Est. VRAM: {Mb(totalVram)}{warn}";
            lblTotal.ForeColor = over > 0 ? Theme.Warning : Theme.Success;
            lblStatus.Text = $"Scanned {_rows.Count} streamable files in {root}"; lblStatus.ForeColor = Theme.Success;
            btnExport.Enabled = _rows.Count > 0;
            UpdateBudgetBar();
        }

        private static string Mb(long b) => b >= 1_048_576 ? $"{b / 1_048_576.0:F1} MB" : b >= 1024 ? $"{b / 1024.0:F0} KB" : $"{b} B";

        private int _sortCol = -1; private bool _sortAsc = true;
        private void SortList(int col)
        {
            if (_sortCol == col) _sortAsc = !_sortAsc; else { _sortCol = col; _sortAsc = true; }
            _rows.Sort((a, b) => {
                int r = col == 0 ? string.Compare(System.IO.Path.GetFileName(a.path), System.IO.Path.GetFileName(b.path)) :
                      col == 1 ? string.Compare(a.ext, b.ext) : col == 2 ? a.disk.CompareTo(b.disk) :
                      col == 3 ? a.vram.CompareTo(b.vram) : col == 4 ? a.overBudget.CompareTo(b.overBudget) : string.Compare(a.sub, b.sub);
                return _sortAsc ? r : -r;
            });
            list.BeginUpdate(); list.Items.Clear();
            foreach (var r in _rows)
            {
                var item = new ListViewItem(System.IO.Path.GetFileName(r.path));
                item.SubItems.Add(r.ext); item.SubItems.Add(Mb(r.disk)); item.SubItems.Add(Mb(r.vram));
                item.SubItems.Add(r.overBudget ? "⚠ OVER" : "✔ OK"); item.SubItems.Add(r.sub);
                item.ForeColor = r.overBudget ? Theme.Danger : r.vram > 5_000_000 ? Theme.Warning : Theme.Text;
                list.Items.Add(item);
            }
            list.EndUpdate();
        }

        private void ExportCsv(object sender, EventArgs e)
        {
            using var d = new SaveFileDialog { Filter = "CSV|*.csv", FileName = "stream_budget.csv" };
            if (d.ShowDialog() != DialogResult.OK) return;
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("File,Extension,DiskMB,EstVRAM_MB,OverBudget,Subfolder");
            foreach (var r in _rows) sb.AppendLine($"\"{System.IO.Path.GetFileName(r.path)}\",{r.ext},{r.disk / 1_048_576.0:F2},{r.vram / 1_048_576.0:F2},{r.overBudget},\"{r.sub}\"");
            System.IO.File.WriteAllText(d.FileName, sb.ToString(), System.Text.Encoding.UTF8);
            MessageBox.Show($"Exported {_rows.Count} rows.", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    // =========================================================================
    //  Conflict Detector
    //  Scans multiple DLC/mod folders, finds files with identical names across
    //  different packs (which causes one mod to silently override the other).
    // =========================================================================
    internal class ConflictDetectorPanel : UserControl
    {
        private Button btnAddFolders, btnScanAll, btnClear, btnExport, btnRemove;
        private ListView folderList, conflictList;
        private SplitContainer split;
        private Label lblStatus, lblSummary;

        private record FileRecord(string File, string DlcName, string FullPath, string Ext);
        private List<string> _folders = new();
        private List<(string fileName, List<FileRecord> sources)> _conflicts = new();

        public ConflictDetectorPanel()
        {
            this.BackColor = Theme.Background;
            this.AllowDrop = true;
            this.DragEnter += (s, e) => e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
            this.DragDrop += (s, e) => { foreach (var p in (string[])e.Data.GetData(DataFormats.FileDrop)) if (System.IO.Directory.Exists(p)) AddFolder(p); };
            Theme.ThemeChanged += () => { this.BackColor = Theme.Background; };
            Build();
        }

        private Button Btn(string t, int w, Color? bg = null) { var b = new Button { Text = t, Width = w, Height = 26, BackColor = bg ?? Theme.Surface, ForeColor = bg.HasValue ? Color.White : Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 56, BackColor = Theme.Surface };
            btnAddFolders = Btn("＋ Add Mod Folders", 140); btnAddFolders.Location = new Point(12, 14); btnAddFolders.Click += BtnAdd;
            btnRemove = Btn("✕ Remove", 78); btnRemove.Location = new Point(158, 14); btnRemove.Click += (s, e) => { if (folderList.SelectedIndices.Count > 0) { _folders.RemoveAt(folderList.SelectedIndices[0]); RebuildFolderList(); } };
            btnClear = Btn("✕ Clear All", 84); btnClear.Location = new Point(242, 14); btnClear.Click += (s, e) => { _folders.Clear(); RebuildFolderList(); _conflicts.Clear(); conflictList.Items.Clear(); };
            var btnGta = Btn("🔍 Auto-Add GTA dlcpacks", 180); btnGta.Location = new Point(334, 14); btnGta.Click += AutoAddGta;
            btnScanAll = Btn("⚡ Scan for Conflicts", 140, Theme.Accent); btnScanAll.Location = new Point(522, 14); btnScanAll.Click += (s, e) => ScanAll();
            btnExport = Btn("📋 Export", 80); btnExport.Location = new Point(668, 14); btnExport.Enabled = false; btnExport.Click += ExportReport;
            var btnCopy = Btn("📄 Copy List", 90); btnCopy.Location = new Point(754, 14); btnCopy.Click += CopyConflictsToClipboard;
            top.Controls.AddRange(new Control[] { btnAddFolders, btnRemove, btnClear, btnGta, btnScanAll, btnExport, btnCopy });

            var infoBar = new Panel { Dock = DockStyle.Top, Height = 28, BackColor = Color.FromArgb(22, 22, 22) };
            lblSummary = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f) };
            infoBar.Controls.Add(lblSummary);

            split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal, SplitterDistance = 140, BackColor = Theme.Background };
            folderList = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, Font = new Font("Consolas", 8f), BackColor = Theme.ListBg, ForeColor = Theme.Text, BorderStyle = BorderStyle.None };
            folderList.Columns.Add("Mod / DLC Folder", 380); folderList.Columns.Add("Files scanned", 100); folderList.Columns.Add("Path", 500);
            split.Panel1.Controls.Add(folderList);
            split.Panel1.Controls.Add(new Label { Text = "Folders to scan (drag folders here, or use + Add):", Dock = DockStyle.Top, Height = 22, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f), Padding = new Padding(4, 4, 0, 0) });

            conflictList = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, Font = new Font("Consolas", 8f), BackColor = Theme.ListBg, ForeColor = Theme.Text, BorderStyle = BorderStyle.None };
            conflictList.Columns.Add("Conflicting File", 280); conflictList.Columns.Add("Ext", 55); conflictList.Columns.Add("Found in DLC(s)", 600);
            conflictList.MouseUp += ConflictList_MouseUp;
            conflictList.DoubleClick += (s, e) =>
            {
                if (conflictList.SelectedItems.Count == 0) return;
                if (conflictList.SelectedItems[0].Tag is List<FileRecord> sources && sources.Count > 0)
                    OpenContainingFolder(sources[0].FullPath);
            };
            split.Panel2.Controls.Add(conflictList);
            split.Panel2.Controls.Add(new Label { Text = "Conflicts detected:", Dock = DockStyle.Top, Height = 22, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f), Padding = new Padding(4, 4, 0, 0) });

            var btm = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = Theme.Surface };
            lblStatus = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f), Text = "Add folders and click Scan for Conflicts." };
            btm.Controls.Add(lblStatus);

            this.Controls.Add(split); this.Controls.Add(btm); this.Controls.Add(infoBar); this.Controls.Add(top);
        }

        private void AddFolder(string path)
        {
            if (!_folders.Contains(path, StringComparer.OrdinalIgnoreCase))
            { _folders.Add(path); RebuildFolderList(); }
        }

        private void BtnAdd(object sender, EventArgs e)
        {
            using var d = new FolderBrowserDialog { Description = "Select a mod or DLC folder" };
            if (d.ShowDialog() == DialogResult.OK) AddFolder(d.SelectedPath);
        }

        private void AutoAddGta(object sender, EventArgs e)
        {
            string gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;
            var dlcpacksPath = System.IO.Path.Combine(gtaRoot, "mods", "update", "x64", "dlcpacks");
            if (!System.IO.Directory.Exists(dlcpacksPath)) { MessageBox.Show("dlcpacks folder not found.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            int added = 0;
            foreach (var d2 in System.IO.Directory.GetDirectories(dlcpacksPath)) { AddFolder(d2); added++; }
            lblStatus.Text = $"Added {added} DLC folders from {dlcpacksPath}";
        }

        private void RebuildFolderList()
        {
            folderList.BeginUpdate(); folderList.Items.Clear();
            foreach (var f in _folders)
            {
                int count = System.IO.Directory.Exists(f) ? System.IO.Directory.GetFiles(f, "*.*", System.IO.SearchOption.AllDirectories).Length : 0;
                var item = new ListViewItem(System.IO.Path.GetFileName(f));
                item.SubItems.Add(count.ToString()); item.SubItems.Add(f);
                folderList.Items.Add(item);
            }
            folderList.EndUpdate();
            lblSummary.Text = $"{_folders.Count} folder(s) queued.";
        }

        private void ScanAll()
        {
            _conflicts.Clear(); conflictList.Items.Clear();
            var allFiles = new Dictionary<string, List<FileRecord>>(StringComparer.OrdinalIgnoreCase);
            foreach (var folder in _folders)
            {
                if (!System.IO.Directory.Exists(folder)) continue;
                string dlcName = System.IO.Path.GetFileName(folder);
                foreach (var file in System.IO.Directory.GetFiles(folder, "*.*", System.IO.SearchOption.AllDirectories))
                {
                    string name = System.IO.Path.GetFileName(file);
                    string ext = System.IO.Path.GetExtension(file);
                    if (!allFiles.ContainsKey(name)) allFiles[name] = new List<FileRecord>();
                    allFiles[name].Add(new FileRecord(name, dlcName, file, ext));
                }
            }
            _conflicts = allFiles.Where(kvp => kvp.Value.Count > 1).OrderByDescending(kvp => kvp.Value.Count).Select(kvp => (kvp.Key, kvp.Value)).ToList();
            conflictList.BeginUpdate();
            foreach (var (name, sources) in _conflicts)
            {
                var item = new ListViewItem(name);
                item.SubItems.Add(sources[0].Ext);
                item.SubItems.Add(string.Join(" | ", sources.Select(s => s.DlcName)));
                item.ForeColor = sources.Count >= 3 ? Theme.Danger : Theme.Warning;
                item.Tag = sources;
                conflictList.Items.Add(item);
            }
            conflictList.EndUpdate();
            lblSummary.Text = $"{_folders.Count} folder(s) scanned  •  {allFiles.Count} unique filenames  •  {_conflicts.Count} conflict(s) found";
            lblSummary.ForeColor = _conflicts.Count > 0 ? Theme.Danger : Theme.Success;
            lblStatus.Text = _conflicts.Count > 0 ? $"⚠ {_conflicts.Count} conflict(s) — one mod will override the other for these files." : "✔ No conflicts found!";
            lblStatus.ForeColor = _conflicts.Count > 0 ? Theme.Warning : Theme.Success;
            btnExport.Enabled = _conflicts.Count > 0;
        }

        // ── Right-click a conflict row → one menu item per DLC source
        //    that file was found in, each opening that specific copy's
        //    containing folder in Explorer (pre-selecting the file) —
        //    faster than hunting through the "Found in DLC(s)" text and
        //    guessing which folder is which. ─────────────────────────────
        private void ConflictList_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right) return;
            var hit = conflictList.HitTest(e.Location);
            if (hit.Item == null) return;
            conflictList.SelectedItems.Clear();
            hit.Item.Selected = true;

            if (hit.Item.Tag is not List<FileRecord> sources || sources.Count == 0) return;

            var menu = new ContextMenuStrip();
            foreach (var src in sources)
            {
                var label = $"📂 Open in {src.DlcName}";
                var path = src.FullPath;
                menu.Items.Add(label, null, (s, ev) => OpenContainingFolder(path));
            }
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("📋 Copy filename", null, (s, ev) => Clipboard.SetText(Path.GetFileName(sources[0].FullPath)));
            menu.Show(conflictList, e.Location);
        }

        private static void OpenContainingFolder(string filePath)
        {
            if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath)) return;
            System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{filePath}\"");
        }

        private void CopyConflictsToClipboard(object sender, EventArgs e)
        {
            if (_conflicts.Count == 0) { MessageBox.Show("No conflicts to copy — scan first.", "Nothing To Copy", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            var sb = new System.Text.StringBuilder();
            foreach (var (name, sources) in _conflicts)
                sb.AppendLine($"{name}  ({sources.Count}x)  —  {string.Join(" | ", sources.Select(s => s.DlcName))}");
            Clipboard.SetText(sb.ToString());
            lblStatus.Text = $"Copied {_conflicts.Count} conflict(s) to clipboard.";
            lblStatus.ForeColor = Theme.Success;
        }

        private void ExportReport(object sender, EventArgs e)
        {
            using var d = new SaveFileDialog { Filter = "CSV|*.csv", FileName = "conflict_report.csv" };
            if (d.ShowDialog() != DialogResult.OK) return;
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("File,Extension,ConflictCount,DLCsInvolved");
            foreach (var (name, sources) in _conflicts)
                sb.AppendLine($"\"{name}\",{sources[0].Ext},{sources.Count},\"{string.Join(" | ", sources.Select(s => s.DlcName))}\"");
            System.IO.File.WriteAllText(d.FileName, sb.ToString(), System.Text.Encoding.UTF8);
            MessageBox.Show($"Exported {_conflicts.Count} conflicts.", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    // =========================================================================
    //  Script Manager
    //  Lists ASI plugins, SHVDN/ScriptHookV scripts and RAGE Plugin Hook plugins,
    //  lets you enable / disable them instantly, and shows version info.
    // =========================================================================
    internal class ScriptManagerPanel : UserControl
    {
        private Button btnScan, btnEnable, btnDisable, btnOpenFolder, btnOpenFile, btnRefresh;
        private TextBox txtGtaRoot;
        private ListView list;
        private Label lblStatus, lblSummary;
        private CheckBox chkShowDisabled;

        private record ScriptEntry(string Path, string Name, string Type, bool Enabled, long Size, string Version);
        private List<ScriptEntry> _scripts = new();

        public ScriptManagerPanel()
        {
            this.BackColor = Theme.Background;
            Theme.ThemeChanged += () => { this.BackColor = Theme.Background; if (list != null) { list.BackColor = Theme.ListBg; list.ForeColor = Theme.Text; } };
            Build();
        }

        private Button Btn(string t, int w, Color? bg = null) { var b = new Button { Text = t, Width = w, Height = 26, BackColor = bg ?? Theme.Surface, ForeColor = bg.HasValue ? Color.White : Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 88, BackColor = Theme.Surface };
            top.Controls.Add(new Label { Text = "GTA V root folder:", AutoSize = true, Location = new Point(12, 12), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) });
            txtGtaRoot = new TextBox { Location = new Point(130, 9), Width = 560, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f) };
            top.Controls.Add(txtGtaRoot);
            var btnBrowse = Btn("Browse…", 74); btnBrowse.Location = new Point(698, 8); btnBrowse.Click += (s, e) => { using var d = new FolderBrowserDialog { Description = "Select GTA V root folder" }; if (d.ShowDialog() == DialogResult.OK) { txtGtaRoot.Text = d.SelectedPath; Scan(); } };
            var btnAuto = Btn("🔍 Auto-Detect", 106); btnAuto.Location = new Point(780, 8);
            btnAuto.Click += (s, e) => { string gt = GtaDirectoryPickerDialog.GetOrPick(this.FindForm()); if (!string.IsNullOrEmpty(gt)) { txtGtaRoot.Text = gt; Scan(); } };
            top.Controls.AddRange(new Control[] { btnBrowse, btnAuto });

            btnScan = Btn("🔍 Scan", 76, Theme.Accent); btnScan.Location = new Point(12, 46); btnScan.Click += (s, e) => Scan();
            btnEnable = Btn("✔ Enable", 80); btnEnable.Location = new Point(94, 46); btnEnable.Click += (s, e) => Toggle(true);
            btnDisable = Btn("✕ Disable", 84); btnDisable.Location = new Point(180, 46); btnDisable.Click += (s, e) => Toggle(false);
            btnOpenFolder = Btn("📂 Open Folder", 106); btnOpenFolder.Location = new Point(270, 46); btnOpenFolder.Click += OpenFolder;
            btnOpenFile = Btn("📄 Open File", 94); btnOpenFile.Location = new Point(382, 46); btnOpenFile.Click += OpenFile;
            btnRefresh = Btn("↺ Refresh", 80); btnRefresh.Location = new Point(482, 46); btnRefresh.Click += (s, e) => Scan();
            chkShowDisabled = new CheckBox { Text = "Show disabled", Location = new Point(570, 50), AutoSize = true, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f), Checked = true };
            chkShowDisabled.CheckedChanged += (s, e) => RebuildList();
            top.Controls.AddRange(new Control[] { btnScan, btnEnable, btnDisable, btnOpenFolder, btnOpenFile, btnRefresh, chkShowDisabled });

            var infoBar = new Panel { Dock = DockStyle.Top, Height = 28, BackColor = Color.FromArgb(22, 22, 22) };
            lblSummary = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f), Text = "Select GTA V root folder to scan scripts." };
            infoBar.Controls.Add(lblSummary);

            list = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, Font = new Font("Consolas", 8f), BackColor = Theme.ListBg, ForeColor = Theme.Text, BorderStyle = BorderStyle.None };
            list.Columns.Add("Script / Plugin", 280); list.Columns.Add("Type", 100); list.Columns.Add("Status", 80); list.Columns.Add("Size", 80); list.Columns.Add("Version", 120); list.Columns.Add("Filename", 300);
            list.DoubleClick += OpenFile;
            list.MouseUp += (s, e) =>
            {
                if (e.Button != MouseButtons.Right) return;
                var hit = list.HitTest(e.Location);
                if (hit.Item == null) return;
                if (!hit.Item.Selected) { list.SelectedItems.Clear(); hit.Item.Selected = true; }

                var menu = new ContextMenuStrip();
                int selCount = list.SelectedItems.Count;
                menu.Items.Add(selCount > 1 ? $"✔ Enable {selCount} selected" : "✔ Enable", null, (s2, e2) => Toggle(true));
                menu.Items.Add(selCount > 1 ? $"✕ Disable {selCount} selected" : "✕ Disable", null, (s2, e2) => Toggle(false));
                menu.Items.Add(new ToolStripSeparator());
                menu.Items.Add("📂 Open Folder", null, OpenFolder);
                menu.Items.Add("📄 Open File Location", null, OpenFile);
                menu.Items.Add(new ToolStripSeparator());
                menu.Items.Add("📋 Copy Filename", null, (s2, e2) =>
                {
                    if (list.SelectedItems.Count > 0 && list.SelectedItems[0].Tag is ScriptEntry se)
                        Clipboard.SetText(Path.GetFileName(se.Path));
                });
                menu.Show(list, e.Location);
            };

            var btm = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = Theme.Surface };
            lblStatus = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            btm.Controls.Add(lblStatus);

            this.Controls.Add(list); this.Controls.Add(btm); this.Controls.Add(infoBar); this.Controls.Add(top);
        }

        private void Scan()
        {
            string root = txtGtaRoot.Text.Trim();
            if (!System.IO.Directory.Exists(root)) { lblStatus.Text = "Folder not found."; lblStatus.ForeColor = Theme.Danger; return; }
            _scripts.Clear();

            void ScanDir(string dir, string type, string[] exts, string[] disabledExts)
            {
                if (!System.IO.Directory.Exists(dir)) return;
                foreach (var f in System.IO.Directory.GetFiles(dir))
                {
                    var ext = System.IO.Path.GetExtension(f).ToLowerInvariant();
                    bool enabled = exts.Contains(ext, StringComparer.OrdinalIgnoreCase);
                    bool disabled = disabledExts.Contains(ext, StringComparer.OrdinalIgnoreCase);
                    if (!enabled && !disabled) continue;
                    string name = System.IO.Path.GetFileNameWithoutExtension(f);
                    if (disabled && name.EndsWith(".bak")) name = System.IO.Path.GetFileNameWithoutExtension(name);
                    long size = new System.IO.FileInfo(f).Length;
                    string ver = "";
                    try { var vi = System.Diagnostics.FileVersionInfo.GetVersionInfo(f); ver = vi.FileVersion ?? ""; } catch { }
                    _scripts.Add(new ScriptEntry(f, name, type, enabled, size, ver));
                }
            }

            ScanDir(root, "ASI Plugin", new[] { ".asi" }, new[] { ".asi.bak", ".asi.disabled" });
            ScanDir(System.IO.Path.Combine(root, "scripts"), "SHVDN Script", new[] { ".dll" }, new[] { ".dll.bak", ".dll.disabled" });
            ScanDir(System.IO.Path.Combine(root, "plugins"), "RAGE Plugin", new[] { ".dll" }, new[] { ".dll.bak", ".dll.disabled" });
            ScanDir(System.IO.Path.Combine(root, "plugins", "LSPDFR"), "LSPDFR Plugin", new[] { ".dll" }, new[] { ".dll.bak", ".dll.disabled" });

            RebuildList();
        }

        private void RebuildList()
        {
            list.BeginUpdate(); list.Items.Clear();
            var filtered = chkShowDisabled.Checked ? _scripts : _scripts.Where(s => s.Enabled).ToList();
            foreach (var s in filtered.OrderBy(s => s.Type).ThenBy(s => s.Name))
            {
                var item = new ListViewItem(s.Name);
                item.SubItems.Add(s.Type); item.SubItems.Add(s.Enabled ? "✔ Active" : "✕ Disabled");
                item.SubItems.Add(s.Size >= 1_048_576 ? $"{s.Size / 1_048_576.0:F1} MB" : $"{s.Size / 1024:F0} KB");
                item.SubItems.Add(string.IsNullOrEmpty(s.Version) ? "—" : s.Version);
                item.SubItems.Add(System.IO.Path.GetFileName(s.Path));
                item.ForeColor = s.Enabled ? Theme.Text : Theme.Muted; item.Tag = s;
                list.Items.Add(item);
            }
            list.EndUpdate();
            lblSummary.Text = $"{_scripts.Count} script(s)  •  {_scripts.Count(s => s.Enabled)} active  •  {_scripts.Count(s => !s.Enabled)} disabled";
            lblStatus.Text = $"Scanned {_scripts.Count} scripts/plugins"; lblStatus.ForeColor = Theme.Success;
        }

        private void Toggle(bool enable)
        {
            if (list.SelectedItems.Count == 0) return;

            int succeeded = 0, failed = 0;
            foreach (ListViewItem lvi in list.SelectedItems)
            {
                if (lvi.Tag is not ScriptEntry s) continue;
                string ext = System.IO.Path.GetExtension(s.Path);
                string newPath = enable ? s.Path.Replace(ext + ".bak", ext).Replace(ext + ".disabled", ext)
                                     : s.Path + ".disabled";
                try { System.IO.File.Move(s.Path, newPath); succeeded++; }
                catch { failed++; }
            }

            Scan();
            lblStatus.Text = failed == 0
                ? $"{(enable ? "Enabled" : "Disabled")} {succeeded} item(s)."
                : $"{(enable ? "Enabled" : "Disabled")} {succeeded} item(s), {failed} failed (in use, or permissions).";
            lblStatus.ForeColor = failed == 0 ? Theme.Success : Theme.Warning;
        }

        private void OpenFolder(object sender, EventArgs e)
        {
            if (list.SelectedItems.Count == 0) return;
            if (list.SelectedItems[0].Tag is ScriptEntry s)
                System.Diagnostics.Process.Start("explorer.exe", System.IO.Path.GetDirectoryName(s.Path));
        }

        private void OpenFile(object sender, EventArgs e)
        {
            if (list.SelectedItems.Count == 0) return;
            if (list.SelectedItems[0].Tag is ScriptEntry s && System.IO.File.Exists(s.Path))
                System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{s.Path}\"");
        }
    }

    // =========================================================================
    //  Vehicle Wizard
    //  Step-by-step guided builder: enter a spawn name, pick class, configure
    //  handling values, choose colours, preview all 4 meta files, and export.
    // =========================================================================
    internal class VehicleWizardPanel : UserControl
    {
        private TabControl steps;
        private RichTextBox previewBox;
        private Button btnGenerate, btnExport, btnCopyPreview;
        private Label lblStatus;

        // Step 1 — Identity
        private TextBox txtSpawnName, txtMake, txtModel, txtDisplayName;
        private ComboBox cboClass, cboDriveType, cboSeatCount;
        // Step 2 — Handling
        private TextBox txtTopSpeed, txtMass, txtBrakeForce, txtTractionCurveMax, txtTractionCurveLateral,
            txtSteeringLock, txtSuspensionForce, txtSuspensionCompDamp, txtSuspensionReboundDamp,
            txtSuspensionUpperLimit, txtSuspensionLowerLimit, txtAntiRollBarForce, txtCollisionDamageMult,
            txtWeaponDamageMult, txtEngineDamageMult, txtPetrolTankVolume, txtOilVolume, txtMonetaryValue;
        private ComboBox cboHandlingType;
        // Step 3 — Audio
        private TextBox txtAudioHash;
        private ComboBox cboAudioPreset;
        // Step 4 — Colours
        private DataGridView gridColors;
        // Step 5 — Wheels & Extras
        private ComboBox cboWheelType;
        private CheckedListBox clbExtras;
        private Button btnImportMeta, btnSavePreset, btnLoadPreset;

        public VehicleWizardPanel()
        {
            this.BackColor = Theme.Background;
            Theme.ThemeChanged += () => this.BackColor = Theme.Background;
            Build();
        }

        private Label Lbl(string t, int x, int y) => new Label { Text = t, AutoSize = true, Location = new Point(x, y), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
        private TextBox Txt(string v, int x, int y, int w) => new TextBox { Text = v, Location = new Point(x, y), Width = w, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 9f) };
        private ComboBox Cbo(int x, int y, int w, string[] items, int sel = 0) { var c = new ComboBox { Location = new Point(x, y), Width = w, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Theme.Background, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; c.Items.AddRange(items); c.SelectedIndex = Math.Min(sel, items.Length - 1); return c; }

        private void Build()
        {
            var toolbar = new Panel { Dock = DockStyle.Bottom, Height = 44, BackColor = Theme.Surface, Padding = new Padding(12, 8, 12, 8) };
            btnGenerate = new Button { Text = "▶ Generate Preview", Location = new Point(12, 8), Width = 150, Height = 28, BackColor = Theme.Accent, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9f, FontStyle.Bold) }; btnGenerate.FlatAppearance.BorderSize = 0; btnGenerate.Click += (s, e) => GeneratePreview();
            btnExport = new Button { Text = "💾 Export Files", Location = new Point(170, 8), Width = 120, Height = 28, BackColor = Color.FromArgb(30, 120, 60), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9f, FontStyle.Bold) }; btnExport.FlatAppearance.BorderSize = 0; btnExport.Click += ExportFiles;
            btnCopyPreview = new Button { Text = "📋 Copy", Location = new Point(298, 8), Width = 80, Height = 28, BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat }; btnCopyPreview.FlatAppearance.BorderColor = Theme.Border; btnCopyPreview.Click += (s, e) => Clipboard.SetText(previewBox.Text);
            btnImportMeta = new Button { Text = "📂 Import Existing…", Location = new Point(386, 8), Width = 140, Height = 28, BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; btnImportMeta.FlatAppearance.BorderColor = Theme.Border; btnImportMeta.Click += (s, e) => ImportExistingMeta();
            btnSavePreset = new Button { Text = "💾 Save Preset", Location = new Point(534, 8), Width = 110, Height = 28, BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; btnSavePreset.FlatAppearance.BorderColor = Theme.Border; btnSavePreset.Click += (s, e) => SavePreset();
            btnLoadPreset = new Button { Text = "📁 Load Preset", Location = new Point(652, 8), Width = 110, Height = 28, BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; btnLoadPreset.FlatAppearance.BorderColor = Theme.Border; btnLoadPreset.Click += (s, e) => LoadPreset();
            lblStatus = new Label { AutoSize = true, Location = new Point(770, 14), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) };
            toolbar.Controls.AddRange(new Control[] { btnGenerate, btnExport, btnCopyPreview, btnImportMeta, btnSavePreset, btnLoadPreset, lblStatus });

            var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterDistance = 520, BackColor = Theme.Background };

            steps = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 8.5f) };
            BuildStep1(); BuildStep2(); BuildStep3(); BuildStep4(); BuildStep5();
            split.Panel1.Controls.Add(steps);

            var previewPanel = new Panel { Dock = DockStyle.Fill };
            previewPanel.Controls.Add(new Label { Text = "Live Preview (click ▶ Generate):", Dock = DockStyle.Top, Height = 22, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f), Padding = new Padding(4, 4, 0, 0) });
            previewBox = new RichTextBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(18, 18, 18), ForeColor = Color.FromArgb(212, 212, 212), Font = new Font("Consolas", 8.5f), ReadOnly = true, BorderStyle = BorderStyle.None, WordWrap = false };
            previewPanel.Controls.Add(previewBox);
            split.Panel2.Controls.Add(previewPanel);

            this.Controls.Add(split); this.Controls.Add(toolbar);
        }

        private void BuildStep1()
        {
            var tab = new TabPage("  1  Identity  "); tab.BackColor = Theme.Background;
            var p = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16) };
            int y = 16;
            p.Controls.Add(Lbl("Spawn name (no spaces, lowercase):", 16, y));
            txtSpawnName = Txt("mycar", 16, y + 18, 200); p.Controls.Add(txtSpawnName); y += 50;

            p.Controls.Add(Lbl("Display name (shown in game UI):", 16, y));
            txtDisplayName = Txt("My Car", 16, y + 18, 200); p.Controls.Add(txtDisplayName); y += 50;

            p.Controls.Add(Lbl("Make (manufacturer):", 16, y)); txtMake = Txt("Vapid", 16, y + 18, 180); p.Controls.Add(txtMake);
            p.Controls.Add(Lbl("Model:", 220, y)); txtModel = Txt("Stallion", 220, y + 18, 180); p.Controls.Add(txtModel); y += 50;

            p.Controls.Add(Lbl("Vehicle class:", 16, y));
            string[] classes = { "Compacts", "Sedans", "SUVs", "Coupes", "Muscle", "Sports Classic", "Sports", "Super", "Motorcycles", "Off-Road", "Industrial", "Utility", "Vans", "Cycles", "Boats", "Helicopters", "Planes", "Service", "Emergency", "Military", "Commercial", "Trains" };
            cboClass = Cbo(16, y + 18, 200, classes, 7); p.Controls.Add(cboClass); y += 50;

            p.Controls.Add(Lbl("Drive type:", 16, y));
            cboDriveType = Cbo(16, y + 18, 130, new[] { "AWD", "FWD", "RWD" }, 2); p.Controls.Add(cboDriveType);
            p.Controls.Add(Lbl("Seats:", 160, y));
            cboSeatCount = Cbo(160, y + 18, 80, new[] { "1", "2", "4", "6", "8" }, 1); p.Controls.Add(cboSeatCount); y += 50;

            tab.Controls.Add(p); steps.TabPages.Add(tab);
        }

        private void BuildStep2()
        {
            var tab = new TabPage("  2  Handling  "); tab.BackColor = Theme.Background;
            var p = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16), AutoScroll = true };
            int y = 16;
            p.Controls.Add(new Label { Text = "Values are written directly into handling.meta. Leave defaults if unsure.", AutoSize = false, Width = 450, Height = 20, Location = new Point(16, y), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) }); y += 30;
            void Row(string label, ref TextBox box, string def, int yy) { p.Controls.Add(Lbl(label, 16, yy)); box = Txt(def, 220, yy - 2, 100); p.Controls.Add(box); }
            void Section(string title, int yy) { p.Controls.Add(new Label { Text = title, AutoSize = true, Location = new Point(16, yy), ForeColor = Theme.Accent, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold) }); }

            Section("── Core ──", y); y += 24;
            Row("Top Speed (m/s — 70≈250kmh):", ref txtTopSpeed, "55.0", y); y += 28;
            Row("Mass (kg):", ref txtMass, "1700.0", y); y += 28;
            Row("Monetary Value ($):", ref txtMonetaryValue, "15000", y); y += 34;

            Section("── Traction & Brakes ──", y); y += 24;
            Row("Brake Force:", ref txtBrakeForce, "0.7", y); y += 28;
            Row("Traction Curve Max:", ref txtTractionCurveMax, "2.45", y); y += 28;
            Row("Traction Curve Lateral:", ref txtTractionCurveLateral, "22.5", y); y += 28;
            Row("Steering Lock (degrees):", ref txtSteeringLock, "35.0", y); y += 34;

            Section("── Suspension ──", y); y += 24;
            Row("Suspension Force:", ref txtSuspensionForce, "2.5", y); y += 28;
            Row("Suspension Comp Damp:", ref txtSuspensionCompDamp, "0.9", y); y += 28;
            Row("Suspension Rebound Damp:", ref txtSuspensionReboundDamp, "1.0", y); y += 28;
            Row("Suspension Upper Limit:", ref txtSuspensionUpperLimit, "0.1", y); y += 28;
            Row("Suspension Lower Limit:", ref txtSuspensionLowerLimit, "-0.12", y); y += 28;
            Row("Anti-Roll Bar Force:", ref txtAntiRollBarForce, "0.2", y); y += 34;

            Section("── Damage & Fuel ──", y); y += 24;
            Row("Collision Damage Mult:", ref txtCollisionDamageMult, "1.0", y); y += 28;
            Row("Weapon Damage Mult:", ref txtWeaponDamageMult, "1.0", y); y += 28;
            Row("Engine Damage Mult:", ref txtEngineDamageMult, "1.0", y); y += 28;
            Row("Petrol Tank Volume:", ref txtPetrolTankVolume, "65.0", y); y += 28;
            Row("Oil Volume:", ref txtOilVolume, "5.0", y); y += 34;

            p.Controls.Add(Lbl("Handling type preset:", 16, y));
            cboHandlingType = Cbo(16, y + 18, 220, new[] { "VEHICLE_HANDLING", "BIKE_HANDLING", "FLYING_HANDLING", "BOAT_HANDLING", "HELICOPTER_HANDLING" }, 0); p.Controls.Add(cboHandlingType);

            tab.Controls.Add(p); steps.TabPages.Add(tab);
        }

        private void BuildStep3()
        {
            var tab = new TabPage("  3  Audio  "); tab.BackColor = Theme.Background;
            var p = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16) };
            int y = 16;
            p.Controls.Add(new Label { Text = "Controls the engine sound. Use an audio hash matching a base game vehicle\nor a custom audio bank name from your .awc files.", AutoSize = false, Width = 480, Height = 36, Location = new Point(16, y), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) }); y += 48;

            p.Controls.Add(Lbl("Audio bank hash / name:", 16, y));
            txtAudioHash = Txt("VEHICLES_IMPONTE_DUKES", 16, y + 18, 300); p.Controls.Add(txtAudioHash); y += 50;

            p.Controls.Add(Lbl("Common presets (click to apply):", 16, y)); y += 22;
            string[] presets = { "VEHICLES_IMPONTE_DUKES", "VEHICLES_VAPID_DOMINATOR", "VEHICLES_FORD_POLICE", "VEHICLES_BRAVADO_BUFFALO", "VEHICLES_BRAVADO_GAUNTLET", "VEHICLES_ALBANY_BUCCANEER", "VEHICLES_MUSCLE_DEFAULT" };
            foreach (var pr in presets)
            {
                var btn = new Button { Text = pr, Location = new Point(16, y), AutoSize = true, Height = 24, BackColor = Theme.Surface, ForeColor = Theme.Muted, FlatStyle = FlatStyle.Flat, Font = new Font("Consolas", 7.5f) };
                btn.FlatAppearance.BorderColor = Theme.Border; btn.FlatAppearance.BorderSize = 1;
                var cap = pr; btn.Click += (s, e) => txtAudioHash.Text = cap; p.Controls.Add(btn); y += 28;
            }

            p.Controls.Add(Lbl("Audio preset (carcols.meta):", 16, y));
            cboAudioPreset = Cbo(16, y + 18, 260, new[] { "none", "car_default_audio_entity", "muscle_car_audio_entity", "suv_audio_entity", "emergency_audio_entity", "helicopter_audio_entity" }, 0); p.Controls.Add(cboAudioPreset);

            tab.Controls.Add(p); steps.TabPages.Add(tab);
        }

        private void BuildStep4()
        {
            var tab = new TabPage("  4  Colours  "); tab.BackColor = Theme.Background;
            var p = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16) };
            p.Controls.Add(new Label { Text = "Define colour combinations for carcols.meta. R/G/B are 0-255.", AutoSize = true, Location = new Point(16, 8), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) });
            gridColors = new DataGridView { Location = new Point(16, 32), BackgroundColor = Theme.Background, ForeColor = Theme.Text, GridColor = Theme.Border, BorderStyle = BorderStyle.None, RowHeadersVisible = false, AllowUserToAddRows = true, Font = new Font("Consolas", 8.5f), AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
            gridColors.DefaultCellStyle.BackColor = Theme.Background; gridColors.DefaultCellStyle.ForeColor = Theme.Text;
            gridColors.Columns.Add("R", "R"); gridColors.Columns.Add("G", "G"); gridColors.Columns.Add("B", "B"); gridColors.Columns.Add("Name", "Colour Name");
            gridColors.Rows.Add("0", "0", "0", "Jet Black"); gridColors.Rows.Add("255", "255", "255", "Arctic White"); gridColors.Rows.Add("30", "100", "200", "LSPD Blue");
            gridColors.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            p.Controls.Add(gridColors);
            p.Resize += (s, e) => gridColors.Size = new Size(p.ClientSize.Width - 32, p.ClientSize.Height - 48);
            tab.Controls.Add(p); steps.TabPages.Add(tab);
        }

        private void BuildStep5()
        {
            var tab = new TabPage("  5  Wheels & Extras  "); tab.BackColor = Theme.Background;
            var p = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16) };

            p.Controls.Add(Lbl("Wheel type (controls which rims are available in-game):", 16, 12));
            cboWheelType = Cbo(16, 32, 220, new[] { "Sport", "Muscle", "Lowrider", "SUV", "Offroad", "Tuner", "BikeWheels", "HighEnd", "Benny's Original", "Benny's Bespoke", "Open Wheel" }, 0);
            p.Controls.Add(cboWheelType);

            p.Controls.Add(new Label { Text = "Extras (spoilers, bull bars, etc.) — check which extra slots this vehicle defines.\nExtra 1 is conventionally the primary/most visible one.", AutoSize = false, Width = 480, Height = 36, Location = new Point(16, 76), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f) });

            clbExtras = new CheckedListBox
            {
                Location = new Point(16, 120),
                Size = new Size(220, 200),
                BackColor = Theme.Background,
                ForeColor = Theme.Text,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 8.5f),
                CheckOnClick = true,
            };
            for (int i = 1; i <= 12; i++) clbExtras.Items.Add($"Extra {i}");
            clbExtras.SetItemChecked(0, true); // extra_1 on by default — matches how most addon vehicles ship
            p.Controls.Add(clbExtras);

            tab.Controls.Add(p); steps.TabPages.Add(tab);
        }

        private void GeneratePreview()
        {
            string spawn = txtSpawnName.Text.Trim().ToLowerInvariant().Replace(" ", "");
            if (string.IsNullOrEmpty(spawn)) { lblStatus.Text = "Enter a spawn name first."; lblStatus.ForeColor = Theme.Danger; return; }
            string display = txtDisplayName.Text.Trim();
            string cls = cboClass.SelectedItem?.ToString() ?? "Sports";
            string drive = cboDriveType.SelectedItem?.ToString() ?? "RWD";
            int seats = int.TryParse(cboSeatCount.SelectedItem?.ToString(), out int s2) ? s2 : 2;

            var sb = new System.Text.StringBuilder();
            sb.AppendLine("<!-- ===== vehicles.meta ===== -->");
            sb.AppendLine("<CVehicleModelInfo__InitDataList>");
            sb.AppendLine("  <InitDatas>");
            sb.AppendLine("    <Item>");
            sb.AppendLine($"      <modelName>{spawn}</modelName>");
            sb.AppendLine($"      <txdName>{spawn}</txdName>");
            sb.AppendLine($"      <handlingId>{spawn.ToUpperInvariant()}</handlingId>");
            sb.AppendLine($"      <gameName>{display.ToUpperInvariant()}</gameName>");
            sb.AppendLine($"      <vehicleMakeName>{txtMake.Text.Trim().ToUpperInvariant()}</vehicleMakeName>");
            sb.AppendLine($"      <vehicleClass>VC_{cls.ToUpperInvariant().Replace(' ', '_').Replace('-', '_')}</vehicleClass>");
            sb.AppendLine($"      <numOfSeats value=\"{seats}\"/>");
            sb.AppendLine($"      <type>VEHICLE_TYPE_CAR</type>");
            sb.AppendLine($"      <plateType>VPT_FRONT_AND_BACK_PLATES</plateType>");
            sb.AppendLine($"      <wheelType>{WheelTypeToken()}</wheelType>");
            sb.AppendLine("    </Item>");
            sb.AppendLine("  </InitDatas>");
            sb.AppendLine("</CVehicleModelInfo__InitDataList>");
            sb.AppendLine();
            sb.AppendLine("<!-- ===== handling.meta ===== -->");
            sb.AppendLine("<CHandlingDataMgr>");
            sb.AppendLine("  <HandlingData>");
            sb.AppendLine("    <Item type=\"CHandlingData\">");
            sb.AppendLine($"      <handlingName>{spawn.ToUpperInvariant()}</handlingName>");
            sb.AppendLine($"      <fMass value=\"{txtMass.Text.Trim()}\"/>");
            sb.AppendLine($"      <fInitialDragCoeff value=\"8.00\"/>");
            sb.AppendLine($"      <fDriveForce value=\"0.35\"/>");
            sb.AppendLine($"      <fDriveInertia value=\"1.00\"/>");
            sb.AppendLine($"      <fClutchChangeRateScaleUpShift value=\"2.50\"/>");
            sb.AppendLine($"      <fClutchChangeRateScaleDownShift value=\"2.50\"/>");
            sb.AppendLine($"      <fDriveMaxFlatVel value=\"{txtTopSpeed.Text.Trim()}\"/>");
            sb.AppendLine($"      <fInitialDriveForce value=\"0.35\"/>");
            sb.AppendLine($"      <fInitialDriveMaxFlatVel value=\"{txtTopSpeed.Text.Trim()}\"/>");
            sb.AppendLine($"      <fBrakeForce value=\"{txtBrakeForce.Text.Trim()}\"/>");
            sb.AppendLine($"      <fSteeringLock value=\"{txtSteeringLock.Text.Trim()}\"/>");
            sb.AppendLine($"      <fTractionCurveMax value=\"{txtTractionCurveMax.Text.Trim()}\"/>");
            sb.AppendLine($"      <fTractionCurveMin value=\"{(double.TryParse(txtTractionCurveMax.Text, out double tcm) ? tcm * 0.82 : 2.0):F2}\"/>");
            sb.AppendLine($"      <fTractionCurveLateral value=\"{txtTractionCurveLateral.Text.Trim()}\"/>");
            sb.AppendLine($"      <fTractionSpringDeltaMax value=\"0.15\"/>");
            sb.AppendLine($"      <fLowSpeedTractionLossMult value=\"0.0\"/>");
            sb.AppendLine($"      <fSuspensionForce value=\"{txtSuspensionForce.Text.Trim()}\"/>");
            sb.AppendLine($"      <fSuspensionCompDamp value=\"{txtSuspensionCompDamp.Text.Trim()}\"/>");
            sb.AppendLine($"      <fSuspensionReboundDamp value=\"{txtSuspensionReboundDamp.Text.Trim()}\"/>");
            sb.AppendLine($"      <fSuspensionUpperLimit value=\"{txtSuspensionUpperLimit.Text.Trim()}\"/>");
            sb.AppendLine($"      <fSuspensionLowerLimit value=\"{txtSuspensionLowerLimit.Text.Trim()}\"/>");
            sb.AppendLine($"      <fSuspensionRaise value=\"0.0\"/>");
            sb.AppendLine($"      <fAntiRollBarForce value=\"{txtAntiRollBarForce.Text.Trim()}\"/>");
            sb.AppendLine($"      <fAntiRollBarBiasFront value=\"0.5\"/>");
            sb.AppendLine($"      <fRollCentreHeightFront value=\"0.35\"/>");
            sb.AppendLine($"      <fRollCentreHeightRear value=\"0.35\"/>");
            sb.AppendLine($"      <fCollisionDamageMult value=\"{txtCollisionDamageMult.Text.Trim()}\"/>");
            sb.AppendLine($"      <fWeaponDamageMult value=\"{txtWeaponDamageMult.Text.Trim()}\"/>");
            sb.AppendLine($"      <fDeformationDamageMult value=\"1.0\"/>");
            sb.AppendLine($"      <fEngineDamageMult value=\"{txtEngineDamageMult.Text.Trim()}\"/>");
            sb.AppendLine($"      <fPetrolTankVolume value=\"{txtPetrolTankVolume.Text.Trim()}\"/>");
            sb.AppendLine($"      <fOilVolume value=\"{txtOilVolume.Text.Trim()}\"/>");
            sb.AppendLine($"      <fSeatOffsetDistX value=\"0.0\"/>");
            sb.AppendLine($"      <fSeatOffsetDistY value=\"0.0\"/>");
            sb.AppendLine($"      <fSeatOffsetDistZ value=\"0.0\"/>");
            sb.AppendLine($"      <nMonetaryValue value=\"{txtMonetaryValue.Text.Trim()}\"/>");
            sb.AppendLine($"      <nInitialDriveGears value=\"6\"/>");
            sb.AppendLine($"      <fDriveBiasFront value=\"{(drive == "FWD" ? "1.0" : drive == "AWD" ? "0.5" : "0.0")}\"/>");
            sb.AppendLine($"      <handlingType>{cboHandlingType.SelectedItem}</handlingType>");
            sb.AppendLine("    </Item>");
            sb.AppendLine("  </HandlingData>");
            sb.AppendLine("</CHandlingDataMgr>");
            sb.AppendLine();
            sb.AppendLine("<!-- ===== carcols.meta ===== -->");
            sb.AppendLine("<CVehicleModelInfoVarGlobal>");
            sb.AppendLine("  <Kits>");
            sb.AppendLine("    <Item>");
            sb.AppendLine($"      <kitName>0_{spawn.ToUpperInvariant()}_MUN</kitName>");
            sb.AppendLine("      <id value=\"0\"/>");
            sb.AppendLine("    </Item>");
            sb.AppendLine("  </Kits>");
            sb.AppendLine("  <Lights>");
            sb.AppendLine("    <Item>");
            sb.AppendLine($"      <vehicleModelName>{spawn}</vehicleModelName>");
            sb.AppendLine($"      <audioNameHash>{txtAudioHash.Text.Trim()}</audioNameHash>");
            sb.AppendLine("      <colors>");
            foreach (DataGridViewRow row in gridColors.Rows)
            {
                if (row.IsNewRow) continue;
                string r = row.Cells[0].Value?.ToString() ?? "0", g = row.Cells[1].Value?.ToString() ?? "0", b = row.Cells[2].Value?.ToString() ?? "0";
                sb.AppendLine($"        <Item><r value=\"{r}\"/><g value=\"{g}\"/><b value=\"{b}\"/></Item>");
            }
            sb.AppendLine("      </colors>");
            sb.AppendLine("    </Item>");
            sb.AppendLine("  </Lights>");
            sb.AppendLine("</CVehicleModelInfoVarGlobal>");
            sb.AppendLine();
            sb.AppendLine("<!-- ===== carvariations.meta ===== -->");
            sb.AppendLine("<CVehicleModelInfoVariation>");
            sb.AppendLine("  <variationData>");
            sb.AppendLine("    <Item>");
            sb.AppendLine($"      <modelName>{spawn}</modelName>");
            sb.AppendLine("      <colors>");
            sb.AppendLine("        <Item>");
            sb.AppendLine("          <indices content=\"char_array\">0 0 0 0</indices>");
            sb.AppendLine("        </Item>");
            sb.AppendLine("      </colors>");
            sb.AppendLine("      <kits>");
            sb.AppendLine($"        <Item>0_{spawn.ToUpperInvariant()}_MUN</Item>");
            sb.AppendLine("      </kits>");
            sb.AppendLine($"      <plateProbabilities>");
            sb.AppendLine("        <Probabilities>");
            sb.AppendLine("          <Item><Name>Standard White</Name><Value value=\"100\"/></Item>");
            sb.AppendLine("        </Probabilities>");
            sb.AppendLine("      </plateProbabilities>");
            string extrasList = string.Join(",", clbExtras.CheckedItems.Cast<string>().Select(s => "EXTRA_" + s.Replace("Extra ", "")));
            sb.AppendLine($"      <extras>{extrasList}</extras>");
            sb.AppendLine("    </Item>");
            sb.AppendLine("  </variationData>");
            sb.AppendLine("</CVehicleModelInfoVariation>");

            previewBox.Text = sb.ToString();
            lblStatus.Text = "✔ Preview generated."; lblStatus.ForeColor = Theme.Success;
        }

        // ── wheelType token for vehicles.meta — GTA5's actual wheel-type
        //    identifiers (well-documented, stable across the whole
        //    modding community, not specific to any particular tool). ────
        private string WheelTypeToken()
        {
            return (cboWheelType?.SelectedItem?.ToString() ?? "Sport") switch
            {
                "Sport" => "WHEEL_TYPE_SPORT",
                "Muscle" => "WHEEL_TYPE_MUSCLE",
                "Lowrider" => "WHEEL_TYPE_LOWRIDER",
                "SUV" => "WHEEL_TYPE_SUV",
                "Offroad" => "WHEEL_TYPE_OFFROAD",
                "Tuner" => "WHEEL_TYPE_TUNER",
                "BikeWheels" => "WHEEL_TYPE_BIKE",
                "HighEnd" => "WHEEL_TYPE_HIEND",
                "Benny's Original" => "WHEEL_TYPE_BENNYS_ORIGINAL",
                "Benny's Bespoke" => "WHEEL_TYPE_BENNYS_BESPOKE",
                "Open Wheel" => "WHEEL_TYPE_OPENWHEEL",
                _ => "WHEEL_TYPE_SPORT",
            };
        }

        private void ExportFiles(object sender, EventArgs e)
        {
            GeneratePreview();
            if (string.IsNullOrEmpty(previewBox.Text)) return;
            using var d = new FolderBrowserDialog { Description = "Select output folder for meta files" };
            if (d.ShowDialog() != DialogResult.OK) return;
            string spawn = txtSpawnName.Text.Trim().ToLowerInvariant();
            string all = previewBox.Text;
            string[] parts = all.Split(new[] { "<!-- ===== " }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var part in parts)
            {
                int end = part.IndexOf("===== -->");
                if (end < 0) continue;
                string fname = part.Substring(0, end).Trim();
                string content = part.Substring(end + 9).Trim();
                System.IO.File.WriteAllText(System.IO.Path.Combine(d.SelectedPath, fname), content, System.Text.Encoding.UTF8);
            }
            var res = MessageBox.Show($"Exported meta files to:\n{d.SelectedPath}\n\nOpen folder?", "Exported", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (res == DialogResult.Yes) System.Diagnostics.Process.Start("explorer.exe", d.SelectedPath);
        }

        // ── Import Existing — the highest-value addition for "complete
        //    control": start from a REAL vehicle's actual tuned values
        //    instead of always from scratch defaults. Picks a
        //    vehicles.meta (required) and optionally a handling.meta,
        //    pulls out whichever fields it recognizes via regex, and
        //    leaves anything it can't find at its current value rather
        //    than blanking it out. ─────────────────────────────────────
        private void ImportExistingMeta()
        {
            using var dlg = new OpenFileDialog { Filter = "vehicles.meta|vehicles.meta;*.meta|All files|*.*", Title = "Select vehicles.meta (or any .meta with a matching <Item> block)" };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            string vehiclesXml;
            try { vehiclesXml = System.IO.File.ReadAllText(dlg.FileName); }
            catch (Exception ex) { MessageBox.Show("Couldn't read file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }

            string Field(string xml, string tag) { var m = System.Text.RegularExpressions.Regex.Match(xml, $@"<{tag}>([^<]*)</{tag}>"); return m.Success ? m.Groups[1].Value.Trim() : null; }
            string Attr(string xml, string tag) { var m = System.Text.RegularExpressions.Regex.Match(xml, $@"<{tag}\s+value=""([^""]*)""\s*/>"); return m.Success ? m.Groups[1].Value.Trim() : null; }

            var v = Field(vehiclesXml, "modelName");
            if (v != null) txtSpawnName.Text = v;
            var gn = Field(vehiclesXml, "gameName"); if (gn != null) txtDisplayName.Text = gn;
            var mk = Field(vehiclesXml, "vehicleMakeName"); if (mk != null) txtMake.Text = mk;

            int importedCount = 0;
            if (v != null) importedCount++;

            // Optional second file for handling.meta — asked for
            // separately since real addons commonly ship these split
            // across two files, and forcing a single combined pick would
            // just fail for the common case.
            var res = MessageBox.Show("Also import a matching handling.meta?", "Import Handling", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                using var dlg2 = new OpenFileDialog { Filter = "handling.meta|handling.meta;*.meta|All files|*.*", Title = "Select handling.meta" };
                if (dlg2.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string handlingXml = System.IO.File.ReadAllText(dlg2.FileName);
                        void ApplyIfFound(string tag, TextBox box) { var val = Attr(handlingXml, tag); if (val != null) { box.Text = val; importedCount++; } }

                        ApplyIfFound("fMass", txtMass);
                        ApplyIfFound("fDriveMaxFlatVel", txtTopSpeed);
                        ApplyIfFound("fBrakeForce", txtBrakeForce);
                        ApplyIfFound("fSteeringLock", txtSteeringLock);
                        ApplyIfFound("fTractionCurveMax", txtTractionCurveMax);
                        ApplyIfFound("fTractionCurveLateral", txtTractionCurveLateral);
                        ApplyIfFound("fSuspensionForce", txtSuspensionForce);
                        ApplyIfFound("fSuspensionCompDamp", txtSuspensionCompDamp);
                        ApplyIfFound("fSuspensionReboundDamp", txtSuspensionReboundDamp);
                        ApplyIfFound("fSuspensionUpperLimit", txtSuspensionUpperLimit);
                        ApplyIfFound("fSuspensionLowerLimit", txtSuspensionLowerLimit);
                        ApplyIfFound("fAntiRollBarForce", txtAntiRollBarForce);
                        ApplyIfFound("fCollisionDamageMult", txtCollisionDamageMult);
                        ApplyIfFound("fWeaponDamageMult", txtWeaponDamageMult);
                        ApplyIfFound("fEngineDamageMult", txtEngineDamageMult);
                        ApplyIfFound("fPetrolTankVolume", txtPetrolTankVolume);
                        ApplyIfFound("fOilVolume", txtOilVolume);
                        ApplyIfFound("nMonetaryValue", txtMonetaryValue);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Couldn't read handling.meta: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            lblStatus.Text = $"Imported {importedCount} field(s) — review each step before generating.";
            lblStatus.ForeColor = Theme.Success;
        }

        // ── Save/Load Preset — persists every field so filling out ~25
        //    values isn't wasted work if you want to reuse it as a
        //    starting point for a similar vehicle later. ─────────────────
        private void SavePreset()
        {
            using var dlg = new SaveFileDialog { Filter = "Vehicle Wizard Preset|*.vwpreset", FileName = (txtSpawnName.Text.Trim() is { Length: > 0 } n ? n : "preset") + ".vwpreset" };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            var sb = new System.Text.StringBuilder();
            void W(string key, string val) => sb.AppendLine($"{key}={val?.Replace("\n", "\\n")}");

            W("SpawnName", txtSpawnName.Text); W("DisplayName", txtDisplayName.Text); W("Make", txtMake.Text); W("Model", txtModel.Text);
            W("Class", cboClass.SelectedItem?.ToString()); W("DriveType", cboDriveType.SelectedItem?.ToString()); W("SeatCount", cboSeatCount.SelectedItem?.ToString());
            W("TopSpeed", txtTopSpeed.Text); W("Mass", txtMass.Text); W("BrakeForce", txtBrakeForce.Text); W("TractionCurveMax", txtTractionCurveMax.Text);
            W("TractionCurveLateral", txtTractionCurveLateral.Text); W("SteeringLock", txtSteeringLock.Text);
            W("SuspensionForce", txtSuspensionForce.Text); W("SuspensionCompDamp", txtSuspensionCompDamp.Text); W("SuspensionReboundDamp", txtSuspensionReboundDamp.Text);
            W("SuspensionUpperLimit", txtSuspensionUpperLimit.Text); W("SuspensionLowerLimit", txtSuspensionLowerLimit.Text); W("AntiRollBarForce", txtAntiRollBarForce.Text);
            W("CollisionDamageMult", txtCollisionDamageMult.Text); W("WeaponDamageMult", txtWeaponDamageMult.Text); W("EngineDamageMult", txtEngineDamageMult.Text);
            W("PetrolTankVolume", txtPetrolTankVolume.Text); W("OilVolume", txtOilVolume.Text); W("MonetaryValue", txtMonetaryValue.Text);
            W("HandlingType", cboHandlingType.SelectedItem?.ToString());
            W("AudioHash", txtAudioHash.Text); W("AudioPreset", cboAudioPreset.SelectedItem?.ToString());
            W("WheelType", cboWheelType.SelectedItem?.ToString());
            W("Extras", string.Join(";", clbExtras.CheckedItems.Cast<string>()));

            var colorRows = new List<string>();
            foreach (DataGridViewRow row in gridColors.Rows)
            {
                if (row.IsNewRow) continue;
                colorRows.Add($"{row.Cells[0].Value}|{row.Cells[1].Value}|{row.Cells[2].Value}|{row.Cells[3].Value}");
            }
            W("Colors", string.Join(";", colorRows));

            System.IO.File.WriteAllText(dlg.FileName, sb.ToString(), System.Text.Encoding.UTF8);
            lblStatus.Text = "✔ Preset saved."; lblStatus.ForeColor = Theme.Success;
        }

        private void LoadPreset()
        {
            using var dlg = new OpenFileDialog { Filter = "Vehicle Wizard Preset|*.vwpreset|All files|*.*" };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                var values = new Dictionary<string, string>();
                foreach (var line in System.IO.File.ReadAllLines(dlg.FileName))
                {
                    int eq = line.IndexOf('=');
                    if (eq < 0) continue;
                    values[line.Substring(0, eq)] = line.Substring(eq + 1).Replace("\\n", "\n");
                }

                void SetTxt(string key, TextBox box) { if (values.TryGetValue(key, out var v)) box.Text = v; }
                void SetCbo(string key, ComboBox box) { if (values.TryGetValue(key, out var v) && box.Items.Contains(v)) box.SelectedItem = v; }

                SetTxt("SpawnName", txtSpawnName); SetTxt("DisplayName", txtDisplayName); SetTxt("Make", txtMake); SetTxt("Model", txtModel);
                SetCbo("Class", cboClass); SetCbo("DriveType", cboDriveType); SetCbo("SeatCount", cboSeatCount);
                SetTxt("TopSpeed", txtTopSpeed); SetTxt("Mass", txtMass); SetTxt("BrakeForce", txtBrakeForce); SetTxt("TractionCurveMax", txtTractionCurveMax);
                SetTxt("TractionCurveLateral", txtTractionCurveLateral); SetTxt("SteeringLock", txtSteeringLock);
                SetTxt("SuspensionForce", txtSuspensionForce); SetTxt("SuspensionCompDamp", txtSuspensionCompDamp); SetTxt("SuspensionReboundDamp", txtSuspensionReboundDamp);
                SetTxt("SuspensionUpperLimit", txtSuspensionUpperLimit); SetTxt("SuspensionLowerLimit", txtSuspensionLowerLimit); SetTxt("AntiRollBarForce", txtAntiRollBarForce);
                SetTxt("CollisionDamageMult", txtCollisionDamageMult); SetTxt("WeaponDamageMult", txtWeaponDamageMult); SetTxt("EngineDamageMult", txtEngineDamageMult);
                SetTxt("PetrolTankVolume", txtPetrolTankVolume); SetTxt("OilVolume", txtOilVolume); SetTxt("MonetaryValue", txtMonetaryValue);
                SetCbo("HandlingType", cboHandlingType);
                SetTxt("AudioHash", txtAudioHash); SetCbo("AudioPreset", cboAudioPreset);
                SetCbo("WheelType", cboWheelType);

                if (values.TryGetValue("Extras", out var extrasStr))
                {
                    var checkedSet = new HashSet<string>(extrasStr.Split(';', StringSplitOptions.RemoveEmptyEntries));
                    for (int i = 0; i < clbExtras.Items.Count; i++)
                        clbExtras.SetItemChecked(i, checkedSet.Contains(clbExtras.Items[i].ToString()));
                }

                if (values.TryGetValue("Colors", out var colorsStr) && !string.IsNullOrEmpty(colorsStr))
                {
                    gridColors.Rows.Clear();
                    foreach (var rowStr in colorsStr.Split(';', StringSplitOptions.RemoveEmptyEntries))
                    {
                        var cells = rowStr.Split('|');
                        if (cells.Length == 4) gridColors.Rows.Add(cells[0], cells[1], cells[2], cells[3]);
                    }
                }

                lblStatus.Text = "✔ Preset loaded."; lblStatus.ForeColor = Theme.Success;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Couldn't load preset: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    // =========================================================================
    //  App Settings Panel
    //  Per-user preferences, paths, theme controls, keyboard shortcut reference
    //  and quick-access launchers for OpenIV / CodeWalker / GTA V.
    // =========================================================================
    internal class AppSettingsPanel : UserControl
    {
        public AppSettingsPanel()
        {
            this.BackColor = Theme.Background;
            Theme.ThemeChanged += () => this.BackColor = Theme.Background;
            Build();
        }

        private Label Lbl(string t, Point p, Color? c = null) => new Label { Text = t, AutoSize = true, Location = p, ForeColor = c ?? Theme.Muted, Font = new Font("Segoe UI", 8.5f) };
        private Button Btn(string t, int w, Color? bg = null) { var b = new Button { Text = t, Width = w, Height = 28, BackColor = bg ?? Theme.Surface, ForeColor = bg.HasValue ? Color.White : Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }
        private TextBox Txt(string v, Point p, int w) => new TextBox { Text = v, Location = p, Width = w, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f) };

        private void Build()
        {
            var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(24, 16, 24, 16) };
            this.Controls.Add(scroll);
            int y = 0;

            // ── GTA Paths ────────────────────────────────────────────────────
            scroll.Controls.Add(SectionLabel("GTA V Paths", y)); y += 32;
            scroll.Controls.Add(Lbl("GTA V root folder:", new Point(0, y))); y += 20;
            var txtGtaPath = Txt(AppSettings.GtaRoot ?? "", new Point(0, y), 640); scroll.Controls.Add(txtGtaPath);
            var btnBrowseGta = Btn("Browse…", 74); btnBrowseGta.Location = new Point(648, y - 1);
            btnBrowseGta.Click += (s, e) => { using var d = new FolderBrowserDialog { Description = "Select GTA V root" }; if (d.ShowDialog() == DialogResult.OK) { txtGtaPath.Text = d.SelectedPath; AppSettings.GtaRoot = d.SelectedPath; AppSettings.Save(); } };
            scroll.Controls.Add(btnBrowseGta); y += 38;

            scroll.Controls.Add(Lbl("OpenIV.exe path:", new Point(0, y))); y += 20;
            var txtOiv = Txt(AppSettings.OpenIvPath ?? "", new Point(0, y), 640); scroll.Controls.Add(txtOiv);
            var btnBrowseOiv = Btn("Browse…", 74); btnBrowseOiv.Location = new Point(648, y - 1);
            btnBrowseOiv.Click += (s, e) => { using var d = new OpenFileDialog { Title = "Find OpenIV.exe", Filter = "OpenIV|OpenIV.exe|Exe|*.exe" }; if (d.ShowDialog() == DialogResult.OK) { txtOiv.Text = d.FileName; AppSettings.OpenIvPath = d.FileName; AppSettings.Save(); } };
            scroll.Controls.Add(btnBrowseOiv); y += 46;

            // ── Quick Launchers ───────────────────────────────────────────────
            scroll.Controls.Add(SectionLabel("Quick Launchers", y)); y += 36;
            var btnLaunchOiv = Btn("🗂  Launch OpenIV", 160, Color.FromArgb(40, 80, 140));
            btnLaunchOiv.Location = new Point(0, y); btnLaunchOiv.Click += (s, e) => Launch(AppSettings.OpenIvPath, "OpenIV.exe");
            var btnLaunchGta = Btn("🎮  Launch GTA V", 160, Color.FromArgb(40, 100, 60));
            btnLaunchGta.Location = new Point(168, y); btnLaunchGta.Click += (s, e) => Launch(System.IO.Path.Combine(AppSettings.GtaRoot ?? "", " GTA5.exe"), "GTA5.exe");
            var btnOpenMods = Btn("📂  Open Mods Folder", 160);
            btnOpenMods.Location = new Point(336, y); btnOpenMods.Click += (s, e) => { var p2 = System.IO.Path.Combine(AppSettings.GtaRoot ?? "", "mods"); if (System.IO.Directory.Exists(p2)) System.Diagnostics.Process.Start("explorer.exe", p2); else MessageBox.Show("Mods folder not found. Set GTA root above."); };
            scroll.Controls.Add(btnLaunchOiv); scroll.Controls.Add(btnLaunchGta); scroll.Controls.Add(btnOpenMods); y += 46;

            // ── Appearance ────────────────────────────────────────────────────
            scroll.Controls.Add(SectionLabel("Appearance", y)); y += 36;
            var btnDark = Btn("🌙 Dark Theme", 120, Color.FromArgb(30, 30, 50)); btnDark.Location = new Point(0, y);
            btnDark.Click += (s, e) => { if (Theme.IsDark) return; Theme.ToggleTheme(); };
            var btnLight = Btn("☀ Light Theme", 120); btnLight.Location = new Point(128, y);
            btnLight.Click += (s, e) => { if (!Theme.IsDark) return; Theme.ToggleTheme(); };
            scroll.Controls.Add(btnDark); scroll.Controls.Add(btnLight); y += 46;

            // ── Keyboard Reference ────────────────────────────────────────────
            scroll.Controls.Add(SectionLabel("Keyboard Shortcuts", y)); y += 36;
            string[] shortcuts = {
                "File Renamer","Ctrl+Z — Undo last rename | Double-click group — Configure | ⏭ Next ⚠ — jump to unconfigured group",
                "Meta Editor","Ctrl+S — Save | Ctrl+F — Find | Enter (in Find box) — Find next | { } Format — Pretty-print XML",
                "Batch Processor","Drop folders onto the job list to add them | ■ Stop — cancel mid-run",
                "Toolbox","Enter in any input — run the tool | Drag file onto card — auto-fill and run",
                "General","All file/folder inputs accept drag and drop | Shift+click list items for multi-select",
            };
            for (int i = 0; i < shortcuts.Length; i += 2)
            {
                scroll.Controls.Add(Lbl(shortcuts[i], new Point(0, y), Theme.Accent)); y += 20;
                scroll.Controls.Add(Lbl(shortcuts[i + 1], new Point(16, y))); y += 28;
            }
            y += 10;

            // ── About ─────────────────────────────────────────────────────────
            scroll.Controls.Add(SectionLabel("About", y)); y += 36;
            scroll.Controls.Add(Lbl("GTA File Renamer – OpenIV Edition", new Point(0, y), Theme.Text)); y += 22;
            scroll.Controls.Add(Lbl($"Version {AppVersion.Current}", new Point(0, y), Theme.Muted)); y += 22;
            scroll.Controls.Add(Lbl("A comprehensive modding toolkit for GTA V: file renaming, FiveM↔SP conversion,", new Point(0, y))); y += 18;
            scroll.Controls.Add(Lbl("vehicle addon DLC building, RPF archive management, mod organising and more.", new Point(0, y))); y += 30;
            scroll.Controls.Add(Lbl("Built with CodeWalker.GameFiles. Requires GTA V + OpenIV for full functionality.", new Point(0, y), Theme.Muted)); y += 30;

            var btnCheckUpdate = Btn("🔄 Check for Updates", 170); btnCheckUpdate.Location = new Point(0, y);
            var lblUpdateStatus = Lbl("", new Point(180, y + 6));
            btnCheckUpdate.Click += async (s, e) =>
            {
                // Disabling the clicked button forces focus elsewhere — in
                // an AutoScroll panel with many controls, that can (and
                // did) snap the scroll position back to whatever control
                // ends up focused, which here was the GTA path field at
                // the very top of the page (added first, so first in tab
                // order). Capturing and restoring the scroll position
                // around the disable/enable cycle stops that jump
                // regardless of exactly where focus lands.
                var savedScroll = scroll.AutoScrollPosition;

                btnCheckUpdate.Enabled = false;
                lblUpdateStatus.Text = "Checking…"; lblUpdateStatus.ForeColor = Theme.Muted;
                var result = await UpdateChecker.CheckAsync();
                btnCheckUpdate.Enabled = true;
                scroll.AutoScrollPosition = new Point(-savedScroll.X, -savedScroll.Y); // AutoScrollPosition's getter returns negated values — negate back when setting

                if (result.Error != null)
                {
                    lblUpdateStatus.Text = "Couldn't check for updates — see details.";
                    lblUpdateStatus.ForeColor = Theme.Warning;
                    MessageBox.Show(result.Error, "Update Check Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (result.UpdateAvailable)
                {
                    lblUpdateStatus.Text = $"Update available: v{result.LatestVersion} (you have v{AppVersion.Current})";
                    lblUpdateStatus.ForeColor = Theme.Warning;

                    if (string.IsNullOrEmpty(result.DownloadUrl))
                    {
                        // This is the actual reason nothing was happening
                        // on every previous attempt — it was never a
                        // bootstrapper problem. A bare version string
                        // (like the current pastebin) has no way to encode
                        // a download link, so there's nothing for the
                        // updater to fetch. Say so plainly instead of the
                        // button silently doing nothing.
                        MessageBox.Show(
                            $"v{result.LatestVersion} is available, but there's no download link to fetch it from.\n\n" +
                            "Your current update source (the pastebin) is just a bare version number, which can't " +
                            "encode a download URL. Switch to either:\n\n" +
                            "  • GitHubRepo (set to \"owner/repo\") — pulls the download link from your GitHub " +
                            "Release's uploaded asset automatically, or\n" +
                            "  • CheckUrl pointing at JSON like {\"version\":\"1.2.0\",\"url\":\"...\",\"notes\":\"...\"}\n\n" +
                            "Either of those gives the updater an actual file to download.",
                            "No Download Link Available", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    var dlgResult = MessageBox.Show(
                        $"A new version is available: v{result.LatestVersion}\n\n{result.ReleaseNotes}\n\nDownload and install it now? " +
                        "(this closes GTA File Renamer and hands off to the updater)",
                        "Update Available", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (dlgResult == DialogResult.Yes)
                        AppUpdater.LaunchAndExit(result.DownloadUrl, result.LatestVersion);
                }
                else
                {
                    lblUpdateStatus.Text = "You're up to date.";
                    lblUpdateStatus.ForeColor = Theme.Success;
                }
            };
            scroll.Controls.Add(btnCheckUpdate); scroll.Controls.Add(lblUpdateStatus); y += 40;

            // ── Legal ─────────────────────────────────────────────────────────
            scroll.Controls.Add(SectionLabel("Legal", y)); y += 36;
            var disclaimerBox = new Label
            {
                Text = "This is an independent, non-commercial community tool. It is not affiliated with, " +
                       "endorsed by, or sponsored by Rockstar Games, Take-Two Interactive, or any of their " +
                       "subsidiaries. Grand Theft Auto and all related trademarks, logos, and copyrighted content " +
                       "are the property of their respective owners.\n\n" +
                       "This tool is provided free of charge for personal, non-commercial single-player use, " +
                       "consistent with Rockstar's stated modding policy. It does not modify, redistribute, or " +
                       "include any of Rockstar's copyrighted game files — it only helps you manage files on " +
                       "your own local installation.",
                AutoSize = false,
                Width = 680,
                Height = 100,
                Location = new Point(0, y),
                ForeColor = Theme.Muted,
                Font = new Font("Segoe UI", 8f),
            };
            scroll.Controls.Add(disclaimerBox); y += 110;

            // Save all path changes on text box leave
            txtGtaPath.Leave += (s, e) => { AppSettings.GtaRoot = txtGtaPath.Text.Trim(); AppSettings.Save(); };
            txtOiv.Leave += (s, e) => { AppSettings.OpenIvPath = txtOiv.Text.Trim(); AppSettings.Save(); };
        }

        private Label SectionLabel(string text, int y) => new Label { Text = text, AutoSize = true, Location = new Point(0, y), Font = new Font("Segoe UI", 10f, FontStyle.Bold), ForeColor = Theme.Accent };

        private static void Launch(string path, string fallback)
        {
            if (!string.IsNullOrEmpty(path) && System.IO.File.Exists(path)) { System.Diagnostics.Process.Start(path); return; }
            MessageBox.Show($"Path not set or file not found.\nSet the path in Settings above.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }


    // =========================================================================
    //  Dashboard Panel — the app's landing page. Pulls together a quick
    //  status overview (GTA folder, update check) and one-click tiles to
    //  jump straight into the most commonly used tools, rather than
    //  requiring the sidebar for everything on first open.
    //
    //  NavigateToRequested is wired up by MainShellModern.RegisterPages()
    //  to call the shell's own NavigateTo — this panel has no direct
    //  reference to the shell otherwise, since panels are just plain
    //  UserControls created by a factory function.
    // =========================================================================
    internal class DashboardPanel : UserControl
    {
        public Action<string> NavigateToRequested;

        private Label _lblGtaStatus;
        private Label _lblUpdateStatus;

        public DashboardPanel()
        {
            BackColor = Theme.Background;
            Theme.ThemeChanged += () => BackColor = Theme.Background;
            Build();
        }

        private void Build()
        {
            var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(24) };
            int y = 0;

            var lblWelcome = new Label
            {
                Text = "🎮  GTA File Renamer",
                Location = new Point(0, y),
                AutoSize = true,
                Font = new Font("Segoe UI Semibold", 20f, FontStyle.Bold),
                ForeColor = Theme.Text,
            };
            scroll.Controls.Add(lblWelcome);
            y += 44;

            var lblVersion = new Label
            {
                Text = $"Version {AppVersion.Current}  ·  OpenIV Edition",
                Location = new Point(0, y),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5f),
                ForeColor = Theme.Muted,
            };
            scroll.Controls.Add(lblVersion);
            y += 40;

            // ── Status row: GTA folder + update check, side by side ──────
            var statusPanel = new Panel { Location = new Point(0, y), Size = new Size(900, 92), BackColor = Theme.Surface };
            _lblGtaStatus = new Label { Location = new Point(16, 12), AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Theme.Text };
            var lblGtaPath = new Label { Location = new Point(16, 36), AutoSize = true, Font = new Font("Segoe UI", 8.5f), ForeColor = Theme.Muted, MaximumSize = new Size(420, 0) };
            var btnChangeGta = new Button { Text = "Change…", Location = new Point(16, 58), Width = 100, Height = 24, BackColor = Theme.Surface2, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8f) };
            btnChangeGta.FlatAppearance.BorderColor = Theme.Border;
            btnChangeGta.Click += (s, e) =>
            {
                var picked = GtaDirectoryPickerDialog.PickAndSave(this.FindForm());
                if (picked != null) RefreshGtaStatus(lblGtaPath);
            };

            var sep = new Panel { Location = new Point(450, 10), Width = 1, Height = 72, BackColor = Theme.Border };

            _lblUpdateStatus = new Label { Location = new Point(470, 12), AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Theme.Text, Text = "Update status: not checked yet" };
            var btnCheckUpdate = new Button { Text = "🔄 Check for Updates", Location = new Point(470, 36), Width = 170, Height = 24, BackColor = Theme.Surface2, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8f) };
            btnCheckUpdate.FlatAppearance.BorderColor = Theme.Border;
            var btnViewChangelog = new Button { Text = "📰 View Changelog", Location = new Point(648, 36), Width = 150, Height = 24, BackColor = Theme.Surface2, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8f) };
            btnViewChangelog.FlatAppearance.BorderColor = Theme.Border;
            btnViewChangelog.Click += (s, e) => NavigateToRequested?.Invoke("changelog");

            btnCheckUpdate.Click += async (s, e) =>
            {
                btnCheckUpdate.Enabled = false;
                _lblUpdateStatus.Text = "Checking for updates…";
                var result = await UpdateChecker.CheckAsync();
                btnCheckUpdate.Enabled = true;
                if (result.Error != null) { _lblUpdateStatus.Text = "Update check failed — see Settings for details."; _lblUpdateStatus.ForeColor = Theme.Warning; }
                else if (result.UpdateAvailable) { _lblUpdateStatus.Text = $"v{result.LatestVersion} available (go to Settings to update)"; _lblUpdateStatus.ForeColor = Theme.Warning; }
                else { _lblUpdateStatus.Text = "You're up to date."; _lblUpdateStatus.ForeColor = Theme.Success; }
            };

            statusPanel.Controls.AddRange(new Control[] { _lblGtaStatus, lblGtaPath, btnChangeGta, sep, _lblUpdateStatus, btnCheckUpdate, btnViewChangelog });
            scroll.Controls.Add(statusPanel);
            RefreshGtaStatus(lblGtaPath);
            y += 112;

            // ── Quick-launch tiles ─────────────────────────────────────────
            var lblQuick = new Label { Text = "QUICK LAUNCH", Location = new Point(0, y), AutoSize = true, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), ForeColor = Theme.Muted };
            scroll.Controls.Add(lblQuick);
            y += 28;

            var tiles = new (string Glyph, string Title, string Desc, string Key)[]
            {
                ("🧙", "Vehicle Wizard", "Build a complete vehicle from scratch or an existing meta.", "veh_wizard"),
                ("📋", "DLC Manager", "Edit dlclist.xml, convert packed ↔ loose update.rpf.", "dlc_manager"),
                ("🚗", "Live Spawner", "Spawn any installed addon vehicle instantly, no restart.", "live_spawner"),
                ("🗄", "Backup Manager", "Review, restore, or clean up every backup this tool made.", "backup_manager"),
                ("🔍", "RPF Explorer", "Browse and extract from any .rpf archive.", "rpf_explorer"),
                ("🩺", "Setup Health Check", "One-click diagnostic for your whole setup.", "health_check"),
            };

            int tileWidth = 280, tileHeight = 96, gap = 16, perRow = 3;
            for (int i = 0; i < tiles.Length; i++)
            {
                var (glyph, title, desc, key) = tiles[i];
                int col = i % perRow, row = i / perRow;
                var tile = MakeTile(glyph, title, desc, key);
                tile.Location = new Point(col * (tileWidth + gap), y + row * (tileHeight + gap));
                scroll.Controls.Add(tile);
            }
            y += ((tiles.Length + perRow - 1) / perRow) * (tileHeight + gap);

            Controls.Add(scroll);
        }

        private Panel MakeTile(string glyph, string title, string desc, string navigateKey)
        {
            var tile = new Panel
            {
                Size = new Size(280, 96),
                BackColor = Theme.Surface,
                Cursor = Cursors.Hand,
            };
            var lblGlyph = new Label { Text = glyph, Location = new Point(14, 14), AutoSize = true, Font = new Font("Segoe UI Emoji", 20f), ForeColor = Theme.Accent };
            var lblTitle = new Label { Text = title, Location = new Point(56, 14), AutoSize = true, Font = new Font("Segoe UI", 10f, FontStyle.Bold), ForeColor = Theme.Text };
            var lblDesc = new Label { Text = desc, Location = new Point(56, 38), Size = new Size(210, 50), Font = new Font("Segoe UI", 8f), ForeColor = Theme.Muted };

            tile.Controls.AddRange(new Control[] { lblGlyph, lblTitle, lblDesc });

            // Whole tile is clickable, including its children — a click on
            // any label inside should still trigger navigation, not just
            // the panel's own background.
            void WireClick(Control c)
            {
                c.Cursor = Cursors.Hand;
                c.Click += (s, e) => NavigateToRequested?.Invoke(navigateKey);
                c.MouseEnter += (s, e) => tile.BackColor = Theme.Surface2;
                c.MouseLeave += (s, e) => tile.BackColor = Theme.Surface;
                foreach (Control child in c.Controls) WireClick(child);
            }
            WireClick(tile);

            return tile;
        }

        private void RefreshGtaStatus(Label pathLabel)
        {
            if (AppSettings.HasGtaDirectory)
            {
                _lblGtaStatus.Text = "✅ GTA V folder set";
                _lblGtaStatus.ForeColor = Theme.Success;
                pathLabel.Text = AppSettings.GtaDirectory;
            }
            else
            {
                _lblGtaStatus.Text = "⚠ GTA V folder not set";
                _lblGtaStatus.ForeColor = Theme.Warning;
                pathLabel.Text = "Set it below, or you'll be asked the first time you need it.";
            }
        }
    }

    // =========================================================================
    //  Changelog Panel
    //
    //  A manually-maintained version history list, alongside a shortcut to
    //  the same "Check for Updates" flow that's on the Settings page. The
    //  History array below is a plain list you add to yourself each time
    //  you release a new version — there's no way for this to know your
    //  actual release history automatically, so it starts seeded with
    //  just the current version rather than inventing entries.
    // =========================================================================
    internal class ChangelogPanel : UserControl
    {
        // ── Add an entry here each time you publish a new version. Newest
        //    first. This is the only place you need to touch to keep this
        //    page accurate — nothing else reads from or writes to it. ────
        private static readonly (string Version, string Date, string Notes)[] History = new[]
        {
            ("1.2.0", "2026-07-03",
                "Self-updating bootstrapper (download, apply, relaunch automatically).\n" +
                "Vehicle Wizard: expanded handling.meta fields, real carvariations.meta generation, " +
                "wheels & extras step, import from an existing vehicles.meta/handling.meta, save/load presets.\n" +
                "GitHub Releases integration for update checks.\n" +
                "Legal/About page disclaimer, global crash handler."),
        };

        public ChangelogPanel()
        {
            BackColor = Theme.Background;
            Theme.ThemeChanged += () => BackColor = Theme.Background;
            Build();
        }

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 56, BackColor = Theme.Surface, Padding = new Padding(16, 12, 16, 12) };
            var lblCurrent = new Label
            {
                Text = $"Current version: {AppVersion.Current}",
                AutoSize = true,
                Location = new Point(0, 4),
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Theme.Text,
            };
            var btnCheck = new Button
            {
                Text = "🔄 Check for Updates",
                Width = 160, Height = 28,
                Location = new Point(0, 26),
                BackColor = Theme.Surface2, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8.5f),
            };
            btnCheck.FlatAppearance.BorderColor = Theme.Border;
            var lblCheckStatus = new Label { Location = new Point(170, 32), AutoSize = true, ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f) };

            btnCheck.Click += async (s, e) =>
            {
                btnCheck.Enabled = false;
                lblCheckStatus.Text = "Checking…"; lblCheckStatus.ForeColor = Theme.Muted;
                var result = await UpdateChecker.CheckAsync();
                btnCheck.Enabled = true;
                if (result.Error != null) { lblCheckStatus.Text = "Check failed — see Settings page for details."; lblCheckStatus.ForeColor = Theme.Warning; }
                else if (result.UpdateAvailable) { lblCheckStatus.Text = $"v{result.LatestVersion} available — go to Settings to update."; lblCheckStatus.ForeColor = Theme.Warning; }
                else { lblCheckStatus.Text = "You're up to date."; lblCheckStatus.ForeColor = Theme.Success; }
            };

            top.Controls.AddRange(new Control[] { lblCurrent, btnCheck, lblCheckStatus });

            var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(16) };
            int y = 8;
            foreach (var (version, date, notes) in History)
            {
                var header = new Label
                {
                    Text = $"v{version}  —  {date}",
                    Location = new Point(0, y),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                    ForeColor = Theme.Accent,
                };
                scroll.Controls.Add(header);
                y += 26;

                foreach (var line in notes.Split('\n'))
                {
                    var lbl = new Label
                    {
                        Text = "•  " + line,
                        Location = new Point(12, y),
                        AutoSize = false,
                        Width = 720,
                        Height = 20,
                        ForeColor = Theme.Text,
                        Font = new Font("Segoe UI", 8.5f),
                    };
                    scroll.Controls.Add(lbl);
                    y += 22;
                }
                y += 20; // gap before next version
            }

            if (History.Length == 0)
            {
                scroll.Controls.Add(new Label { Text = "No changelog entries yet.", Location = new Point(0, y), AutoSize = true, ForeColor = Theme.Muted });
            }

            Controls.Add(scroll);
            Controls.Add(top);
        }
    }

    // =========================================================================
    //  Setup Health Check Panel
    //
    //  One-click diagnostic pulling together everything this project has
    //  learned about what can go wrong with a GTA V mods setup over this
    //  codebase's history: is update.rpf loose or packed, is dlclist.xml
    //  well-formed, is the LiveVehicleLoader RPH plugin actually in place,
    //  is LML detected, are there orphaned backup files piling up. Purely
    //  read-only — every check here only inspects the filesystem, never
    //  writes anything.
    // =========================================================================
    internal class SetupHealthCheckPanel : UserControl
    {
        private ListView _list;
        private Label _lblSummary;
        private Button _btnRunAll;
        private string _gtaRoot;

        private enum CheckStatus { Ok, Warning, Error, Info }

        public SetupHealthCheckPanel()
        {
            BackColor = Theme.Background;
            Theme.ThemeChanged += () => BackColor = Theme.Background;
            Build();
            _gtaRoot = AppSettings.HasGtaDirectory ? AppSettings.GtaDirectory : null;
            RunChecks();
        }

        private Button Btn(string t, int w, Color? bg = null) { var b = new Button { Text = t, Width = w, Height = 28, BackColor = bg ?? Theme.Surface, ForeColor = bg.HasValue ? Color.White : Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 64, BackColor = Theme.Surface, Padding = new Padding(12, 12, 12, 12) };
            _btnRunAll = Btn("🩺 Run All Checks", 150, Theme.Accent);
            _btnRunAll.Location = new Point(0, 0);
            _btnRunAll.Click += (s, e) => RunChecks();

            var btnChangeRoot = Btn("📁 Change GTA Folder", 170);
            btnChangeRoot.Location = new Point(158, 0);
            btnChangeRoot.Click += (s, e) =>
            {
                var picked = GtaDirectoryPickerDialog.PickAndSave(this.FindForm());
                if (picked != null) { _gtaRoot = picked; RunChecks(); }
            };

            top.Controls.AddRange(new Control[] { _btnRunAll, btnChangeRoot });

            _list = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                BackColor = Theme.ListBg,
                ForeColor = Theme.Text,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 8.5f),
            };
            _list.Columns.Add("Status", 70);
            _list.Columns.Add("Check", 220);
            _list.Columns.Add("Result", 700);

            _lblSummary = new Label { Dock = DockStyle.Bottom, Height = 30, ForeColor = Theme.Muted, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(10, 0, 0, 0), BackColor = Theme.Surface };

            Controls.Add(_list);
            Controls.Add(_lblSummary);
            Controls.Add(top);
        }

        private void AddResult(CheckStatus status, string check, string result)
        {
            string icon = status switch { CheckStatus.Ok => "✅", CheckStatus.Warning => "⚠️", CheckStatus.Error => "❌", _ => "ℹ️" };
            var color = status switch { CheckStatus.Ok => Theme.Success, CheckStatus.Warning => Theme.Warning, CheckStatus.Error => Theme.Danger, _ => Theme.Muted };
            var lvi = new ListViewItem(icon);
            lvi.SubItems.Add(check);
            lvi.SubItems.Add(result);
            lvi.ForeColor = color;
            _list.Items.Add(lvi);
        }

        private void RunChecks()
        {
            _list.Items.Clear();
            int ok = 0, warn = 0, err = 0;

            void Track(CheckStatus s, string check, string result)
            {
                AddResult(s, check, result);
                if (s == CheckStatus.Ok) ok++;
                else if (s == CheckStatus.Warning) warn++;
                else if (s == CheckStatus.Error) err++;
            }

            // ── GTA folder ────────────────────────────────────────────────
            if (string.IsNullOrEmpty(_gtaRoot) || !Directory.Exists(_gtaRoot))
            {
                Track(CheckStatus.Error, "GTA V folder", "Not set, or the saved folder no longer exists. Use \"Change GTA Folder\" above.");
                _lblSummary.Text = $" {ok} OK  •  {warn} warning(s)  •  {err} error(s)";
                return; // nothing else can be checked meaningfully without this
            }
            Track(CheckStatus.Ok, "GTA V folder", _gtaRoot);

            // ── update.rpf state ─────────────────────────────────────────
            string updateRpfPath = Path.Combine(_gtaRoot, "mods", "update", "update.rpf");
            bool looseFolder = Directory.Exists(updateRpfPath);
            bool packedFile = File.Exists(updateRpfPath);
            if (looseFolder)
                Track(CheckStatus.Ok, "update.rpf", "Loose folder — dlclist.xml edits save directly, no repack risk.");
            else if (packedFile)
                Track(CheckStatus.Warning, "update.rpf", "Packed archive — dlclist.xml edits need manual OpenIV, or a one-time conversion (DLC Manager page).");
            else
                Track(CheckStatus.Info, "update.rpf", "Not found at the expected path — mods folder may not be set up yet.");

            // ── dlclist.xml well-formed? ─────────────────────────────────
            string dlcListXml = null;
            if (looseFolder)
            {
                string path = Path.Combine(updateRpfPath, "common", "data", "dlclist.xml");
                if (File.Exists(path)) { try { dlcListXml = File.ReadAllText(path); } catch { } }
            }
            else if (packedFile)
            {
                try { dlcListXml = RpfBuilder.ExtractDlcListXml(_gtaRoot); } catch { }
            }

            if (dlcListXml == null)
            {
                Track(CheckStatus.Info, "dlclist.xml", "Couldn't read it (see update.rpf result above).");
            }
            else if (dlcListXml.Contains("</SMandatoryPacksData>") && dlcListXml.Contains("</Paths>"))
            {
                int entryCount = Regex.Matches(dlcListXml, "<Item>").Count;
                Track(CheckStatus.Ok, "dlclist.xml", $"Well-formed — {entryCount} entries.");
            }
            else
            {
                Track(CheckStatus.Error, "dlclist.xml", "Missing expected closing tags (</Paths></SMandatoryPacksData>) — looks truncated/corrupted. See Backup Manager to restore a known-good copy.");
            }

            // ── LiveVehicleLoader RPH plugin ─────────────────────────────
            string pluginPath = Path.Combine(_gtaRoot, "Plugins", "LiveVehicleLoaderPlugin.dll");
            if (File.Exists(pluginPath))
                Track(CheckStatus.Ok, "LiveVehicleLoader plugin", $"Found at {pluginPath}");
            else
                Track(CheckStatus.Info, "LiveVehicleLoader plugin", "Not found in Plugins\\ — instant spawn (Test/Inject Addon page) won't work until it's installed there.");

            // ── LML ───────────────────────────────────────────────────────
            string lmlFolder = Path.Combine(_gtaRoot, "lml");
            string vfsDll = Path.Combine(_gtaRoot, "vfs.dll");
            if (Directory.Exists(lmlFolder) && File.Exists(vfsDll))
                Track(CheckStatus.Ok, "Lenny's Mod Loader", "Detected (lml\\ folder and vfs.dll both present).");
            else if (Directory.Exists(lmlFolder) || File.Exists(vfsDll))
                Track(CheckStatus.Warning, "Lenny's Mod Loader", "Partially detected — one of lml\\ or vfs.dll is missing. Reinstalling LML may fix this.");
            else
                Track(CheckStatus.Info, "Lenny's Mod Loader", "Not detected — fine if you don't use it; the LML export option elsewhere is greyed out until it is.");

            // ── OpenIV (best-effort — no reliable single signal) ─────────
            string openIvGuess = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "New Technology Studio", "Apps", "OpenIV", "OpenIV.exe");
            Track(File.Exists(openIvGuess) ? CheckStatus.Ok : CheckStatus.Info,
                "OpenIV",
                File.Exists(openIvGuess) ? $"Found at {openIvGuess}" : "Not found at the default install location — this is a best-effort check, it may just be installed elsewhere.");

            // ── Orphaned backups ──────────────────────────────────────────
            string updateDir = Path.Combine(_gtaRoot, "mods", "update");
            if (Directory.Exists(updateDir))
            {
                var backups = Directory.GetFileSystemEntries(updateDir, "update.rpf.*");
                if (backups.Length == 0)
                    Track(CheckStatus.Ok, "Backups", "None found — nothing to clean up.");
                else
                    Track(CheckStatus.Info, "Backups", $"{backups.Length} backup item(s) in mods\\update\\ — see Backup Manager to review or clean these up.");
            }

            _lblSummary.Text = $" {ok} OK  •  {warn} warning(s)  •  {err} error(s)  —  last run {DateTime.Now:HH:mm:ss}";
            _lblSummary.ForeColor = err > 0 ? Theme.Danger : (warn > 0 ? Theme.Warning : Theme.Success);
        }
    }

    // =========================================================================
    //  Live Spawner Panel
    //
    //  Aggregates spawnable models across EVERY installed DLC folder (not
    //  just whatever's currently staged on the Test/Inject Addon page),
    //  using the same LiveVehicleLoader.FindSpawnableModels tree-walk
    //  already proven there, and the same TrySpawnAsync pipe call to the
    //  RPH plugin. Doesn't duplicate that logic — just applies it across
    //  dlcpacks\* instead of a single folder.
    // =========================================================================
    internal class LiveSpawnerPanel : UserControl
    {
        private TextBox _txtFilter;
        private ListView _list;
        private Label _lblStatus, _lblCount;
        private Button _btnScan, _btnSpawn;
        private CheckBox _chkInGameMenu;
        private string _gtaRoot;

        private class SpawnEntry { public string Model; public string DlcFolder; }
        private List<SpawnEntry> _all = new List<SpawnEntry>();

        public LiveSpawnerPanel()
        {
            BackColor = Theme.Background;
            Theme.ThemeChanged += () => BackColor = Theme.Background;
            Build();
            _gtaRoot = AppSettings.HasGtaDirectory ? AppSettings.GtaDirectory : null;
            _chkInGameMenu.Checked = LoadInGameMenuConfig();
        }

        // ── Shared config file the RPH plugin reads once at startup (see
        //    LiveVehicleLoaderPlugin.cs's LoadInGameMenuEnabled). Written
        //    to <gtaRoot> directly (NOT a Plugins subfolder) — confirmed
        //    empirically from the plugin's own diagnostic log, which
        //    showed AppDomain.CurrentDomain.BaseDirectory for its remote
        //    AppDomain resolves to the game root itself, not Plugins\.
        //    (The original assumption that it'd match Plugins\ — based on
        //    that being where the .dll loads from — turned out wrong;
        //    RPH apparently sets the AppDomain's ApplicationBase to the
        //    game root regardless of which folder the plugin file is in.) ──
        private string InGameMenuConfigPath =>
            string.IsNullOrEmpty(_gtaRoot) ? null : System.IO.Path.Combine(_gtaRoot, "LiveVehicleLoaderPlugin.settings.json");

        private bool LoadInGameMenuConfig()
        {
            try
            {
                var path = InGameMenuConfigPath;
                if (string.IsNullOrEmpty(path) || !System.IO.File.Exists(path)) return false;
                string json = System.IO.File.ReadAllText(path);
                return System.Text.RegularExpressions.Regex.IsMatch(json, "\"enabled\"\\s*:\\s*true", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            }
            catch { return false; }
        }

        private void SaveInGameMenuConfig(bool enabled)
        {
            var path = InGameMenuConfigPath;
            if (string.IsNullOrEmpty(path))
            {
                MessageBox.Show("Set your GTA folder first (Change GTA Folder above).", "No GTA Folder Set", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var dir = System.IO.Path.GetDirectoryName(path);
                if (!System.IO.Directory.Exists(dir))
                {
                    MessageBox.Show(
                        $"GTA folder not found at:\n  {dir}\n" +
                        "Set/confirm your GTA folder above before enabling this.",
                        "Folder Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                System.IO.File.WriteAllText(path, $"{{\"enabled\":{(enabled ? "true" : "false")}}}");
                _lblStatus.Text = enabled
                    ? "In-game menu enabled — reload the plugin in RPH (or restart the game) for it to take effect. Press F9 in-game to open it."
                    : "In-game menu disabled — reload the plugin in RPH (or restart the game) for it to take effect.";
                _lblStatus.ForeColor = Theme.Warning;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Couldn't save the setting: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Button Btn(string t, int w, Color? bg = null) { var b = new Button { Text = t, Width = w, Height = 28, BackColor = bg ?? Theme.Surface, ForeColor = bg.HasValue ? Color.White : Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 96, BackColor = Theme.Surface, Padding = new Padding(12, 12, 12, 12) };

            _btnScan = Btn("🔍 Scan All Installed Addons", 200, Theme.Accent);
            _btnScan.Location = new Point(0, 0);
            _btnScan.Click += (s, e) => ScanAll();

            var btnChangeRoot = Btn("📁 Change GTA Folder", 170);
            btnChangeRoot.Location = new Point(208, 0);
            btnChangeRoot.Click += (s, e) =>
            {
                var picked = GtaDirectoryPickerDialog.PickAndSave(this.FindForm());
                if (picked != null) { _gtaRoot = picked; ScanAll(); }
            };

            _txtFilter = new TextBox { Location = new Point(388, 2), Width = 260, BackColor = Theme.Background, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, PlaceholderText = "🔎 Filter models…", Font = new Font("Segoe UI", 8.5f) };
            _txtFilter.TextChanged += (s, e) => RebuildList();

            _btnSpawn = Btn("🚗 Spawn Selected", 150, Theme.Accent);
            _btnSpawn.Location = new Point(658, 0);
            _btnSpawn.Enabled = false;
            _btnSpawn.Click += async (s, e) => await SpawnSelectedAsync();

            // ── In-game menu toggle — writes a small shared JSON config
            //    file the RPH plugin reads once at startup (RPH plugins
            //    don't hot-reload, so this needs a plugin reload/game
            //    restart to take effect after being changed — the label
            //    says so directly rather than implying it's instant). ────
            _chkInGameMenu = new CheckBox
            {
                Text = "🎮 Enable In-Game Menu (F9 to open — requires plugin reload)",
                Location = new Point(0, 40),
                AutoSize = true,
                ForeColor = Theme.Text,
                Font = new Font("Segoe UI", 8.5f),
            };
            _chkInGameMenu.CheckedChanged += (s, e) => SaveInGameMenuConfig(_chkInGameMenu.Checked);

            top.Controls.AddRange(new Control[] { _btnScan, btnChangeRoot, _txtFilter, _btnSpawn, _chkInGameMenu });

            _list = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                MultiSelect = false,
                GridLines = true,
                BackColor = Theme.ListBg,
                ForeColor = Theme.Text,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 8.5f),
            };
            _list.Columns.Add("Model / Spawn Name", 320);
            _list.Columns.Add("Installed DLC Folder", 320);
            _list.SelectedIndexChanged += (s, e) => _btnSpawn.Enabled = _list.SelectedItems.Count > 0;
            _list.DoubleClick += async (s, e) => await SpawnSelectedAsync();

            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 30, BackColor = Theme.Surface };
            _lblStatus = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f), Text = "Scan to list every spawnable model across your installed addons." };
            bottom.Controls.Add(_lblStatus);

            var infoBar = new Panel { Dock = DockStyle.Top, Height = 26, BackColor = Color.FromArgb(22, 22, 22) };
            _lblCount = new Label { AutoSize = true, Location = new Point(12, 6), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8.5f) };
            infoBar.Controls.Add(_lblCount);

            Controls.Add(_list);
            Controls.Add(bottom);
            Controls.Add(infoBar);
            Controls.Add(top);
        }

        private void ScanAll()
        {
            if (string.IsNullOrEmpty(_gtaRoot))
            {
                _gtaRoot = GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
                if (string.IsNullOrEmpty(_gtaRoot)) return;
            }

            string dlcpacksPath = Path.Combine(_gtaRoot, "mods", "update", "x64", "dlcpacks");
            if (!Directory.Exists(dlcpacksPath))
            {
                _lblStatus.Text = $"dlcpacks folder not found at {dlcpacksPath}";
                _lblStatus.ForeColor = Theme.Danger;
                return;
            }

            _all.Clear();
            _btnScan.Enabled = false;
            _lblStatus.Text = "Scanning…";
            _lblStatus.ForeColor = Theme.Warning;
            Application.DoEvents();

            foreach (var dlcFolder in Directory.GetDirectories(dlcpacksPath))
            {
                string dlcName = Path.GetFileName(dlcFolder);
                List<string> models;
                try { models = LiveVehicleLoader.FindSpawnableModels(dlcFolder); }
                catch { continue; }

                foreach (var m in models)
                    _all.Add(new SpawnEntry { Model = m, DlcFolder = dlcName });
            }

            _btnScan.Enabled = true;
            RebuildList();
            _lblStatus.Text = LiveVehicleLoader.IsGtaRunning()
                ? "GTA5.exe is running — ready to spawn."
                : "GTA5.exe isn't running — start the game first to spawn.";
            _lblStatus.ForeColor = LiveVehicleLoader.IsGtaRunning() ? Theme.Success : Theme.Warning;
        }

        private void RebuildList()
        {
            _list.Items.Clear();
            string filter = _txtFilter.Text.Trim();
            var filtered = string.IsNullOrEmpty(filter)
                ? _all
                : _all.Where(e => e.Model.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0).ToList();

            foreach (var e in filtered.OrderBy(e => e.Model))
            {
                var lvi = new ListViewItem(e.Model);
                lvi.SubItems.Add(e.DlcFolder);
                lvi.Tag = e;
                _list.Items.Add(lvi);
            }
            _lblCount.Text = $"{_all.Count} model(s) across {_all.Select(e => e.DlcFolder).Distinct().Count()} installed addon(s)" +
                              (filtered.Count != _all.Count ? $"  —  {filtered.Count} shown" : "");
        }

        private async Task SpawnSelectedAsync()
        {
            if (_list.SelectedItems.Count == 0) return;
            if (_list.SelectedItems[0].Tag is not SpawnEntry entry) return;

            _btnSpawn.Enabled = false;
            _lblStatus.Text = $"Spawning '{entry.Model}' …";
            _lblStatus.ForeColor = Theme.Warning;

            var result = await LiveVehicleLoader.TrySpawnAsync(entry.Model);

            _btnSpawn.Enabled = true;
            _lblStatus.Text = result.Message;
            _lblStatus.ForeColor = result.Success ? Theme.Success : Theme.Danger;
        }
    }

    // =========================================================================
    //  Load Order Manager Panel
    //
    //  A friendlier, drag-to-reorder view of the same dlclist.xml the DLC
    //  Manager page edits as a plain list — same read/write rules (loose
    //  file only, backed up before every save, packed archives shown
    //  read-only via RpfBuilder.ExtractDlcListXml) since load order only
    //  ever lives in that one file regardless of which page is editing it.
    // =========================================================================
    internal class LoadOrderManagerPanel : UserControl
    {
        private ListBox _listBox;
        private Label _lblStatus;
        private Button _btnSave;
        private string _loadedPath = "";
        private bool _readOnly = false;
        private string _gtaRoot;
        private List<string> _entries = new List<string>();

        // ── Manual drag state — no DoDragDrop/OLE involved at all, see the
        //    comment on MouseDown below for why. ────────────────────────────
        private int _dragSourceIndex = -1;
        private int _dragHoverIndex = -1;
        private bool _dragging = false;
        private Point _dragStartPoint;

        public LoadOrderManagerPanel()
        {
            BackColor = Theme.Background;
            Theme.ThemeChanged += () => BackColor = Theme.Background;
            Build();
            _gtaRoot = AppSettings.HasGtaDirectory ? AppSettings.GtaDirectory : null;
        }

        private Button Btn(string t, int w, Color? bg = null) { var b = new Button { Text = t, Width = w, Height = 28, BackColor = bg ?? Theme.Surface, ForeColor = bg.HasValue ? Color.White : Theme.Text, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f) }; b.FlatAppearance.BorderColor = Theme.Border; b.FlatAppearance.BorderSize = 1; return b; }

        private void Build()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 64, BackColor = Theme.Surface, Padding = new Padding(12, 12, 12, 12) };

            var btnLoad = Btn("🔍 Auto-Detect & Load", 170, Theme.Accent);
            btnLoad.Location = new Point(0, 0);
            btnLoad.Click += (s, e) => LoadDlcList();

            _btnSave = Btn("💾 Save Order", 130);
            _btnSave.Location = new Point(178, 0);
            _btnSave.Enabled = false;
            _btnSave.Click += (s, e) => SaveOrder();

            var lblHint = new Label
            {
                Text = "Drag entries up/down to reorder. Load order affects which mod's files win when two DLCs contain the same filename.",
                Location = new Point(320, 6),
                Size = new Size(560, 32),
                ForeColor = Theme.Muted,
                Font = new Font("Segoe UI", 8f),
            };

            top.Controls.AddRange(new Control[] { btnLoad, _btnSave, lblHint });

            _listBox = new ListBox
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.ListBg,
                ForeColor = Theme.Text,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 9f),
                DrawMode = DrawMode.OwnerDrawFixed,
                ItemHeight = 22,
            };
            _listBox.DrawItem += ListBox_DrawItem;
            _listBox.MouseDown += ListBox_MouseDown;
            _listBox.MouseMove += ListBox_MouseMove;
            _listBox.MouseUp += ListBox_MouseUp;

            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 30, BackColor = Theme.Surface };
            _lblStatus = new Label { AutoSize = true, Location = new Point(12, 7), ForeColor = Theme.Muted, Font = new Font("Segoe UI", 8f), Text = "Click Auto-Detect & Load to begin." };
            bottom.Controls.Add(_lblStatus);

            Controls.Add(_listBox);
            Controls.Add(bottom);
            Controls.Add(top);
        }

        private void ListBox_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            e.DrawBackground();
            bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
            var bg = selected ? Theme.AccentDim : Theme.ListBg;
            using (var brush = new SolidBrush(bg)) e.Graphics.FillRectangle(brush, e.Bounds);

            string text = $"{e.Index + 1,4}.  {_listBox.Items[e.Index]}";
            using var textBrush = new SolidBrush(Theme.Text);
            e.Graphics.DrawString(text, e.Font, textBrush, e.Bounds.Left + 4, e.Bounds.Top + 2);

            // While dragging, draw a bright insertion line above/below
            // whichever row the cursor is currently over, so there's clear
            // visual feedback without relying on OS-level drag cursors at
            // all (this whole mechanism is plain mouse tracking).
            if (_dragging && e.Index == _dragHoverIndex)
            {
                using var indicatorPen = new Pen(Theme.Accent, 2);
                bool below = _dragHoverIndex > _dragSourceIndex;
                int y = below ? e.Bounds.Bottom - 1 : e.Bounds.Top + 1;
                e.Graphics.DrawLine(indicatorPen, e.Bounds.Left, y, e.Bounds.Right, y);
            }
            if (_dragging && e.Index == _dragSourceIndex)
            {
                using var ghostBrush = new SolidBrush(Color.FromArgb(60, Theme.Accent));
                e.Graphics.FillRectangle(ghostBrush, e.Bounds);
            }

            e.DrawFocusRectangle();
        }

        // ── Manual drag-to-reorder — deliberately NOT using DoDragDrop/OLE.
        //    A first attempt used Control.DoDragDrop, which starts a native
        //    OS-level drag operation; in real use it never visibly started
        //    at all (no cursor change, nothing), which points at the OLE
        //    drag negotiation failing at a lower level than anything this
        //    code controls (mouse-capture conflicts with the ListBox's own
        //    built-in click handling are a known source of exactly this
        //    symptom). Rather than keep guessing at native drag-drop
        //    internals that can't be tested without a Windows machine, this
        //    tracks the mouse directly with plain MouseDown/MouseMove/
        //    MouseUp — no OS drag session, no IDataObject, nothing that can
        //    fail for OLE-related reasons. This is standard practice for
        //    in-list reordering specifically (as opposed to dragging
        //    between different controls, which is what DoDragDrop is
        //    really meant for). ────────────────────────────────────────────
        private void ListBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (_readOnly || e.Button != MouseButtons.Left) return;
            int index = _listBox.IndexFromPoint(e.Location);
            if (index < 0) return;
            _dragSourceIndex = index;
            _dragHoverIndex = index;
            _dragStartPoint = e.Location;
            _dragging = false; // only becomes true once the mouse actually moves past a small threshold — see MouseMove
        }

        private void ListBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (_readOnly || _dragSourceIndex < 0 || e.Button != MouseButtons.Left) return;

            if (!_dragging)
            {
                // Require a small movement threshold before starting the
                // drag, so a plain click (no movement) doesn't get treated
                // as a zero-distance drag.
                if (Math.Abs(e.Location.Y - _dragStartPoint.Y) < 4) return;
                _dragging = true;
                _listBox.Cursor = Cursors.Hand;
                _listBox.Capture = true; // guarantees MouseMove/MouseUp keep routing here even if the cursor leaves the control's bounds mid-drag
            }

            int hover = _listBox.IndexFromPoint(e.Location);
            if (hover < 0) hover = e.Location.Y < 0 ? 0 : _listBox.Items.Count - 1;
            if (hover != _dragHoverIndex)
            {
                _dragHoverIndex = hover;
                _listBox.Invalidate();
            }
        }

        private void ListBox_MouseUp(object sender, MouseEventArgs e)
        {
            _listBox.Cursor = Cursors.Default;
            _listBox.Capture = false;
            if (_readOnly || !_dragging || _dragSourceIndex < 0)
            {
                _dragSourceIndex = -1; _dragHoverIndex = -1; _dragging = false;
                return;
            }

            int sourceIndex = _dragSourceIndex;
            int targetIndex = _dragHoverIndex;
            _dragSourceIndex = -1; _dragHoverIndex = -1; _dragging = false;

            if (sourceIndex < 0 || sourceIndex >= _entries.Count) { _listBox.Invalidate(); return; }
            if (targetIndex < 0 || targetIndex >= _entries.Count) targetIndex = _entries.Count - 1;
            if (sourceIndex == targetIndex) { _listBox.Invalidate(); return; }

            var item = _entries[sourceIndex];
            _entries.RemoveAt(sourceIndex);
            // Re-insertion target shifts by one if the item moved from
            // earlier in the list to later, since removing it first
            // shifts every subsequent index down by one.
            if (sourceIndex < targetIndex) targetIndex--;
            _entries.Insert(targetIndex, item);

            RebuildListBox();
            _listBox.SelectedIndex = targetIndex;
            _btnSave.Enabled = !_readOnly;
            _lblStatus.Text = $"Moved to position {targetIndex + 1}. Not saved yet.";
            _lblStatus.ForeColor = Theme.Warning;
        }

        private void RebuildListBox()
        {
            _listBox.Items.Clear();
            foreach (var e in _entries) _listBox.Items.Add(e);
        }

        private void LoadDlcList()
        {
            string gtaRoot = _gtaRoot ?? GtaDirectoryPickerDialog.GetOrPick(this.FindForm());
            if (string.IsNullOrEmpty(gtaRoot)) return;
            _gtaRoot = gtaRoot;

            string loosePath = Path.Combine(gtaRoot, "mods", "update", "update.rpf", "common", "data", "dlclist.xml");
            string xml;
            if (File.Exists(loosePath))
            {
                xml = File.ReadAllText(loosePath);
                _loadedPath = loosePath;
                _readOnly = false;
            }
            else
            {
                string extracted = null;
                try { extracted = RpfBuilder.ExtractDlcListXml(gtaRoot); } catch { }
                if (string.IsNullOrEmpty(extracted))
                {
                    MessageBox.Show("Couldn't find or read dlclist.xml.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                xml = extracted;
                _loadedPath = "";
                _readOnly = true;
            }

            _entries.Clear();
            foreach (Match m in Regex.Matches(xml, @"<Item>\s*(dlcpacks:[^<]+)\s*</Item>"))
                _entries.Add(m.Groups[1].Value.Trim());

            RebuildListBox();
            _btnSave.Enabled = false;

            _lblStatus.Text = _readOnly
                ? $"Loaded {_entries.Count} entries (READ-ONLY — packed update.rpf, no loose override to save to)."
                : $"Loaded {_entries.Count} entries from {_loadedPath}.";
            _lblStatus.ForeColor = _readOnly ? Theme.Warning : Theme.Success;
        }

        private void SaveOrder()
        {
            if (_readOnly || string.IsNullOrEmpty(_loadedPath))
            {
                MessageBox.Show(
                    "This was loaded read-only from a packed update.rpf — there's no loose file to save the new " +
                    "order to. Use the DLC Manager page's conversion options first, then reorder here.",
                    "Can't Save", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string backup = $"{_loadedPath}.backup_{DateTime.Now:yyyyMMdd_HHmmss}";
                File.Copy(_loadedPath, backup, overwrite: false);

                var sb = new StringBuilder();
                sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendLine("<SMandatoryPacksData>");
                sb.AppendLine("\t<Paths>");
                foreach (var entry in _entries)
                    sb.AppendLine($"\t\t<Item>{entry}</Item>");
                sb.AppendLine("\t</Paths>");
                sb.AppendLine("</SMandatoryPacksData>");

                File.WriteAllText(_loadedPath, sb.ToString(), Encoding.UTF8);
                _btnSave.Enabled = false;
                _lblStatus.Text = $"Saved new load order — {_entries.Count} entries. Backup kept at {Path.GetFileName(backup)}.";
                _lblStatus.ForeColor = Theme.Success;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Save failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    // =========================================================================
    //  App version + update checking
    //
    //  UpdateChecker fetches a small JSON manifest from a configurable URL
    //  and compares it against AppVersion.Current. Deliberately generic —
    //  point CheckUrl at wherever you actually host releases (a GitHub
    //  Releases API URL works fine: e.g.
    //  https://api.github.com/repos/you/repo/releases/latest — just note
    //  its JSON uses "tag_name" instead of "version", so adjust the field
    //  name below to match whatever you actually host, or keep this
    //  pointed at your own simple {"version":"...","url":"...","notes":"..."}
    //  file if you're not using GitHub Releases).
    // =========================================================================
    internal static class AppVersion
    {
        public static readonly string Current = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version?.ToString(3) ?? "1.0.0";
    }

    internal static class UpdateChecker
    {
        // ── Fill this in as "owner/repo" (e.g. "octocat/Hello-World") to
        //    check GitHub Releases instead of/alongside CheckUrl below —
        //    this is preferred when set, since GitHub's Releases API is a
        //    well-documented, stable format (tag_name / assets[].browser_
        //    download_url / body), unlike an arbitrary paste whose exact
        //    contents can't be verified from here. Leave empty to use
        //    CheckUrl instead. ──────────────────────────────────────────
        public const string GitHubRepo = ""; // TODO: paste your "owner/repo" here

        // ── Direct download override — set this and it's used as the
        //    update payload regardless of where the version number came
        //    from (GitHubRepo's Releases API, CheckUrl's JSON, or a bare
        //    version string). Useful when you're hosting the actual
        //    update file as a plain committed file rather than a formal
        //    GitHub Release asset (a Release gives you real download
        //    URLs automatically via GitHubRepo above — this is for when
        //    you're not using that).
        //
        //    IMPORTANT: a "github.com/.../blob/..." link is an HTML page,
        //    not the actual file bytes — it needs converting to
        //    "raw.githubusercontent.com/.../..." (no "blob" segment) to
        //    get something an HttpClient can actually download.
        //
        //    Pinned to a specific COMMIT HASH rather than "main" —
        //    verified this exact commit actually has the file (2.53MB,
        //    confirmed by fetching it directly). A "main"-branch URL
        //    kept 404ing, most likely because this file isn't at that
        //    path on main's current tip, only on this commit.
        //
        //    TRADE-OFF worth knowing: a commit-hash URL is frozen to
        //    this exact commit forever — publishing a new update means
        //    updating this constant with the NEW commit hash each time,
        //    not just re-uploading the file. A proper GitHub Release
        //    (via GitHubRepo above) avoids that entirely — its "latest"
        //    URL automatically points at whatever you most recently
        //    published, no code changes needed per release. Worth
        //    switching to that for anything beyond initial testing.
        //
        //    Also worth knowing: raw.githubusercontent.com has a file
        //    size ceiling (roughly 100–125MB) and GitHub doesn't intend
        //    it as general-purpose file hosting — fine for testing or a
        //    modest-sized app, but a proper Release is the more
        //    scalable, sanctioned path if this ever needs to host
        //    something larger. ─────────────────────────────────────────
        public const string DirectDownloadUrl =
            "https://raw.githubusercontent.com/EclipseYT212/GtaVehicleTool/c09be76e642c7d292d3e4d441d91f5a6c139c352/New%20Compressed%20(zipped)%20Folder.zip";

        // Fallback / alternative — expects JSON {"version":"1.2.0","url":"...","notes":"..."}
        // or a bare version string like "1.2.0" / "V1.2.0" on its own.
        public const string CheckUrl = "https://pastebin.com/raw/D53ZEwxe";

        public class UpdateResult
        {
            public bool UpdateAvailable;
            public string LatestVersion;
            public string DownloadUrl;
            public string ReleaseNotes;
            public string Error; // null on success — set to the actual reason on failure, shown in the UI instead of a generic message
        }

        public static async System.Threading.Tasks.Task<UpdateResult> CheckAsync()
        {
            bool useGitHub = !string.IsNullOrWhiteSpace(GitHubRepo);
            string url = useGitHub ? $"https://api.github.com/repos/{GitHubRepo}/releases/latest" : CheckUrl;

            if (string.IsNullOrEmpty(url))
                return new UpdateResult { Error = "No update source configured — set either GitHubRepo or CheckUrl in UpdateChecker." };

            try
            {
                using var client = new System.Net.Http.HttpClient { Timeout = TimeSpan.FromSeconds(8) };
                // A generic UA string is enough for most hosts, but Pastebin
                // specifically is known to sometimes reject or challenge
                // requests without a browser-like one, and GitHub's API
                // REQUIRES a User-Agent header or it rejects the request
                // outright — a real browser UA satisfies both.
                client.DefaultRequestHeaders.UserAgent.ParseAdd(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) GtaFileRenamer-UpdateCheck/1.0");
                if (useGitHub) client.DefaultRequestHeaders.Accept.ParseAdd("application/vnd.github+json");

                System.Net.Http.HttpResponseMessage response;
                try { response = await client.GetAsync(url); }
                catch (System.Net.Http.HttpRequestException ex) { return new UpdateResult { Error = "Network error: " + ex.Message }; }
                catch (TaskCanceledException) { return new UpdateResult { Error = "Request timed out after 8 seconds." }; }

                if (!response.IsSuccessStatusCode)
                {
                    string extra = useGitHub && (int)response.StatusCode == 404
                        ? " (check GitHubRepo is spelled \"owner/repo\" correctly and the repo has at least one published release)"
                        : "";
                    return new UpdateResult { Error = $"Server returned {(int)response.StatusCode} {response.ReasonPhrase}.{extra}" };
                }

                string json = await response.Content.ReadAsStringAsync();

                string latest;
                string downloadUrl = null;
                string notes = "";

                if (useGitHub)
                {
                    // GitHub's actual Releases API shape — tag_name (not
                    // "version"), assets[0].browser_download_url for the
                    // first uploaded release asset, body for release notes.
                    var tagMatch = System.Text.RegularExpressions.Regex.Match(json, "\"tag_name\"\\s*:\\s*\"([^\"]+)\"");
                    if (!tagMatch.Success)
                        return new UpdateResult { Error = "GitHub response didn't contain a \"tag_name\" — is this really a Releases API response?" };
                    latest = tagMatch.Groups[1].Value.TrimStart('v', 'V');

                    var assetMatch = System.Text.RegularExpressions.Regex.Match(json, "\"browser_download_url\"\\s*:\\s*\"([^\"]+)\"");
                    downloadUrl = assetMatch.Success ? assetMatch.Groups[1].Value : null;

                    var bodyMatch = System.Text.RegularExpressions.Regex.Match(json, "\"body\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
                    if (bodyMatch.Success)
                        notes = System.Text.RegularExpressions.Regex.Unescape(bodyMatch.Groups[1].Value);
                }
                else
                {
                    var versionMatch = System.Text.RegularExpressions.Regex.Match(json, "\"version\"\\s*:\\s*\"([^\"]+)\"");
                    if (versionMatch.Success)
                    {
                        latest = versionMatch.Groups[1].Value;
                        var urlMatch = System.Text.RegularExpressions.Regex.Match(json, "\"url\"\\s*:\\s*\"([^\"]+)\"");
                        var notesMatch = System.Text.RegularExpressions.Regex.Match(json, "\"notes\"\\s*:\\s*\"([^\"]*)\"");
                        downloadUrl = urlMatch.Success ? urlMatch.Groups[1].Value : null;
                        notes = notesMatch.Success ? notesMatch.Groups[1].Value : "";
                    }
                    else
                    {
                        // Not JSON, or no "version" field — try the whole
                        // response as a bare version string instead (e.g. a
                        // paste that just contains "V1.2.0" or "1.2.0" on
                        // its own, which is what this actually turned out
                        // to be for the paste this was first tested against).
                        string trimmed = json.Trim().TrimStart('v', 'V');
                        var bareMatch = System.Text.RegularExpressions.Regex.Match(trimmed, @"^\d+(\.\d+){1,3}");
                        if (!bareMatch.Success)
                        {
                            string preview = json.Length > 200 ? json.Substring(0, 200) + "…" : json;
                            return new UpdateResult { Error = $"Couldn't find a version number in the response (tried JSON \"version\" field and a bare version string). Got:\n{preview}" };
                        }
                        latest = bareMatch.Value;
                    }
                }

                bool isNewer = Version.TryParse(latest, out var latestVer) && Version.TryParse(AppVersion.Current, out var currentVer)
                    ? latestVer > currentVer
                    : !string.Equals(latest, AppVersion.Current, StringComparison.OrdinalIgnoreCase);

                return new UpdateResult
                {
                    UpdateAvailable = isNewer,
                    LatestVersion = latest,
                    DownloadUrl = !string.IsNullOrWhiteSpace(DirectDownloadUrl) ? DirectDownloadUrl : downloadUrl,
                    ReleaseNotes = notes,
                };
            }
            catch (Exception ex)
            {
                return new UpdateResult { Error = "Unexpected error: " + ex.Message };
            }
        }
    }

    // =========================================================================
    //  AppUpdater — hands off to the separate GtaFileRenamerUpdater.exe
    //  bootstrapper and exits. A running .exe can't overwrite itself on
    //  Windows, so applying an update has to happen from a different
    //  process entirely — this only launches that process and gets out of
    //  the way. See the GtaFileRenamerUpdater project for the actual
    //  download/replace/relaunch logic.
    // =========================================================================
    internal static class AppUpdater
    {
        // ── Copies the currently-running exe to a temp location and
        //    launches THAT COPY with special arguments, then exits.
        //
        //    Why: Windows won't let a running .exe overwrite its own file
        //    on disk — that's a hard OS constraint, not a design choice.
        //    The copy running from %TEMP% never locks the real installed
        //    .exe at all, so once the ORIGINAL (install-dir) instance has
        //    exited, the temp copy is completely free to replace it. This
        //    keeps everything in one project/one build — there's no
        //    separate exe to build or manually place anywhere; the
        //    "updater" is just this same exe, launched with different
        //    arguments, from a different path. ─────────────────────────
        // ── Guaranteed-writable diagnostic log — deliberately NOT in
        //    installDir (that could itself be part of what's failing).
        //    Written to unconditionally, at every step, so a failure
        //    anywhere in this method leaves a trail instead of just
        //    vanishing. Delete this file freely; it's just a debug aid. ──
        private static readonly string LaunchLogPath =
            System.IO.Path.Combine(System.IO.Path.GetTempPath(), "GtaFileRenamerLaunchDebug.log");

        private static void LaunchLog(string message)
        {
            try { System.IO.File.AppendAllText(LaunchLogPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}\n"); }
            catch { /* if even this fails, there's genuinely nothing further we can do */ }
        }

        public static void LaunchAndExit(string downloadUrl, string latestVersion)
        {
            LaunchLog("=== LaunchAndExit called ===");
            LaunchLog($"downloadUrl={downloadUrl}");
            LaunchLog($"latestVersion={latestVersion}");

            string installDir, currentExePath, mainExeName, tempDir, tempCopyPath;
            try
            {
                installDir = AppDomain.CurrentDomain.BaseDirectory;
                currentExePath = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
                mainExeName = System.IO.Path.GetFileName(currentExePath);
                LaunchLog($"installDir={installDir}");
                LaunchLog($"currentExePath={currentExePath}");
                LaunchLog($"mainExeName={mainExeName}");
            }
            catch (Exception ex)
            {
                LaunchLog("FAILED getting current process info: " + ex);
                MessageBox.Show("Couldn't determine the current app's location: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                tempDir = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"GtaFileRenamerUpdater_{Guid.NewGuid():N}");
                System.IO.Directory.CreateDirectory(tempDir);
                LaunchLog($"Created tempDir={tempDir}");
            }
            catch (Exception ex)
            {
                LaunchLog("FAILED creating temp directory: " + ex);
                MessageBox.Show("Couldn't create a temp folder for the update: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                int copiedCount = CopyDirectoryShallow(installDir, tempDir);
                LaunchLog($"Copied {copiedCount} file(s) from installDir to tempDir.");
                tempCopyPath = System.IO.Path.Combine(tempDir, mainExeName);
                LaunchLog($"tempCopyPath={tempCopyPath}, exists={System.IO.File.Exists(tempCopyPath)}");

                if (!System.IO.File.Exists(tempCopyPath))
                {
                    LaunchLog("FATAL: the main exe itself did not end up in the temp copy — cannot launch.");
                    MessageBox.Show(
                        $"The update couldn't start — {mainExeName} wasn't successfully copied to the temp folder.\n\n" +
                        $"Details logged to:\n{LaunchLogPath}",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            catch (Exception ex)
            {
                LaunchLog("FAILED copying app to temp: " + ex);
                MessageBox.Show("Couldn't copy the app to a temp folder: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                int pid = System.Diagnostics.Process.GetCurrentProcess().Id;
                // installDir MUST have its trailing backslash stripped
                // before being embedded in a quoted argument — a path
                // ending in "\" immediately before the closing quote gets
                // read by Windows as an escaped quote character, not a
                // path separator + string terminator, which corrupts the
                // entire argument split. AppDomain.BaseDirectory always
                // has that trailing backslash, so this isn't optional.
                string installDirForArgs = installDir.TrimEnd('\\', '/');
                string arguments = $"--apply-update \"{downloadUrl}\" \"{installDirForArgs}\" \"{mainExeName}\" {pid} \"{latestVersion}\"";
                LaunchLog($"Launching: \"{tempCopyPath}\" {arguments}");

                var psi = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = tempCopyPath,
                    Arguments = arguments,
                    UseShellExecute = true,
                };
                var started = System.Diagnostics.Process.Start(psi);

                if (started == null)
                {
                    // UseShellExecute=true can return null even on
                    // "success" in some cases (e.g. the shell handed the
                    // request to an already-running instance) — log it
                    // either way rather than assume.
                    LaunchLog("Process.Start returned null (UseShellExecute=true can do this even without an error).");
                }
                else
                {
                    LaunchLog($"Process.Start returned Id={started.Id}, HasExited={SafeHasExited(started)}");
                }
            }
            catch (Exception ex)
            {
                LaunchLog("FAILED launching temp copy: " + ex);
                MessageBox.Show(
                    $"Couldn't launch the updater: {ex.Message}\n\nDetails logged to:\n{LaunchLogPath}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LaunchLog("Reached Application.Exit() — closing main app now.");
            System.Windows.Forms.Application.Exit();
        }

        private static bool? SafeHasExited(System.Diagnostics.Process p)
        {
            try { return p.HasExited; }
            catch { return null; } // checking too early/too late can itself throw — not worth failing over
        }

        // ── A real write-access check, not a permissions-flag guess —
        //    creates and immediately deletes a small marker file. Used
        //    to decide whether elevation is actually needed before ever
        //    requesting it, rather than assuming. ─────────────────────
        internal static bool CanWriteToDirectory(string dir)
        {
            try
            {
                string testFile = System.IO.Path.Combine(dir, $".write_test_{Guid.NewGuid():N}.tmp");
                System.IO.File.WriteAllText(testFile, "");
                System.IO.File.Delete(testFile);
                return true;
            }
            catch
            {
                return false;
            }
        }

        // ── Recursive copy — covers subfolders too (some dependencies,
        //    especially native-interop packages, ship files under paths
        //    like "runtimes\win-x64\native\", not just flat next to the
        //    exe). Skips any individual file that fails to copy rather
        //    than aborting the whole thing — a locked or irrelevant
        //    leftover file (like a previous updater's log) shouldn't
        //    block the copy of everything the app actually needs to run. ──
        internal static int CopyDirectoryShallow(string sourceDir, string destDir)
        {
            int copied = 0;
            foreach (var file in System.IO.Directory.GetFiles(sourceDir, "*", System.IO.SearchOption.AllDirectories))
            {
                try
                {
                    string rel = System.IO.Path.GetRelativePath(sourceDir, file);
                    string dest = System.IO.Path.Combine(destDir, rel);
                    System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(dest));
                    System.IO.File.Copy(file, dest, overwrite: true);
                    copied++;
                }
                catch (Exception ex)
                {
                    LaunchLog($"  Failed copying {file}: {ex.Message}");
                }
            }
            return copied;
        }
    }

    // =========================================================================
    //  UpdaterForm — runs when this same exe is launched with
    //  "--apply-update ..." arguments (see Program.Main below and
    //  AppUpdater.LaunchAndExit above). Waits for the original instance
    //  to exit, downloads the update, replaces files, relaunches.
    // =========================================================================
    internal class UpdaterForm : Form
    {
        private readonly string _downloadUrl, _installDir, _mainExeName, _latestVersion;
        private readonly int _mainPid;
        private readonly Label _status, _detail;
        private readonly ProgressBar _progressBar;
        private readonly string _logPath;

        public UpdaterForm(string downloadUrl, string installDir, string mainExeName, int mainPid, string latestVersion)
        {
            _downloadUrl = downloadUrl;
            _installDir = installDir;
            _mainExeName = mainExeName;
            _mainPid = mainPid;
            _latestVersion = latestVersion;
            _logPath = System.IO.Path.Combine(installDir, "updater_log.txt");

            Text = "GTA File Renamer — Updating";
            Size = new Size(500, 190);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            TopMost = true; // this runs after the main window closes — make sure it's actually visible, not buried
            BackColor = Color.FromArgb(24, 24, 28);

            _status = new Label
            {
                Text = "Starting update…",
                Location = new Point(20, 20),
                Size = new Size(460, 24),
                TextAlign = ContentAlignment.MiddleLeft,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
            };
            _progressBar = new ProgressBar
            {
                Location = new Point(20, 52),
                Size = new Size(460, 22),
                Minimum = 0,
                Maximum = 100,
                Value = 0,
                Style = ProgressBarStyle.Continuous,
            };
            _detail = new Label
            {
                Text = "",
                Location = new Point(20, 82),
                Size = new Size(460, 60),
                TextAlign = ContentAlignment.TopLeft,
                ForeColor = Color.FromArgb(180, 180, 180),
                Font = new Font("Consolas", 8.5f),
            };
            Controls.Add(_status);
            Controls.Add(_progressBar);
            Controls.Add(_detail);

            Shown += async (s, e) => await RunUpdateAsync();
        }

        private void Log(string message)
        {
            try { System.IO.File.AppendAllText(_logPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}\n"); }
            catch { /* if we can't even log, there's nothing further to do about it */ }
        }

        private void SetStatus(string text)
        {
            _status.Text = text;
            Log(text);
        }

        // ── Updates the detail line + progress bar without spamming the
        //    log file with one entry per file — the log still gets a
        //    summary line at the start/end of each phase (see
        //    DownloadUpdateAsync/ApplyUpdateAsync), just not a line for
        //    every single percent tick or every single file. ────────────
        private void SetDetail(string text, int? progressPercent = null)
        {
            _detail.Text = text;
            if (progressPercent.HasValue)
                _progressBar.Value = Math.Max(0, Math.Min(100, progressPercent.Value));
        }

        private async System.Threading.Tasks.Task RunUpdateAsync()
        {
            try
            {
                SetStatus($"Updating to v{_latestVersion} — waiting for GTA File Renamer to close…");
                await WaitForMainProcessExitAsync();

                SetStatus("Downloading update…");
                string downloadedFile = await DownloadUpdateAsync();

                SetStatus("Applying update…");
                await ApplyUpdateAsync(downloadedFile);

                SetStatus("Update applied — relaunching…");
                SetDetail("", 100);
                await System.Threading.Tasks.Task.Delay(800);
                RelaunchMainApp();

                Close();
            }
            catch (Exception ex)
            {
                Log("FATAL: " + ex);
                MessageBox.Show(
                    $"Update failed: {ex.Message}\n\nFull details logged to:\n{_logPath}\n\n" +
                    "Your existing install wasn't touched if this failed before the \"Applying update\" step.",
                    "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                RelaunchMainApp(); // don't leave the user without a working app just because the update failed
                Close();
            }
        }

        private async System.Threading.Tasks.Task WaitForMainProcessExitAsync()
        {
            if (_mainPid <= 0) { await System.Threading.Tasks.Task.Delay(1500); return; }
            try
            {
                var proc = System.Diagnostics.Process.GetProcessById(_mainPid);
                await System.Threading.Tasks.Task.Run(() => proc.WaitForExit(15000));
            }
            catch (ArgumentException) { /* already exited before we even got here — fine */ }
            await System.Threading.Tasks.Task.Delay(500); // grace period for file handles to actually release
        }

        // ── Staged inside the install directory itself now (previously
        //    %TEMP%) — this is genuinely "the tool's own path" rather
        //    than a generic system temp location. Cleaned up at the end
        //    of ApplyUpdateAsync either way. ─────────────────────────────
        private string StagingDir => System.IO.Path.Combine(_installDir, "_update_staging");

        private async System.Threading.Tasks.Task<string> DownloadUpdateAsync()
        {
            string stagingDir = StagingDir;
            if (System.IO.Directory.Exists(stagingDir))
                System.IO.Directory.Delete(stagingDir, recursive: true); // leftover from a previous failed attempt — start clean
            System.IO.Directory.CreateDirectory(stagingDir);

            using var client = new System.Net.Http.HttpClient { Timeout = TimeSpan.FromMinutes(10) };
            client.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) GtaFileRenamerUpdater/1.0");

            using var response = await client.GetAsync(_downloadUrl, System.Net.Http.HttpCompletionOption.ResponseHeadersRead);
            if (!response.IsSuccessStatusCode)
                throw new Exception($"Download failed: server returned {(int)response.StatusCode} {response.ReasonPhrase}");

            string fileName = response.Content.Headers.ContentDisposition?.FileNameStar
                               ?? response.Content.Headers.ContentDisposition?.FileName?.Trim('"')
                               ?? System.IO.Path.GetFileName(new Uri(_downloadUrl).LocalPath);
            if (string.IsNullOrWhiteSpace(fileName)) fileName = "update.bin";
            foreach (var c in System.IO.Path.GetInvalidFileNameChars()) fileName = fileName.Replace(c, '_');
            fileName = Uri.UnescapeDataString(fileName); // URLs commonly have %20 etc. — show the real name, not the encoded one

            long? totalBytes = response.Content.Headers.ContentLength;
            string totalLabel = totalBytes.HasValue ? FormatBytes(totalBytes.Value) : "unknown size";

            string filePath = System.IO.Path.Combine(stagingDir, fileName);
            using (var contentStream = await response.Content.ReadAsStreamAsync())
            using (var fs = System.IO.File.Create(filePath))
            {
                var buffer = new byte[81920];
                long totalRead = 0;
                int read;
                var lastUiUpdate = DateTime.MinValue;

                while ((read = await contentStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                {
                    await fs.WriteAsync(buffer, 0, read);
                    totalRead += read;

                    // Throttled to a few times a second — updating the UI
                    // on every single 80KB chunk would be needless churn
                    // for a 2-3MB file that downloads in a fraction of a
                    // second anyway.
                    if ((DateTime.Now - lastUiUpdate).TotalMilliseconds >= 100)
                    {
                        lastUiUpdate = DateTime.Now;
                        int percent = totalBytes.HasValue ? (int)(totalRead * 100 / totalBytes.Value) : 0;
                        SetDetail($"Downloading: {fileName}\n{FormatBytes(totalRead)} / {totalLabel}", percent);
                    }
                }
                SetDetail($"Downloading: {fileName}\n{FormatBytes(totalRead)} / {totalLabel}", 100);
            }

            Log($"Downloaded {fileName} ({new System.IO.FileInfo(filePath).Length} bytes) to {filePath}");
            return filePath;
        }

        private static string FormatBytes(long bytes)
        {
            string[] units = { "B", "KB", "MB", "GB" };
            double size = bytes; int u = 0;
            while (size >= 1024 && u < units.Length - 1) { size /= 1024; u++; }
            return $"{size:0.#} {units[u]}";
        }

        private async System.Threading.Tasks.Task ApplyUpdateAsync(string downloadedFile)
        {
            bool isZip = downloadedFile.EndsWith(".zip", StringComparison.OrdinalIgnoreCase) || HasZipMagicBytes(downloadedFile);

            if (isZip)
            {
                string extractDir = downloadedFile + "_extracted";
                SetDetail("Extracting archive…", 0);
                System.IO.Compression.ZipFile.ExtractToDirectory(downloadedFile, extractDir);
                Log($"Extracted zip to {extractDir}");

                // ── Handle the "wrapped folder" case — very common when a
                //    zip was made via Windows' "Compress to ZIP file" on a
                //    FOLDER rather than on its individual contents: the
                //    zip ends up with one top-level folder inside it
                //    wrapping everything else, so a naive extract-and-
                //    copy creates a stray subfolder in the install
                //    directory instead of actually overwriting the real
                //    files. Confirmed this is exactly what happened here
                //    ("New Compressed (zipped) Folder.zip" is the
                //    telltale name that action produces).
                //
                //    Detected by checking whether extractDir contains
                //    EXACTLY one entry, and that entry is itself a
                //    directory — if so, treat that inner directory as the
                //    real root instead of extractDir. ────────────────────
                string effectiveRoot = extractDir;
                var topLevelEntries = System.IO.Directory.GetFileSystemEntries(extractDir);
                if (topLevelEntries.Length == 1 && System.IO.Directory.Exists(topLevelEntries[0]))
                {
                    effectiveRoot = topLevelEntries[0];
                    Log($"Detected a single wrapping folder ({System.IO.Path.GetFileName(effectiveRoot)}) — using its contents as the real update root instead of copying it as a subfolder.");
                }

                var allFiles = System.IO.Directory.GetFiles(effectiveRoot, "*", System.IO.SearchOption.AllDirectories);
                int fileCount = 0;
                for (int i = 0; i < allFiles.Length; i++)
                {
                    string file = allFiles[i];
                    string rel = System.IO.Path.GetRelativePath(effectiveRoot, file);
                    string dest = System.IO.Path.Combine(_installDir, rel);

                    int percent = allFiles.Length > 0 ? (i + 1) * 100 / allFiles.Length : 100;
                    SetDetail($"Extracting: {rel}\nFile {i + 1} of {allFiles.Length}", percent);
                    Log($"  Extracting: {rel}");

                    System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(dest));
                    await CopyWithRetryAsync(file, dest);
                    fileCount++;
                }
                Log($"Copied {fileCount} file(s) from the update into {_installDir}.");
            }
            else
            {
                SetDetail($"Replacing: {_mainExeName}", 50);
                string dest = System.IO.Path.Combine(_installDir, _mainExeName);
                await CopyWithRetryAsync(downloadedFile, dest);
                SetDetail($"Replaced: {_mainExeName}", 100);
            }

            // ── Clean up the staging folder now that everything's been
            //    copied out of it — leaving it behind would mean it (and
            //    the leftover downloaded zip inside it) sits in the
            //    install directory permanently after every update. ──────
            try
            {
                if (System.IO.Directory.Exists(StagingDir))
                    System.IO.Directory.Delete(StagingDir, recursive: true);
            }
            catch (Exception ex)
            {
                // Not fatal — the update already succeeded by this point,
                // this is just tidiness. Log it in case it piles up.
                Log($"Couldn't clean up staging folder (non-fatal): {ex.Message}");
            }
        }

        private async System.Threading.Tasks.Task CopyWithRetryAsync(string source, string dest)
        {
            const int maxAttempts = 5;
            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                try { System.IO.File.Copy(source, dest, overwrite: true); return; }
                catch (System.IO.IOException) when (attempt < maxAttempts)
                {
                    Log($"  {System.IO.Path.GetFileName(dest)} still locked, retrying ({attempt}/{maxAttempts})…");
                    await System.Threading.Tasks.Task.Delay(600);
                }
            }
            throw new System.IO.IOException($"Couldn't replace {dest} — it stayed locked after {maxAttempts} attempts.");
        }

        private static bool HasZipMagicBytes(string filePath)
        {
            try
            {
                using var fs = System.IO.File.OpenRead(filePath);
                var buf = new byte[2];
                if (fs.Read(buf, 0, 2) < 2) return false;
                return buf[0] == 0x50 && buf[1] == 0x4B; // "PK"
            }
            catch { return false; }
        }

        private void RelaunchMainApp()
        {
            try
            {
                string mainExePath = System.IO.Path.Combine(_installDir, _mainExeName);
                if (System.IO.File.Exists(mainExePath))
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo { FileName = mainExePath, WorkingDirectory = _installDir, UseShellExecute = true });
                else
                    Log($"Couldn't relaunch — {mainExePath} not found.");
            }
            catch (Exception ex)
            {
                Log("Relaunch failed: " + ex.Message);
            }
        }
    }

    // =========================================================================
    //  Application entry point
    // =========================================================================

    static class Program
    {
        private static string CrashLogPath => System.IO.Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "GtaFileRenamer", "crash_log.txt");

        private static void LogCrash(Exception ex, string source)
        {
            try
            {
                var dir = System.IO.Path.GetDirectoryName(CrashLogPath);
                System.IO.Directory.CreateDirectory(dir);
                System.IO.File.AppendAllText(CrashLogPath,
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] ({source}) {ex}\n\n");
            }
            catch { /* if we can't even log the crash, there's nothing further to do */ }
        }

        [System.STAThread]
        static void Main(string[] args)
        {
            // Global handlers — these catch exceptions that happen OUTSIDE
            // the normal WinForms message loop (background threads, async
            // void handlers, etc.) and on the UI thread respectively. Log
            // them instead of letting the process just vanish with no
            // record of what happened, which is what was happening before
            // for any exception that made it this far up.
            AppDomain.CurrentDomain.UnhandledException += (s, e) => LogCrash(e.ExceptionObject as Exception, "AppDomain");
            System.Windows.Forms.Application.ThreadException += (s, e) => LogCrash(e.Exception, "UI thread");
            System.Windows.Forms.Application.SetUnhandledExceptionMode(System.Windows.Forms.UnhandledExceptionMode.CatchException);

            System.Windows.Forms.Application.EnableVisualStyles();
            System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);

            // ── Update mode — this same exe, launched from a temp copy
            //    with these arguments by AppUpdater.LaunchAndExit above.
            //    Runs the updater UI instead of the normal app. ─────────
            if (args.Length > 0 && args[0] == "--apply-update")
            {
                if (args.Length < 5)
                {
                    MessageBox.Show("Update launched with missing arguments — can't continue.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string downloadUrl = args[1];
                string installDir = args[2];
                string mainExeName = args[3];
                int mainPid = int.TryParse(args[4], out int pid) ? pid : -1;
                string latestVersion = args.Length > 5 ? args[5] : "unknown";

                if (!AppUpdater.CanWriteToDirectory(installDir))
                {
                    // Self-elevate — only if the write check actually
                    // fails, not unconditionally. Relaunches THIS SAME
                    // temp-copy exe with the same args plus an explicit
                    // elevation request.
                    try
                    {
                        var psi = new System.Diagnostics.ProcessStartInfo
                        {
                            FileName = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName,
                            Arguments = string.Join(" ", Array.ConvertAll(args, a => $"\"{a}\"")),
                            UseShellExecute = true,
                            Verb = "runas",
                        };
                        System.Diagnostics.Process.Start(psi);
                    }
                    catch (System.ComponentModel.Win32Exception)
                    {
                        MessageBox.Show(
                            $"This update needs permission to write to:\n  {installDir}\n\n" +
                            "Elevation was declined, so the update can't be applied. Try again and accept the " +
                            "permission prompt.",
                            "Permission Needed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    return;
                }

                System.Windows.Forms.Application.Run(new UpdaterForm(downloadUrl, installDir, mainExeName, mainPid, latestVersion));
                return;
            }

            try
            {
                System.Windows.Forms.Application.Run(new ModernMainForm());
            }
            catch (Exception ex)
            {
                LogCrash(ex, "Application.Run");
                System.Windows.Forms.MessageBox.Show(
                    $"A fatal error occurred and has been logged to:\n{CrashLogPath}\n\n{ex.Message}",
                    "Unexpected Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
            }
        }
    }
}